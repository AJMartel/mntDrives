// general tool functions

void printHello( )
{
   printf("hello\n");
}

