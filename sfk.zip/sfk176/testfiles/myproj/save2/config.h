// the myproj config

#define FOO 1

