/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

class BarGlass
{
public:
    BarGlass   ( );
   ~BarGlass   ( );

private:
Something
   *pClSomething;
};
