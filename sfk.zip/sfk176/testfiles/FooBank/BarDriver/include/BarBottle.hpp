/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

class BarBottle
{
public:
    BarBottle   ( );
   ~BarBottle   ( );

private:
Something
   *pClSomething;
};
