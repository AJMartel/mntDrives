/*
   this is a completely pointless text file
   to easily demonstrate sfk functionality.
*/

#include "Trace.hpp"

BarBottle::BarBottle( )
{
   pClSomething = 0;
}

BarBottle::~BarBottle( )
{
   if (pClBotte) {
      delete pClSomething = 0;
      pClSomething = 0;
   }
}
