// os_handle_t.h: interface and implementation of the os_handle_t class.
//
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.
#ifndef _OS_HANDLE_T_H_
#define _OS_HANDLE_T_H_

#include "stdafx.h"

namespace wipe_v1_0 {

class os_handle_t
{
public:
	inline os_handle_t(const os_handle_t& rHandle)
		{	
			m_bFreeHandleOnClose = rHandle.m_bFreeHandleOnClose;
			m_hHandle = rHandle.release(); 
		}
	inline os_handle_t(HANDLE hHandle = INVALID_HANDLE_VALUE, bool bFreeHandleOnClose = true ) : m_hHandle(hHandle),
			m_bFreeHandleOnClose(bFreeHandleOnClose && hHandle != INVALID_HANDLE_VALUE)
		{	}
	inline os_handle_t& operator=(const os_handle_t& rHandle)
		{	
			if(m_hHandle != rHandle.get())
			{
				if(m_bFreeHandleOnClose)
					::CloseHandle(m_hHandle);
				m_bFreeHandleOnClose = rHandle.m_bFreeHandleOnClose;
				m_hHandle = rHandle.release();
			}
			else if(rHandle.m_bFreeHandleOnClose)
				m_bFreeHandleOnClose = true;

			return *this;
		}
	inline os_handle_t& operator=(HANDLE hHandle)
		{
			if(m_hHandle != hHandle)
			{
				if(m_bFreeHandleOnClose)
					::CloseHandle(m_hHandle);
			}
			m_hHandle = hHandle;
			m_bFreeHandleOnClose = true;
			return *this;
		}
	inline ~os_handle_t()
		{
			if(!empty())
				::CloseHandle(m_hHandle);
		}
	inline operator HANDLE() const
		{	return get();	}
	inline HANDLE get() const
		{	return m_hHandle;	}
	inline HANDLE release() const
		{
			m_bFreeHandleOnClose = false;
			return m_hHandle;	
		}
	inline bool empty() const
		{
			return (m_hHandle == INVALID_HANDLE_VALUE);
		}
private:
	HANDLE m_hHandle;
	mutable bool m_bFreeHandleOnClose;
};

} //namespace wipe_v1_0

#endif //_OS_HANDLE_T_H_