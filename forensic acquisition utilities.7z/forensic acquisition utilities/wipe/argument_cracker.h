// argument_cracker.h: interface and implementation of the argument_cracker class.
//
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#ifndef _ARGUMENT_CRACKER_H_
#define _ARGUMENT_CRACKER_H_

#include "stdafx.h"

namespace wipe_v1_0 {

wchar_t* full_path(const wchar_t* lpszPath)
{
	wchar_t* lpszFullPath = (wchar_t*)0;

	_ASSERTE(lpszPath != NULL);

	unsigned long dwSize = GetLongPathName(lpszPath, (wchar_t*)0, 0UL);
	
	if(dwSize == 0UL)
	{
		dwSize = (unsigned long) wcslen(lpszPath) + 1;
		lpszFullPath = new wchar_t[dwSize];
		wcsncpy(lpszFullPath, lpszPath, dwSize);
	}
	else
	{

		dwSize = (unsigned long)max((size_t)dwSize, wcslen(lpszPath));

		lpszFullPath = new wchar_t[++dwSize];

		unsigned long dwReturned = GetLongPathName(lpszPath, lpszFullPath, dwSize);
		_ASSERTE(dwReturned < dwSize);
	}

	_RPT0(_CRT_WARN, "FILE: ");
	OutputDebugStringW(lpszFullPath);
	_RPT0(_CRT_WARN, "\n");

	return lpszFullPath;
}

class argument_cracker  
{
public:
	argument_cracker(int argc, wchar_t** argv) 
		: m_iArgs(argc), m_rgArgs(argv), m_pszFile(0), 
		  m_nPhase(phase_none), m_nBlockSize(4096),
		  m_nTapePartition(0), m_bVerify(false),
		  m_lPattern(wiper_pattern_none)
	{
	}

	~argument_cracker()
	{
		if(m_pszFile != (wchar_t*) 0)
			delete [] m_pszFile;
	}

	bool operator()(void)
	{
		if(m_iArgs < 2)
			return false;

		for(int i = 1; i < m_iArgs; ++i)
			if(!crack(m_rgArgs[i]))
				return false;   // unknown argument

		return true;
	}
	inline const wchar_t* file() const
	{
		return m_pszFile;
	}
	inline size_t block_size() const
	{
		return m_nBlockSize;
	}
	inline bool verify() const
	{
		return m_bVerify;
	}
	inline unsigned int tape_partition() const
	{
		return m_nTapePartition;
	}
	inline long pattern() const
	{
		return m_lPattern;
	}
private:
	enum { phase_none = 0,
		phase_reading_block_size,
		phase_reading_tape_partition,
		phase_reading_pattern,
	};
	enum { wiper_pattern_none = 0L,  //8/17/2004
		wiper_pattern_FF,
		wiper_pattern_random,
		wiper_pattern_zero,
	};

	bool crack(const wchar_t* lpszArg)
	{
		using namespace std;
		bool bResult;

		if(is_flag(lpszArg))
			bResult = crack_flag(lpszArg);
		else 
			bResult = crack_argument(lpszArg);
		
//		m_nPhase = phase_none;
		return bResult;
	}
	bool is_flag(const wchar_t* lpszArg) const
	{
		_ASSERTE(lpszArg != NULL);
		if(lpszArg[0] == L'-' ||
			lpszArg[0] == L'/')
			return true;
		return false;
	}
	bool crack_flag(const wchar_t* lpszArg)
	{
		switch(lpszArg[1])
		{
		case L'b':
		case L'B':
			m_nPhase = phase_reading_block_size;
			return true;
		case L'v':
		case L'V':
			m_bVerify = true;
			return true;
		case L'P':
		case L'p':
			m_nPhase = phase_reading_tape_partition;
			return true;
		case L'W':  // added 8/17/2004
		case L'w':
			m_nPhase = phase_reading_pattern;
			return true;
		case L'?':
		default:
			m_nPhase = phase_none;
			break;
		}
		return false;		
	}
	bool crack_argument(const wchar_t* lpszArg)
	{
		switch(m_nPhase)
		{
		case phase_reading_block_size:
			if(!is_numeric(lpszArg))
				return false;
			m_nBlockSize = _wtoi(lpszArg);
			break;
		case phase_reading_tape_partition:
			if(!is_numeric(lpszArg))
				return false;
			m_nTapePartition = _wtoi(lpszArg);
			break;
		case phase_none:
			m_pszFile = full_path(lpszArg);
			break;
		case phase_reading_pattern:
			if(wcsnicmp(lpszArg, L"FF", 2) == 0 ||
				wcsnicmp(lpszArg, L"ff", 2) == 0)
				m_lPattern = wiper_pattern_FF;
			else if(wcsnicmp(lpszArg, L"00", 2) == 0)
				m_lPattern = wiper_pattern_zero;
			else if(wcsnicmp(lpszArg, L"RND", 3) == 0 ||
				wcsnicmp(lpszArg, L"rnd", 3) == 0)
				m_lPattern = wiper_pattern_random;
			break;
		default:
			return false;
		}

		m_nPhase = phase_none;

		return true;
	}
	// Tests each character in the sequence to see if it is a digit.
	inline bool is_numeric(const wchar_t* lpszArg)
	{
		size_t len = wcslen(lpszArg);

		if(len == 0)
			return false;

		for(size_t i = 0; i < len; ++i)
			if(!iswdigit(lpszArg[i]))
				return false;
		return true;
	}

	const int m_iArgs;
	wchar_t** m_rgArgs;
	wchar_t* m_pszFile;
	unsigned int m_nPhase;
	unsigned int m_nTapePartition;
	size_t m_nBlockSize;
	long m_lPattern;
	bool m_bVerify;
};


} //namespace wipe_v1_0

#endif //_ARGUMENT_CRACKER_H_