// wipe.cpp : Defines the entry point for the console application.
//
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#include "stdafx.h"
#include "resource.h"

#ifndef _ARGUMENT_CRACKER_H_
#include "argument_cracker.h"
#endif //_ARGUMENT_CRACKER_H_

#ifndef _OS_VERSION_H_
#include "os_version.h"
#endif //_OS_VERSION_H_

#ifndef _WIPE_COMMANDER_H_
#include "wipe_commander.h"
#endif //_WIPE_COMMANDER_H_

using namespace std;
using namespace wipe_v1_0;

#define OS_VERSION_MAJOR_REQUIRED 5
#define OS_VERSION_MINOR_REQUIRED 0
#define BIG_BUFFER_SIZE 1024
#define DRIVE_TYPE_LENGTH 32

wchar_t* lpszProgram = (wchar_t*)0;

NTQUERYINFORMATIONFILE file_and_attributes::m_pfnNtQueryInfomationFile = (NTQUERYINFORMATIONFILE)0;
RTLNTSTATUSTODOSERROR file_and_attributes::m_pfnRtlNtStatusToDosError = (RTLNTSTATUSTODOSERROR) 0;

/*bool wipe_directory(size_t nBlockSize, file_and_attributes& _F);
bool wipe_file_or_directory(file_and_attributes& _F, size_t block_size, bool bVerify);
bool wipe_streams(size_t block_size, file_and_attributes& _F, bool bVerify);*/

int __stdcall control_handler ( unsigned long);

bool get_ntfs_stream_api()
{
	// Ntdll.dll is already loaded so there is no need to call LoadLibrary()
	HMODULE hMod = GetModuleHandleW(L"ntdll.dll");

	_ASSERTE(hMod != (HMODULE) 0);
	file_and_attributes::m_pfnNtQueryInfomationFile = reinterpret_cast<NTQUERYINFORMATIONFILE>(GetProcAddress(hMod, "NtQueryInformationFile"));

	_ASSERTE(file_and_attributes::m_pfnNtQueryInfomationFile != (NTQUERYINFORMATIONFILE)0);

	file_and_attributes::m_pfnRtlNtStatusToDosError = reinterpret_cast<RTLNTSTATUSTODOSERROR>(GetProcAddress(hMod, "RtlNtStatusToDosError"));

	_ASSERTE(file_and_attributes::m_pfnRtlNtStatusToDosError != (RTLNTSTATUSTODOSERROR)0);
	return true;
}

HANDLE open_process_token_for_query()
{
	HANDLE hToken = INVALID_HANDLE_VALUE;
	if(!OpenProcessToken( GetCurrentProcess(),
				          TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY,
				          &hToken )) {
	
		return false;
	}
	return hToken;
}

bool enable_backup_privilege()
{
	os_handle_t Token(open_process_token_for_query());

	if(Token.empty())
		return false;

    LUID luid;
	if(!LookupPrivilegeValue(NULL, SE_BACKUP_NAME, &luid ))
		return false;

    TOKEN_PRIVILEGES tp;
    tp.PrivilegeCount           = 1;
    tp.Privileges[0].Luid       = luid;
    tp.Privileges[0].Attributes = 0;

    TOKEN_PRIVILEGES tpPrevious;
    unsigned long _S = sizeof(TOKEN_PRIVILEGES);
	
    //
    // first pass.  get current privilege setting
    //

    if(!AdjustTokenPrivileges(
            Token,
            FALSE,
            &tp,
            sizeof(TOKEN_PRIVILEGES),
            &tpPrevious,
            &_S))
	{
		long lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to retrieve previous state of backup privilege! Last Error = %ld\n", lError);
		return false;
	}

    
    //
    // second pass.  set privilege based on previous setting
    //
    tpPrevious.PrivilegeCount       = 1;
    tpPrevious.Privileges[0].Luid   = luid;
    tpPrevious.Privileges[0].Attributes |= (SE_PRIVILEGE_ENABLED);
    
	if(!AdjustTokenPrivileges(Token,
							  FALSE,
							  &tpPrevious,
							  _S,
							  NULL,
							  NULL))
	{
		long lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to enable backup privilege! Last Error = %ld\n", lError);
		return false;
	}
	
	return true;
}

wchar_t* get_module_path()
{
	unsigned int i = 0;
	unsigned long dwSize;

	wchar_t * lpszFullPath = (wchar_t*) 0;
	
	// Unfortunately there is no way to size the module file name
	// other than trial and error.  Increase the path buffer in
	// _MAX_PATH increments.

	// Technically, this algorithm would result in an endless loop
	// in the case where the module does not exist.  However, the 
	// fact that this code is executing establishes the module's 
	// existence.
	do
	{
		
		dwSize = (_MAX_PATH * sizeof(wchar_t) * ++i);

		if(lpszFullPath != NULL)
			delete [] lpszFullPath;

		lpszFullPath = new wchar_t[dwSize];
		
		 
	} while(GetModuleFileName(NULL, lpszFullPath, dwSize) == 0UL);

	return lpszFullPath;
}

wchar_t* full_exe_path(const wchar_t* lpszPath)
{
	wchar_t* lpszFullPath = get_module_path();
	return lpszFullPath;
}

void display_system_time()
{
	SYSTEMTIME now;
	GetSystemTime(&now);

	TIME_ZONE_INFORMATION ti;

	fwprintf(stderr, L"\n%02d/%02d/%d  %02d:%02d:%02d (UTC)\n",
		    now.wDay, now.wMonth, now.wYear,
			now.wHour, now.wMinute, now.wSecond);

	unsigned long dwResult = GetTimeZoneInformation(&ti);
	
	if(dwResult == TIME_ZONE_ID_INVALID ||
		dwResult == TIME_ZONE_ID_UNKNOWN)
		return;
	
	SYSTEMTIME local;
	if(!SystemTimeToTzSpecificLocalTime(&ti, &now, &local))
		return;

	fwprintf(stderr, L"%02d/%02d/%d  %02d:%02d:%02d (local time)\n\n",
		    local.wDay, local.wMonth, local.wYear,
			local.wHour, local.wMinute, local.wSecond);

}

bool display_os_version()
{
	OSVERSIONINFOEX osvi;
	wchar_t szBuf[32];
	wchar_t szBuf2[32];


	// Try calling GetVersionEx using the OSVERSIONINFOEX structure.
	//
	// If that fails, try using the OSVERSIONINFO structure.

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if(!GetVersionEx ((OSVERSIONINFO *) &osvi))
		return false;

	switch (osvi.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		wcout << load_string(IDS_MICROSOFTWINDOWS, szBuf, 32) << load_string(IDS_VERSION, szBuf2, 32)
			  << L" " << dec << osvi.dwMajorVersion << L"." << osvi.dwMinorVersion << L" (Build "
				<< (osvi.dwBuildNumber & 0xFFFF) << L".";
		
		if ( osvi.wProductType == VER_NT_WORKSTATION )
		{
			if( osvi.wSuiteMask & VER_SUITE_PERSONAL )
				wcout << load_string(IDS_PERSONAL, szBuf, 32);
			else
				wcout << load_string(IDS_PROFESSIONAL, szBuf, 32);
		}

		else if ( osvi.wProductType == VER_NT_SERVER )
		{
		   if( osvi.wSuiteMask & VER_SUITE_DATACENTER )
			  wcout << load_string(IDS_DATACENTER, szBuf, 32);
		   else if( osvi.wSuiteMask & VER_SUITE_ENTERPRISE )
			  wcout << load_string(IDS_ADVANCEDSERVER, szBuf, 32);
		   else
			  wcout << load_string(IDS_SERVER, szBuf, 32);
		}
		if(osvi.szCSDVersion[0] != L'\0')
			wcout << L" " << osvi.szCSDVersion;

		wcout << L")" << endl;
        break;
	default:
		;

   }

   return true; 
}

LPCSTR system_error(long lerror, LPSTR lpBuf, unsigned long dwSize)
{
	if((FormatMessageA( 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		lerror,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		lpBuf,
		dwSize,
		NULL 
	)) == 0UL)
		return "";

	return lpBuf;
}

LPCWSTR system_error(long lerror, LPWSTR lpBuf, unsigned long dwSize)
{
	if((FormatMessageW( 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		lerror,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		lpBuf,
		dwSize,
		NULL 
	)) == 0UL)
		return L"";

	return lpBuf;
}

bool display_current_user(EXTENDED_NAME_FORMAT NameFormat)
{
	long lError;
	unsigned long dwSize = 0UL;
	wchar_t szBuf[32];

	if(GetUserNameEx(NameFormat, 
		              NULL,
					  &dwSize) ||
		(lError = GetLastError()) != ERROR_MORE_DATA)
	{
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return false;
	}

	wchar_t* pszName = reinterpret_cast<wchar_t*>(_alloca(dwSize * sizeof(wchar_t)));

	if(!GetUserNameEx(NameFormat, 
		              pszName,
					  &dwSize))
	{
		lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return false;
	}

	wcout << load_string(IDS_CURRENT_USER, szBuf, 32) << pszName << endl << endl;
	return true;
}

bool __stdcall banner(wchar_t* ProgramName)
{
#ifdef _DEBUG
	char ErrorBufA[BIG_BUFFER_SIZE];
#endif //_DEBUG

	unsigned long dwHandle;
	unsigned long dwSize = GetFileVersionInfoSize(ProgramName, &dwHandle);
	wchar_t* lpszFileDescription;
	wchar_t* lpszProductVersion;
	wchar_t* lpszLegalCopyright;
	wchar_t* lpszProductName;
	wchar_t* lpszFileVersion;
	wchar_t* lpszComment;
	wchar_t szBuf[32];

	unsigned int nSize;

	if(dwSize == 0UL)
	{
		_RPT2(_CRT_ERROR, "GetFileVersionInfo size failed! Size = %ld, Last Error = %s\n", dwSize, system_error(GetLastError(), ErrorBufA, BIG_BUFFER_SIZE));
		OutputDebugString(ProgramName);
		return false;
	}

	unsigned char* pbData = (unsigned char*)_alloca(dwSize * sizeof(unsigned char));
	if(!GetFileVersionInfo(ProgramName, dwHandle, dwSize, pbData))
	{
		_ASSERT(false);
		return false;
	}

	if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileDescription", 
					  reinterpret_cast<void**>(&lpszFileDescription), 
					  &nSize))
	{
		_ASSERT(false);
		return false;
	}

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductVersion", 
					  reinterpret_cast<void**>(&lpszProductVersion), 
					  &nSize))
	 {
		_ASSERT(false);
		 return false;
	 }

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductName", 
					  reinterpret_cast<void**>(&lpszProductName), 
					  &nSize))
	 {
		_ASSERT(false);
		 return false;
	 }


     if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileVersion", 
					  reinterpret_cast<void**>(&lpszFileVersion), 
					  &nSize))
	 {
		_ASSERT(false);
		 return false;
	 }

	 if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\LegalCopyright", 
					  reinterpret_cast<void**>(&lpszLegalCopyright), 
					  &nSize))
	  {
		 _ASSERT(false);
		  return false;
	  }

	  if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\Comments", 
					  (void**)&lpszComment, 
					  &nSize))
	  {
		 _ASSERT(false);
		  return false;
	  }

	wcout << lpszProductName << L", " << lpszProductVersion << endl;
	wcout << lpszFileDescription << L", " << lpszFileVersion << endl;
	wcout << lpszLegalCopyright << endl << endl << flush;
	wcout << load_string(IDS_COMMANDLINE, szBuf, 32) << GetCommandLineW() << endl;
	wcout << load_string(IDS_MODULE, szBuf, 32) << ProgramName << endl;
	wcout << lpszComment << endl;

	display_os_version();
	display_system_time();
	if(!display_current_user(NameCanonical))
		display_current_user(NameSamCompatible);

	return true;
}

void display_help()
{
	wchar_t ErrorBufW[BIG_BUFFER_SIZE];
	wcout << load_string(IDS_HELP, ErrorBufW, BIG_BUFFER_SIZE) << endl;
}

void __stdcall initialize_debug_memory()
{
#ifdef _DEBUG
	// Get the current state of the flag
	// and store it in a temporary variable
	int tmpFlag = _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );

	// Turn on client block identifiers and automatic leak detection
	tmpFlag |= (_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	// Set the new state for the flag
	_CrtSetDbgFlag( tmpFlag );
#endif //_DEBUG
}

bool display_message(unsigned int nIDFormat, ...)
{
	wchar_t szFormat[_MAX_PATH];
	wchar_t szBuffer[_MAX_PATH];

	if(LoadString(GetModuleHandle(NULL), nIDFormat, szFormat, _MAX_PATH) <= 0)
	{
		_RPT1(_CRT_WARN, "Error: Format string ID %ld not found!\n", nIDFormat);
		return false;
	}

	va_list marker;
	va_start(marker, nIDFormat);
	if(_vsnwprintf(szBuffer, _MAX_PATH, szFormat, marker) < 0)
		return false;

	wcout << szBuffer << endl;
	return true;
}

void report_bad_result()
{
	// Must not throw an exception.
	try
	{
		wchar_t szBuffer1[_MAX_PATH];
		wchar_t szBuffer2[_MAX_PATH];
		wcout << load_string(IDS_WIPE_FAILED, szBuffer1, _MAX_PATH) << 
			system_error(GetLastError(), szBuffer2, _MAX_PATH) << endl;
	}
	catch(...) { }
	
}

wipe_commander _Commander;

int wmain(int argc, wchar_t* argv[])
{
	bool bResult = false;
	bool bCoInit = false;

	initialize_debug_memory();
	SetConsoleCtrlHandler(control_handler, 1 );
	SetConsoleCtrlHandler(NULL, FALSE ); // added 8/17/2004
	SetErrorMode(SEM_FAILCRITICALERRORS);

	lpszProgram = full_exe_path(argv[0]);
	_RPT0(_CRT_WARN, "EXE: ");
	OutputDebugStringW(lpszProgram);
	_RPT0(_CRT_WARN, "\n");

	

	try
	{
		
		if(!check_os_version(OS_VERSION_MAJOR_REQUIRED, OS_VERSION_MINOR_REQUIRED))
		{
			display_message(IDS_E_OS_VERSION, OS_VERSION_MAJOR_REQUIRED, OS_VERSION_MINOR_REQUIRED, -1);
			throw (ERROR_OLD_WIN_VERSION);
		}

		// Needed for shell link support
		HRESULT hr = CoInitializeEx(NULL, COINIT_MULTITHREADED);
		
		if(hr != S_OK)
			throw(hr);

		bCoInit = true;

		// Needed for shell link support
		hr = CoInitializeSecurity( NULL, -1, NULL, NULL, 
									RPC_C_AUTHN_LEVEL_DEFAULT, 
									RPC_C_IMP_LEVEL_IMPERSONATE, 
									NULL, 
									EOAC_NONE, 
									NULL );

		if(hr != S_OK)
			throw(hr);

		banner(lpszProgram);	
		argument_cracker _C(argc, argv);

		if(!_C())
		{
			display_help();
			bResult = true;
		}
		else
		{

			bool bBackupPrivilegeEnabled = get_ntfs_stream_api();

			if(!enable_backup_privilege())
			{
				wchar_t szBuf[_MAX_PATH];
				wcout << load_string(IDS_NOBACKUP_PRIV_WARNING, szBuf, _MAX_PATH);
			}

			_Commander.initialize(_C.block_size(), _C.tape_partition(), _C.pattern(), bBackupPrivilegeEnabled, _C.verify());
			bResult = _Commander.wipe_file_or_directory(file_and_attributes(_C.file()));
		}
	}
	catch(long e)
	{
		SetLastError(e);
	}

	if(!bResult)
		report_bad_result();

	Sleep(5000);

	_Commander.erase();

	if(lpszProgram != (wchar_t*)0)
		delete [] lpszProgram;

	if(bCoInit)
		CoUninitialize();

	display_system_time();

	return bResult;
}

//
//  FUNCTION: control_handler ( unsigned long sig )
//
//  PURPOSE: Handled console control events
//
//  PARAMETERS:
//    dwCtrlType - type of control event
//
//  RETURN VALUE:
//    True - handled
//    False - unhandled
//
//  COMMENTS:
//
int __stdcall control_handler ( unsigned long sig )
{
	switch( sig)
    {
        case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
        case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
			wcout << L"Stopping " << lpszProgram << L"..." << endl;
			_Commander.stop();
            return 1;
            break;
		default:
			;
    }
    return 0;
}

