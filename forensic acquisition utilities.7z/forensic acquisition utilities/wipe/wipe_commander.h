// wipe_commander.h: interface and implementation of the wipe_commander class.
//
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.
#ifndef _WIPE_COMMANDER_H_
#define _WIPE_COMMANDER_H_

#include "stdafx.h"

#ifndef _FINDDATA_H_
#include "_win32_find_file.h"
#endif //_FINDDATA_H_

#ifndef _WIPER_V_1_0_H_
#include "wiper.h"
#endif //_WIPER_V_1_0_H_

LPCWSTR system_error(long lerror, LPWSTR lpBuf, unsigned long dwSize);

namespace wipe_v1_0 {

const wchar_t* __stdcall load_string(unsigned int nIDString, wchar_t* lpszBuf, int iSize)
{
	if(LoadString(GetModuleHandle(NULL), nIDString, lpszBuf, iSize) <= 0)
	{
		_RPT1(_CRT_WARN, "Error: Failed to load string ID %ld!\n", nIDString);
		return L"";
	}
	return lpszBuf;
}


class wipe_commander  : public wiper_progress,
                        private OVERLAPPED
{
public:
	wipe_commander() 
		: m_bDone(0L), m_bBackupPrivilegeEnabled(false), 
		  m_nBlockSize(4096), m_bVerify(false), m_nPartition(0), m_lPattern(0L)
	{
		Internal = (ULONG_PTR)0;
		InternalHigh = (ULONG_PTR)0;
		Offset = 0UL;
		OffsetHigh = 0UL;
		hEvent = INVALID_HANDLE_VALUE;
	}
	~wipe_commander()
	{
		erase();
	}

	bool try_wipe_file_or_directory(file_and_attributes& _F)
	{
		try
		{
			return wipe_file_or_directory(_F);
		}
		catch(long e)
		{
			SetLastError(e);
		}
		return false;
	}

	bool wipe_file_or_directory(file_and_attributes& _F)
	{
		if(m_bDone)
			return false;
		
		if(_F.is_tape_device())
			return handle_file(_F);
		else if(_F.is_shell_link() && 
			!handle_shell_link(_F))
			return false;
			
		if(m_bDone)
			return false;

		if(_F.is_mount_point() && 
			!handle_mount_point(_F))
			return false;

		if(m_bDone)
			return false;

		if(_F.is_directory())
		{
			if(!handle_directory(_F))
				return false;
		}
		else 
		{
			if(!handle_file(_F))
				return false;
		}
		return true;
	}
	inline bool initialize(size_t nBlockSize, unsigned int nTapePartition, long lPattern, bool bBackupPrivilegeEnabled, bool bVerify)
	{
		m_bBackupPrivilegeEnabled = bBackupPrivilegeEnabled;
		m_bVerify = bVerify;
		m_nBlockSize = nBlockSize;
		m_nPartition = nTapePartition;
		m_lPattern = lPattern;

		hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
		if(hEvent == INVALID_HANDLE_VALUE)
			throw((long) GetLastError());
		return true;
	}
	inline void stop()
	{
		InterlockedExchange(&m_bDone, 1L);
		if(hEvent != INVALID_HANDLE_VALUE)
			SetEvent(hEvent);
	}
	inline void erase()
	{
		if(hEvent != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hEvent);
			hEvent = INVALID_HANDLE_VALUE;
		}
	}
private:
	void display_standard_warnings(file_and_attributes& _F)
	{
		
	}
	bool prompt_readonly(file_and_attributes& _F)
	{
		using namespace std;
		wchar_t szPrompt[_MAX_PATH];
		wchar_t szYesNo[32];
		wchar_t szYy[3];

		wcout << _F.name() << L": " << system_error(ERROR_FILE_READ_ONLY, szPrompt, _MAX_PATH);

		if(!load_string(IDS_CHANGE_READONLY_PROMPT, szPrompt, _MAX_PATH))
			return false;

		if(!load_string(IDS_YESORNO, szYesNo, 32) || !load_string(IDS_Yy, szYy, 3))
			return false;
		
		if(!cmdline_prompt_yes_or_no(szPrompt, L"", szYesNo, szYy))
			return false;

		return true;
	}

	bool prompt_for_wipe(file_and_attributes& _F)
	{
		wchar_t szPrompt[_MAX_PATH];

		display_standard_warnings(_F);
		
		if(!load_string(IDS_WIPE_PROMPT, szPrompt, _MAX_PATH))
			return false;

		wchar_t szYesNo[32];
		wchar_t szYy[3];

		if(!load_string(IDS_YESORNO, szYesNo, 32) || !load_string(IDS_Yy, szYy, 3))
			return false;

		std::wstring s = _F.name();

		if((_F.is_disk_device() && 
			_F.is_physical_disk()) || _F.is_tape_device())
		{
			s += L" (";
			s += _F.manufacturer();
			s += L", ";
			s+= _F.serial_no();
			s+= L")";
		}

		if(!cmdline_prompt_yes_or_no(szPrompt, s.c_str(), szYesNo, szYy))
			return false;

		if(!load_string(IDS_WARNING_WILL_DESTROY, szPrompt, _MAX_PATH))
			return false;

		if(!cmdline_prompt_yes_or_no(szPrompt, s.c_str(), szYesNo, szYy))
			return false;

		return true;
	}

	bool wipe_file(size_t nBlockSize, file_and_attributes& _F, bool bVerify)
	{
		ResetEvent(hEvent);

		if(!_F.is_open() && !_F.open())
			return false;

		if(!_F.load())
			return false;

		if(!_F.is_locked() &&
			!_F.lock(dynamic_cast<OVERLAPPED&>(*this)))
			return false;

		if(_F.is_tape_device() &&
			!_F.rewind_tape(m_nPartition))
			throw ((long) GetLastError());

		try
		{
			
			wiper* _W = new wiper(_F, dynamic_cast<wiper_progress&>(*this), m_lPattern, bVerify, nBlockSize);
			
			ResetEvent(hEvent);
			m_bDone = 0L;

			if(!_W -> create(wiper::base_class::in_io))
				return false;

			unsigned long dwResult = WaitForSingleObject(hEvent, INFINITE);
			
			if(InterlockedCompareExchange(&m_bDone, 1L, 0L) == 0L)
			{
				// The user is requesting that we cancel the operation, 
				// probably by pressing CTRL-C

				ResetEvent(hEvent);
				
				// wait one minute for the thread to exit
				WaitForSingleObject(hEvent, 120000);
			}
		}
		catch(long e)
		{
			_RPT1(_CRT_WARN, "Catching exception in main.cpp write_file(): Last Error = %ld\n", e);
			SetLastError(e);
			return false;
		}
		catch(...)
		{
			_RPT0(_CRT_WARN, "Catching unknown exception in main.cpp write_file()!\n");
			SetLastError(E_UNEXPECTED);
			return false;
		}

		m_bDone = 0L;
		SetLastError(m_lReason);

		return (m_lReason == ERROR_SUCCESS);
	}

	bool wipe_subdirectories(size_t nBlockSize, file_and_attributes& _F, bool bVerify)
	{
		using namespace std;

		typedef _win32_find_file<_win32_find_data, _win32_find_directorynamematch<_win32_find_data> > find_type;
		typedef find_type::forward_iterator forward_iterator;

		if(m_bDone)
			return false;

		bool bResult = true;

		wstring s = _F.name();
		add_trailing_path_separator_if(s);
		s += L"*";

		find_type _Fnd(s.c_str());
		
		for(forward_iterator i = _Fnd.begin(); i != _Fnd.end(); !m_bDone, i++)
		{
			_RPT0(_CRT_WARN, "wipe_subdirectory next directory is ");
			OutputDebugString((*i).name());
			_RPT0(_CRT_WARN, "\n");
			
			wstring path = _F.name();
			path += (*i).name();
			add_trailing_path_separator_if(path);
			path += _F.search_pattern();
			
			_RPT0(_CRT_WARN, "Preparing to wipe subdirectory ");
			OutputDebugString(path.c_str());
			_RPT0(_CRT_WARN, "\n");

			if(!try_wipe_file_or_directory(file_and_attributes(path.c_str())))
				bResult = false;
		}

		return bResult;
	}

	bool wipe_directory(size_t nBlockSize, file_and_attributes& _F, bool bVerify)
	{
		using namespace std;

		typedef _win32_find_file<_win32_find_data, _win32_find_namematch_nodirectory<_win32_find_data> > find_type;
		typedef find_type::forward_iterator forward_iterator;

		if(m_bDone)
			return false;
		
		bool bResult = true;

		wstring search = _F.name();
		add_trailing_path_separator_if(search);
		search += _F.search_pattern();

		find_type _Fnd(search.c_str());

		
		for(forward_iterator i = _Fnd.begin(); i != _Fnd.end(); !m_bDone, i++)
		{
			_RPT0(_CRT_WARN, "wipe_directory next file is ");
			OutputDebugString((*i).name());
			_RPT0(_CRT_WARN, "\n");

			wstring path = _F.name();
			path += (*i).name();

			if(!try_wipe_file_or_directory(file_and_attributes(path.c_str())))
				bResult = false;
		}

		if(!wipe_subdirectories(nBlockSize, _F, bVerify))
			bResult = false;

		return bResult;
	}

	bool prompt_open_volume_instead_of_mount_point(file_and_attributes& _F)
	{
		using namespace std;
		
		wchar_t szFormat[_MAX_PATH];
		wstring szPrompt = _F.name();

		if(!load_string(IDS_MOUNT_VOLUME_REFERS, szFormat, _MAX_PATH))
			throw((long)GetLastError());

		szPrompt += szFormat;
		szPrompt += _F.volume_name();
		
		if(!load_string(IDS_MOUNT_VOLUME_PROMPT, szFormat, _MAX_PATH))
			throw((long)GetLastError());
		
		szPrompt += szFormat;

		wchar_t szYesNo[32];
		wchar_t szYy[3];

		load_string(IDS_VOLUME_OR_ROOT, szYesNo, 32);
		load_string(IDS_Vv, szYy, 3);

		return cmdline_prompt_yes_or_no(szPrompt.c_str(), L"", szYesNo, szYy);
	}

	bool prompt_open_shell_link_object_instead_of_raw_link(file_and_attributes& _F)
	{
		using namespace std;
		
		wchar_t szFormat[_MAX_PATH];
		wstring szPrompt = _F.name();

		if(!load_string(IDS_LINK_REFERS, szFormat, _MAX_PATH))
			throw((long)GetLastError());

		szPrompt += szFormat;
		szPrompt += _F.raw_link_path();
		
		if(!load_string(IDS_LINK_PATH_PROMPT, szFormat, _MAX_PATH))
			throw((long)GetLastError());
		
		szPrompt += szFormat;

		wchar_t szYesNo[32];
		wchar_t szYy[3];

		load_string(IDS_LINK_OR_OBJECT, szYesNo, 32);
		load_string(IDS_Oo, szYy, 3);

		return cmdline_prompt_yes_or_no(szPrompt.c_str(), L"", szYesNo, szYy);
	}

	bool wipe_streams(size_t block_size, file_and_attributes& _F, bool bVerify)
	{
		using namespace std;
		
		typedef _ntfs_stream_infomation::iterator iterator;

		if(!m_bBackupPrivilegeEnabled || 
			_F.is_disk_device() || 
			_F.is_tape_device())
			return true;

		if(!_F.is_open() &&
			!_F.open(true))
			return false;

		if(m_bDone)
			return false;
		
		// Retrieve an enumeration object that contains
		// stream information for the file.
		_ntfs_stream_infomation _I = _F.streams();

		long lError = GetLastError();
		if(lError != ERROR_SUCCESS || _I.empty())
		{
			// Stream information was retrieved but there are
			// no alternate streams
			if(lError == ERROR_SUCCESS)
				return true;

			// Unable to retrieve alternate stream information for this file.
			_RPT0(_CRT_WARN, "Failed to retrieve stream information for ");
			OutputDebugString(_F.name());
			_RPT1(_CRT_WARN, ": Last Error = %ld\n", lError);
			return false;
		}

		bool bResult = true;

		for(iterator i = _I.begin(); i != _I.end(); i++)
		{
			wchar_t szStream[_MAX_PATH];

			if(m_bDone)
				return false;

			// Convert the stream name length from the number of bytes 
			// to the number of characters
			size_t len = (*i).NameLength/sizeof(wchar_t);
			
			// Copy the stream name into the buffer and null terminate it.
			wcsncpy(szStream, (wchar_t*)(*i).Name, len);
			szStream[len] = L'\0';

			if(wcsnicmp(szStream, L"::$DATA", 7) == 0)
				continue;

			wstring s = _F.name();
			remove_trailing_path_separator_if(s);
			s += szStream;

			_RPT0(_CRT_WARN, "Wiping alternate stream ");
			OutputDebugString(s.c_str());
			_RPT0(_CRT_WARN, "\n");

			file_and_attributes _S(s.c_str());

			if(m_bDone)
				return false;

			// If the directory has alternate streams we need to prompt for wiping
			// since no previous prompt will have been given
			if(_F.is_directory() &&
				!prompt_for_wipe(_S))
				continue;
			if(m_bDone)
				return false;


			if(!wipe_file(block_size, _S, bVerify))
				bResult = false;
		}
		return bResult;
	}

	bool cmdline_prompt_yes_or_no(const wchar_t* lpszPrompt, const wchar_t* lpszFile, const wchar_t* lpszYesNo, const wchar_t* lpszYy)
	{
		using namespace std;		
		
		wchar_t szResponse[_MAX_PATH];

		wcout << endl << lpszPrompt;
		wcout << lpszFile;
		wcout << lpszYesNo;

		wcin.clear();

		wcin >> szResponse; 

		if(wcin.fail())
			return false;

		return (szResponse[0] == lpszYy[0] || szResponse[0] == lpszYy[1]);
	}
	bool handle_shell_link(file_and_attributes& _F)
	{
		using namespace std;

		try
		{
			if(prompt_open_shell_link_object_instead_of_raw_link(_F))
				_F.set_open_raw_link_path();	
		}
		catch(_com_error e)
		{
			wcout << e.ErrorMessage() << endl;
			return false;
		}
		return true;
	}
	inline bool handle_mount_point(file_and_attributes& _F)
	{
		if(prompt_open_volume_instead_of_mount_point(_F) &&
			! _F.set_open_volume())
			return false;
		return true;
	}
	inline bool handle_directory(file_and_attributes& _F)
	{
		using namespace std;

		bool bResult = true;

		if(!wipe_streams(m_nBlockSize, _F, m_bVerify))
		{
			wchar_t szBuf1[_MAX_PATH];
			wchar_t szBuf2[_MAX_PATH];
			wcout << load_string(IDS_NOSTREAMS_WARNING1, szBuf1, _MAX_PATH) << _F.name() << load_string(IDS_NOSTREAMS_WARNING2, szBuf2, _MAX_PATH) << endl;
			
			bResult = false;
		}
		if(!wipe_directory(m_nBlockSize, _F, m_bVerify))
			bResult = false;
		return bResult;
	}
	inline bool handle_file(file_and_attributes& _F)
	{
		using namespace std;

		bool bResult = true;

 		if(!prompt_for_wipe(_F))
		{
			SetLastError(ERROR_CANCELLED);
			return false;
		}
		
		if(_F.is_readonly())
		{
			if(prompt_readonly(_F))
			{
				if(!_F.set_read_only(false))
				{
					wchar_t szBuf[_MAX_PATH];
					wcout << _F.name() << L": " << system_error(GetLastError(), szBuf, _MAX_PATH);
					return FALSE;
				}
			}
			else
			{
				SetLastError(ERROR_FILE_READ_ONLY);
				return FALSE;
			}
		}

		if(!wipe_streams(m_nBlockSize, _F, m_bVerify))
		{
			wchar_t szBuf1[_MAX_PATH];
			wchar_t szBuf2[_MAX_PATH];
			wcout << endl << load_string(IDS_NOSTREAMS_WARNING1, szBuf1, _MAX_PATH) << _F.name() << load_string(IDS_NOSTREAMS_WARNING2, szBuf2, _MAX_PATH) << endl;

			bResult = false;
		}
		if(!wipe_file(m_nBlockSize, _F, m_bVerify))
			bResult = false;
		return bResult;
	}
	
	// wiper_progress methods
	void __stdcall wipe_phase_start(int iPhase, const file_and_attributes& _F) const
	{
/*		using namespace std;
		wchar_t* pszFill;

		switch(iPhase)
		{
		case wiper_progress::phase_writing_FF:
			pszFill = L"FF";
			break;
		case wiper_progress::phase_writing_random:
			pszFill = L"random bits";;
			break;
		case wiper_progress::phase_writing_zero:
			pszFill = L"zero";;
			break;
		default:
			_ASSERT(false);
			break;
		}

		wcout << endl << L"Preparing to write " << pszFill << L" to " << _F.name() << endl;*/
	}
	void __stdcall wipe_phase_start_allocated_range(int iPhase, const file_and_attributes& _F, const FILE_ALLOCATED_RANGE_BUFFER& rb) const
	{
		using namespace std;

		unsigned int nID;

		switch(iPhase)
		{
		case wiper_progress::phase_writing_FF:
			nID = IDS_FF_PHASE_BEGIN;
			break;
		case wiper_progress::phase_writing_random:
			nID = IDS_RANDOM_PHASE_BEGIN;
			break;
		case wiper_progress::phase_writing_zero:
			nID = IDS_ZERO_PHASE_BEGIN;
			break;
		default:
			_ASSERT(false);
			return;
		}

		wchar_t buf[_MAX_PATH];
		wchar_t szFormat[_MAX_PATH];

		if(!load_string(nID, szFormat, _MAX_PATH))
			return;

		swprintf(buf, szFormat, rb.FileOffset.QuadPart, rb.Length.QuadPart);

		wcout <<  buf << _F.name() << L":" << endl; 

	}
	void __stdcall wipe_phase_completed_allocated_range(int iPhase, const file_and_attributes& _F, const FILE_ALLOCATED_RANGE_BUFFER& rb, __int64 TotalWritten) const
	{
		/*using namespace std;

		wchar_t buf[_MAX_PATH];
		swprintf(buf, L"0x%08I64u,%I64d of ", rb.FileOffset.QuadPart, rb.Length.QuadPart);

		wchar_t* pszFill;

		switch(iPhase)
		{
		case wiper_progress::phase_writing_FF:
			pszFill = L"FF";
			break;
		case wiper_progress::phase_writing_random:
			pszFill = L"random";;
			break;
		case wiper_progress::phase_writing_zero:
			pszFill = L"zero";;
			break;
		default:
			_ASSERT(false);
			break;
		}


		wcout << L"Completed writing " << pszFill << L" bits to allocated range " << buf << _F.name() << L": "; */
	}
	void __stdcall wipe_phase_completed(int iPhase, const file_and_attributes& _F, __int64 TotalWritten, unsigned long interval) const
	{
		using namespace std;

		wchar_t buf[_MAX_PATH];
		wchar_t szFormat[_MAX_PATH];

		if(!load_string(IDS_PHASE_COMPLETE, szFormat, _MAX_PATH))
			return;

		swprintf(buf, szFormat, interval, TotalWritten);
		wcout << buf << endl;
	}
	void __stdcall wipe_verify_phase_start(int iPhase, const file_and_attributes& _F) const
	{
		using namespace std;

		wchar_t szFormat[_MAX_PATH];

		if(!load_string(IDS_VERIFYING, szFormat, _MAX_PATH))
			return;

		wcout << szFormat;		
	}
	virtual void __stdcall wipe_verify_phase_completed(int iPhase, const file_and_attributes& _F, bool bResult) const
	{
		using namespace std;

		wchar_t szFormat[_MAX_PATH];

		if(!load_string((bResult)? IDS_OK : IDS_FAILED, szFormat, _MAX_PATH))
			return;

		wcout << szFormat << endl;		
	}
	void __stdcall wipe_progress(int iPhase, const file_and_attributes& _F, const FILE_ALLOCATED_RANGE_BUFFER& rb, __int64 TotalWritten) const
	{

	}
	void __stdcall wipe_result(const file_and_attributes& _F, long lReason) const
	{
		InterlockedExchange(&m_lReason, lReason);
	}
	long __stdcall wipe_done() const
	{
		return InterlockedCompareExchange(&m_bDone, 1L, 1L);
	}
	void __stdcall wipe_complete() const
	{
		InterlockedExchange(&m_bDone, 1L);
		if(hEvent != INVALID_HANDLE_VALUE)
			SetEvent(hEvent);
	}

	mutable long m_bDone;
	mutable long m_lReason;
	size_t m_nBlockSize;
	unsigned int m_nPartition;
	long m_lPattern;
	bool m_bBackupPrivilegeEnabled;
	bool m_bVerify;
};	

} //namespace wipe_v1_0 

#endif //_WIPE_COMMANDER_H_