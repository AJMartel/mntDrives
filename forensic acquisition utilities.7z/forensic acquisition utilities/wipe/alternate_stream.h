// alternate_stream.h: interface and implementation of the alternate_stream class.
//
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#ifndef _ALTERNATE_STREAM_H_
#define _ALTERNATE_STREAM_H_

#include "stdafx.h"

#ifndef _UTILITY_
#include <utility>
#endif //_UTILITY_

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

//
// return code type
//
typedef INT NTSTATUS;

//
// Check for success
//
#define NT_SUCCESS(Status) ((NTSTATUS)(Status) >= 0)

//
// The NT return codes we care about
//
#define STATUS_BUFFER_OVERFLOW           ((NTSTATUS)0x80000005L)

//
// Io Status block (see NTDDK.H)
//

// from ntddk.h
typedef struct _IO_STATUS_BLOCK {
    union {
        NTSTATUS Status;
        PVOID Pointer;
    };

    ULONG_PTR Information;
} IO_STATUS_BLOCK, *PIO_STATUS_BLOCK;

#if defined(_WIN64)
typedef struct _IO_STATUS_BLOCK32 {
    NTSTATUS Status;
    ULONG Information;
} IO_STATUS_BLOCK32, *PIO_STATUS_BLOCK32;
#endif


//
// Define an Asynchronous Procedure Call from I/O viewpoint
//

typedef
VOID
(NTAPI *PIO_APC_ROUTINE) (
    IN PVOID ApcContext,
    IN PIO_STATUS_BLOCK IoStatusBlock,
    IN ULONG Reserved
    );
#define PIO_APC_ROUTINE_DEFINED

typedef enum _FILE_INFORMATION_CLASS {
    FileStreamInformation = 22,
} FILE_INFORMATION_CLASS, *PFILE_INFORMATION_CLASS;

//
// Streams information
//
#pragma pack(4)
typedef struct {
	ULONG    	        NextEntry;
	ULONG    	        NameLength;
	LARGE_INTEGER    	Size;
	LARGE_INTEGER    	AllocationSize;
	USHORT    	        Name[1];
} FILE_STREAM_INFORMATION, *PFILE_STREAM_INFORMATION;
#pragma pack()

//
// Native functions we use
//
typedef NTSTATUS (__stdcall *NTQUERYINFORMATIONFILE)( 
    IN HANDLE FileHandle,
    OUT PIO_STATUS_BLOCK IoStatusBlock,
    OUT PVOID FileInformation,
    IN ULONG Length,
    IN FILE_INFORMATION_CLASS FileInformationClass
    );

typedef ULONG (__stdcall *RTLNTSTATUSTODOSERROR) (
		IN NTSTATUS Status
		);

#ifdef __cplusplus
}
#endif //__cplusplus

namespace wipe_v1_0 {

class _ntfs_stream_infomation 
{
public:
	typedef _ntfs_stream_infomation& reference;
	typedef const _ntfs_stream_infomation& const_reference;

	class iterator 
		: public std::iterator<std::forward_iterator_tag, PFILE_STREAM_INFORMATION, size_t>
	{
	public:
		friend bool operator==(const iterator& _It1, const iterator _It2);
		friend bool operator!=(const iterator& _It1, const iterator _It2);

		inline iterator(PFILE_STREAM_INFORMATION _I, size_t _S) 
			: m_pNext(_I), 
			  m_pEnd(reinterpret_cast<PFILE_STREAM_INFORMATION>((reinterpret_cast<unsigned char*>(m_pNext) + _S)))
		{
		}
		inline const FILE_STREAM_INFORMATION& operator*() const
		{
			return *m_pNext;
		}
		inline iterator& operator++(int)
		{
			if(m_pNext -> NextEntry == 0UL)
			{
				m_pNext = m_pEnd;
			}
			else
			{
				unsigned char* p = reinterpret_cast<unsigned char*>(m_pNext);
				p += m_pNext -> NextEntry;
				m_pNext = reinterpret_cast<PFILE_STREAM_INFORMATION>(p);
			}

			_ASSERTE(m_pNext <= m_pEnd);

			return *this;
		}
	private:
		PFILE_STREAM_INFORMATION m_pNext;
		const PFILE_STREAM_INFORMATION m_pEnd;
	};

	inline _ntfs_stream_infomation() 
		: m_pInfo((PFILE_STREAM_INFORMATION)0), m_size(0), m_bOwns(false)
	{
	}
	inline _ntfs_stream_infomation(PFILE_STREAM_INFORMATION _I, size_t _S) 
		: m_pInfo(_I), m_size(_S), m_bOwns(true)
	{
	}
	inline _ntfs_stream_infomation(const_reference _I) : m_size(_I.m_size)
	{
		m_bOwns = _I.m_bOwns;
		m_pInfo = _I.release();
	}
	inline ~_ntfs_stream_infomation() 
	{
		if(m_bOwns)
		{
			if(m_pInfo != (PFILE_STREAM_INFORMATION)0)
			{
				delete [] reinterpret_cast<unsigned char*>(m_pInfo);
				m_pInfo = (PFILE_STREAM_INFORMATION)0;
			}
			m_bOwns = false;
		}
	}

	inline iterator begin() const
	{
		return iterator(m_pInfo, m_size);
	}
	inline iterator end() const
	{
		return iterator(reinterpret_cast<PFILE_STREAM_INFORMATION>((reinterpret_cast<unsigned char*>(m_pInfo) + m_size)), 0);
	}
	inline PFILE_STREAM_INFORMATION release() const
	{
		if(m_bOwns)
			m_bOwns = false;
		return m_pInfo;
	}
	inline bool empty() const
	{
		return (m_pInfo == 	(PFILE_STREAM_INFORMATION)0);	
	}
	inline reference operator=(const_reference _I)
	{	
		m_size = _I.m_size;
		m_bOwns = _I.m_bOwns;
		m_pInfo = _I.release();
		return *this;
	}
	static FILE_INFORMATION_CLASS information_class()
	{
		return FileStreamInformation;
	}
private:
	PFILE_STREAM_INFORMATION m_pInfo;
	size_t m_size;
	mutable bool m_bOwns;
};

bool operator==(const _ntfs_stream_infomation::iterator& _It1, const _ntfs_stream_infomation::iterator _It2)
{
	return (_It1.m_pNext == _It2.m_pNext);
}

bool operator!=(const _ntfs_stream_infomation::iterator& _It1, const _ntfs_stream_infomation::iterator _It2)
{
	return !operator==(_It1, _It2);
}

} //namespace wipe_v1_0

#endif //_ALTERNATE_STREAM_H_