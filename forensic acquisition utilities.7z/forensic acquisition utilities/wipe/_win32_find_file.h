// _win32_find_file.h: interface and implementation of the _win32_find_file class.
//
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#ifndef _FINDDATA_H_
#define _FINDDATA_H_

#include "stdafx.h"

namespace wipe_v1_0 {

class _win32_find_data : private WIN32_FIND_DATAW
{
public:
	typedef wchar_t char_type;
	typedef _win32_find_data& reference;
	typedef const _win32_find_data& const_reference;

	// construction
	inline _win32_find_data()
	{
		memset((LPWIN32_FIND_DATAW)this, 0, sizeof(WIN32_FIND_DATAW));
	}
	inline _win32_find_data(const_reference _F)
	{
		memcpy((LPWIN32_FIND_DATAW)(*this), 
				(LPWIN32_FIND_DATAW)_F, 
				sizeof(WIN32_FIND_DATAW));
	}
	// attributes
	inline unsigned long attributes() const
	{	
		return dwFileAttributes;	
	}
	inline __int64 creation() const
	{	
		return (ftCreationTime.dwLowDateTime | (ftCreationTime.dwHighDateTime << 0x20));	
	}
	inline __int64 last_access() const
	{	
		return (ftLastAccessTime.dwLowDateTime | (ftLastAccessTime.dwHighDateTime << 0x20));	
	}
	inline __int64 last_write() const
	{	
		return (ftLastWriteTime.dwLowDateTime | (ftLastWriteTime.dwHighDateTime << 0x20));	
	}
	inline __int64 size() const
	{	
		return (nFileSizeLow | (nFileSizeHigh << 0x20));	
	}
	inline const char_type* name() const
	{	
		return cFileName;	
	}
	inline const char_type* alternate_name() const
	{	
		return cAlternateFileName;	
	} 

	// operators
	inline reference operator=(const_reference _F)
	{
		memcpy((LPWIN32_FIND_DATAW)(*this), 
				(LPWIN32_FIND_DATAW)_F, 
				sizeof(WIN32_FIND_DATAW));

		return *this;
	}
	inline operator LPWIN32_FIND_DATA() const
	{
		return (LPWIN32_FIND_DATA)this;
	}
	static FINDEX_INFO_LEVELS info_level()
	{
		return FindExInfoStandard;
	}

};

template<class FIND_DATA_TYPE = _win32_find_data>
class _win32_find_namematch
{
public:
	typedef FIND_DATA_TYPE find_data_type;
	typedef _win32_find_namematch<find_data_type> filter_type;
	typedef filter_type& reference;
	typedef const filter_type const_reference;

	inline bool operator()(const find_data_type& _Fd) const
	{
		if(wcsnicmp(_Fd.name(), L".", 2) == 0 ||
			wcsnicmp(_Fd.name(), L"..", 3) == 0 || 
			_Fd.name()[0] == L'\0')
			return false;
		return true;
	}
	inline FINDEX_SEARCH_OPS search_opts() const
	{
		return FindExSearchNameMatch;
	}
	inline reference operator=(const_reference Flt)
	{
		return *this;
	}
};

template<class FIND_DATA_TYPE = _win32_find_data>
class _win32_find_namematch_nodirectory : public _win32_find_namematch<FIND_DATA_TYPE>
{
public:
	typedef _win32_find_namematch<FIND_DATA_TYPE> base_type;

	inline bool operator()(const find_data_type& _Fd) const
	{
		if(_Fd.attributes() & FILE_ATTRIBUTE_DIRECTORY)
			return false;
		return base_type::operator()(_Fd);
	}

};

template<class FIND_DATA_TYPE = _win32_find_data>
class _win32_find_directorynamematch
{
public:
	typedef FIND_DATA_TYPE find_data_type;
	typedef _win32_find_directorynamematch<find_data_type> filter_type;
	typedef filter_type& reference;
	typedef const filter_type const_reference;

	inline bool operator()(const find_data_type& _Fd) const
	{
		if(!(_Fd.attributes() & FILE_ATTRIBUTE_DIRECTORY))
			return false;
		else if(wcsnicmp(_Fd.name(), L".", 2) == 0 ||
			wcsnicmp(_Fd.name(), L"..", 3) == 0)
			return false;
		return true;
	}
	inline FINDEX_SEARCH_OPS search_opts() const
	{
		return FindExSearchLimitToDirectories;
	}
	inline reference operator=(const_reference Flt)
	{
		return *this;
	}
};

template<class FIND_DATA_TYPE = _win32_find_data, 
         class FILTER_TYPE = _win32_find_namematch<FIND_DATA_TYPE> >
class _win32_find_file
{
public:
	typedef wchar_t char_type;
	typedef FIND_DATA_TYPE find_data_type;
	typedef FILTER_TYPE filter_type;
	typedef _win32_find_file<find_data_type, filter_type> find_type;
	typedef const find_type* const_pointer;
	typedef const find_type& const_reference;

	class forward_iterator
		: public std::iterator<std::forward_iterator_tag, FIND_DATA_TYPE, size_t>
	{
	public:
		typedef forward_iterator iterator_type;
		typedef iterator_type& reference;
		typedef const iterator_type& const_reference;

		//friend bool operator!=(const_reference _It1, const_reference _It2);

		//construction
		forward_iterator(const filter_type& _Flt = filter_type())
			: m_hFind((HANDLE)0), m_iPos(0), m_bOwns(false), m_Flt(_Flt)
		{
		}
		forward_iterator(const char_type* lpszSearch, const filter_type& _Flt) 
			: m_hFind((HANDLE)0), m_iPos(0), m_bOwns(false), m_Flt(_Flt)
		{
			_ASSERTE(lpszSearch != (const wchar_t*)0);
			if((m_hFind = ::FindFirstFileExW(lpszSearch, 
				                             find_data_type::info_level(), 
											 (LPWIN32_FIND_DATA)m_find_data, 
											 _Flt.search_opts(), 
											 NULL, 
											 0UL)) != (HANDLE)0)
			{
				m_iPos = 1;
				m_bOwns = true;
				
				if(!m_Flt(m_find_data))
					(*this)++;
			}
		}
		inline forward_iterator(const_reference _It) 
			: m_find_data(_It.m_find_data), m_Flt(_It.m_Flt)
		{	
			m_iPos = _It.m_iPos;
			m_bOwns = _It.m_bOwns;
			m_hFind = _It.release();
		}

		//destruction
		inline ~forward_iterator()
		{
			erase();	
		}
		inline void erase()
		{
			if(m_hFind != (HANDLE)0)
			{
				if(m_bOwns)
					::FindClose(m_hFind);
				m_hFind = (HANDLE)0;
			}
			m_iPos = 0;
			m_bOwns = false;
		}

		//attribute
		inline HANDLE release() const
		{
			if(m_bOwns)
				m_bOwns = false;
			m_iPos = 0;
			return m_hFind;
		}

		// operators
		inline reference operator=(const_reference _It) 
		{
			if(m_hFind && m_hFind != _It.m_hFind)
				erase();
			m_bOwns = _It.m_bOwns;
			m_iPos = _It.m_iPos;
			m_hFind = _It.release();
			m_find_data = _It.m_find_data;
			return *this;
		}
		inline find_data_type operator*()
		{	
			return m_find_data;	
		}
		inline const_reference operator++(int)
		{
			_ASSERTE(m_hFind != (HANDLE)0);

			// Repetively call FindNextFileW until the filter returns true
			// or the call to FindNextFileW fails.
			do {

				m_iPos = ::FindNextFileW(m_hFind, m_find_data);

			} while(m_iPos && !m_Flt(m_find_data));

			return *this;
		}
		inline bool operator==(const_reference _It) const
		{
			return (m_iPos == _It.m_iPos);
		}
		inline bool operator!=(const_reference _It) const
		{
			return !operator==(_It);
		}
	private:
		//attributes
		HANDLE m_hFind;
		mutable int m_iPos;
		find_data_type m_find_data;
		const filter_type& m_Flt;
		mutable bool m_bOwns;
	};

	typedef forward_iterator& iterator;
	typedef const forward_iterator& const_iterator;

	//constructor
	inline _win32_find_file(const char_type* lpszSearch, const filter_type& _Flt = filter_type()) 
			: m_pszSearch(lpszSearch), m_Flt(_Flt)
	{
		_ASSERTE(lpszSearch != (const char_type*)0);	
		_RPT0(_CRT_WARN, "Constructing search handle to search for pattern ");
		OutputDebugString(m_pszSearch);
		_RPT0(_CRT_WARN, "\n");
	}

	//attributes
	inline const_iterator begin()
	{
		m_search = forward_iterator(m_pszSearch, m_Flt);
		return m_search;
	}
	inline const_iterator end() const
	{	
		return m_end;	
	}
private:
	//attributes
	const char_type* m_pszSearch;
	forward_iterator m_search;
	const filter_type m_Flt;
	const forward_iterator m_end;
};

/*template<class FIND_DATA_TYPE, class FILTER_TYPE>
inline bool operator==(_win32_find_file<FIND_DATA_TYPE, FILTER_TYPE>::forward_iterator::const_reference _It1, 
					   _win32_find_file<FIND_DATA_TYPE, FILTER_TYPE>::forward_iterator::const_reference _It2)
{
	return _It1.m_iPos == _It2.m_iPos;
}
template<class FIND_DATA_TYPE, class FILTER_TYPE>
inline bool operator!=(_win32_find_file<FIND_DATA_TYPE, FILTER_TYPE>::forward_iterator::const_reference _It1, 
					   _win32_find_file<FIND_DATA_TYPE, FILTER_TYPE>::forward_iterator::const_reference _It2)
{
	return !operator==(_It1, _It2);
}*/

} //namespace wipe_v1_0

#endif //_FINDDATA_H_