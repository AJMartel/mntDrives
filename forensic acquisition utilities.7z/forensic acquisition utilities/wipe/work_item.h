// work_item.h: interface and implementation of the work_item class.
//
/////////////////////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#ifndef _WORK_ITEM_V_1_0_H_
#define _WORK_ITEM_V_1_0_H_

#include "stdafx.h"

#if !defined(_INC_PROCESS)
#include <process.h>
#endif // _INC_PROCESS

#ifndef _OS_HANDLE_T_H_
#include "os_handle_t.h"
#endif //_OS_HANDLE_T_H_

// from mtdll.h

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

struct _tiddata {
        unsigned long   _tid;       /* thread ID */
        uintptr_t _thandle;         /* thread handle */
};
typedef struct _tiddata * _ptiddata;
_ptiddata __cdecl _getptd(void);  /* return address of per-thread CRT data */
void __cdecl _freeptd(_ptiddata); /* free up a per-thread CRT data block */

#ifdef __cplusplus
}
#endif //__cplusplus

namespace wipe_v1_0 {

inline bool isvalid_pointer(const void* lp, std::allocator<void*>::size_type len, bool bWrite = true)
{
	return (lp != (void*) 0 && !::IsBadReadPtr(lp, (unsigned int) len) &&
		(!bWrite || !::IsBadWritePtr(const_cast<void*>(lp), len)));
}

template<class _TYPE>
class work_item
{
public:
	typedef _TYPE derived_type;
	typedef std::allocator<derived_type> allocator_type;
	typedef allocator_type::size_type size_type;
	typedef derived_type* pointer;
	typedef const derived_type* const_pointer;
	typedef work_item<derived_type>& reference;
	typedef const work_item<derived_type>& const_reference;

	enum { _default = WT_EXECUTEDEFAULT,
		in_io = WT_EXECUTEINIOTHREAD,
		in_persistent_io = WT_EXECUTEINPERSISTENTIOTHREAD,
		long_function = WT_EXECUTELONGFUNCTION,
	};

	inline work_item(bool bAutoDelete = true)
		: m_dwThreadId(0UL),
		  m_bExitThread(false),
		  m_bAutoDelete(bAutoDelete)
	{ 	
	}
	inline ~work_item()
	{	
		pointer pThis = (pointer)this;
		pThis->cleanup();	
	}
	inline bool create(unsigned long dwFlags = _default)
	{
		return (::QueueUserWorkItem((LPTHREAD_START_ROUTINE)entry_point, 
								   (void*)static_cast<pointer>(this), 
								   dwFlags) == TRUE);
	}
	inline bool initialize()
	{
		m_dwThreadId = ::GetCurrentThreadId();
		return true;
	}
	inline void cleanup()
	{
	}
	inline unsigned long suspend()
	{
		os_handle_t hThread = ::OpenThread(THREAD_SUSPEND_RESUME, false, m_dwThreadId);
		return ::SuspendThread(hThread);
	}
	inline unsigned long resume()
	{
		os_handle_t hThread = ::OpenThread(THREAD_SUSPEND_RESUME, false, m_dwThreadId);
		return ::ResumeThread(hThread);
	}
    inline long shutdown()
	{	
		::InterlockedExchange(&m_bExitThread, (long)true); return 0L;	
	}
	inline unsigned long thread_id() const
	{	
		return m_dwThreadId; 
	}
	inline bool done() const
	{ 
		return m_bExitThread != 0L;	
	}
	inline bool auto_delete() const
	{	
		return m_bAutoDelete;	
	}
	inline bool set_priority(size_type iPriority = THREAD_PRIORITY_NORMAL)
	{
		os_handle_t hThread = ::OpenThread(THREAD_SET_INFORMATION, false, m_dwThreadId);
		return ::SetThreadPriority(hThread, (int)iPriority);
	}
	inline size_type priority()
	{	
		os_handle_t hThread = ::OpenThread(THREAD_QUERY_INFORMATION , false, m_dwThreadId);
		return ::GetThreadPriority(hThread);	
	}
	os_handle_t os_handle(unsigned long dwAccess = THREAD_ALL_ACCESS) const
	{
		return ::OpenThread(dwAccess , false, m_dwThreadId);
	}
private:
	// operations
	// implementation of thread entry point shared by all
	// 	work_item derived classes.
	static unsigned long __stdcall entry_point(pointer lpContext)
	{
			// lpParam is actually the 'this' pointer
		_ASSERTE(isvalid_pointer(lpContext, sizeof(derived_type)));

		unsigned long dwResult = run_thread(lpContext);

		// delete must not throw an exception
		if(lpContext -> auto_delete())
			delete lpContext;
			
		_ptiddata ptd = _getptd();

		if(ptd != (_ptiddata)0)
		{
			/*
			* Close the thread handle (if there was one)
			*/
			if ( ptd->_thandle != (uintptr_t)(-1) )
					(void) CloseHandle( (HANDLE)(ptd->_thandle) );

			/*
			* Free up the _tiddata structure & its subordinate buffers
			*      _freeptd() will also clear the value for this thread
			*      of the TLS variable __tlsindex.
			*/
			_freeptd(ptd);
			
		}

		return (unsigned int) dwResult;
	}
	static unsigned long __stdcall run_thread(pointer lpContext)
	{
		unsigned long dwResult = 0UL;

		try
		{
			if(!lpContext->initialize())
				return E_UNEXPECTED;

			lpContext->run();	// run it
	
			_ASSERTE(isvalid_pointer(lpContext, sizeof(derived_type)));
			lpContext->cleanup();
		}
		catch(std::exception& e)
		{
			_RPT2(_CRT_WARN, "Catching exception of type %s in work_item<>::entry_point!\n"
					   "     %s!", typeid(e).name(), e.what());
			_ASSERT(false);
			dwResult = E_UNEXPECTED;
		}
		catch(long e)
		{
			_RPT1(_CRT_WARN, "Catching exception in work_item<>::entry_point: Error = %ld\n", e);
			_ASSERT(false);
			dwResult = e;
		}
		catch(...)
		{
			_RPT0(_CRT_WARN, "Catching unknown exception in work_item<>::entry_point!\n");
			dwResult = E_UNEXPECTED;
			_ASSERT(false);
		}

		return dwResult;
	}
private:
	// attributes
	unsigned long m_dwThreadId;
	long m_bExitThread;
	bool m_bAutoDelete;
};

}

#endif //_WORK_ITEM_V_1_0_H_