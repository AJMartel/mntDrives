// wiper.h: interface and implementation of the wiper class.
//
/////////////////////////////////////////////////////////////////////////////////
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#ifndef _WIPER_V_1_0_H_
#define _WIPER_V_1_0_H_

#include "stdafx.h"

#ifndef _STRING_
#include <string>
#endif //_STRING_

#ifndef _VECTOR_
#include <vector>
#endif // _VECTOR_

#ifndef __WINCRYPT_H__
#include <wincrypt.h>
#endif // __WINCRYPT_H__

#ifndef _SHLGUID_H_
#include <shlguid.h>
#endif // _SHLGUID_H_

#include <shobjidl.h>

#if !defined(_INC_COMDEF)
#include <comdef.h>
#endif //_INC_COMDEF

#ifndef _INC_LIMITS
#include <limits.h>
#endif //_INC_LIMITS

#ifndef _WORK_ITEM_V_1_0_H_
#include "work_item.h"
#endif //_WORK_ITEM_V_1_0_H_

#ifndef _OS_VERSION_H_
#include "osversion.h"
#endif //_OS_VERSION_H_

#ifndef _ALTERNATE_STREAM_H_
#include "alternate_stream.h"
#endif //_ALTERNATE_STREAM_H_

#ifndef _INC_SETUPAPI
#include <Setupapi.h>
#endif // _INC_SETUPAPI

#define FILESYSNAMEBUFSIZE 1024
#define DEFAULT_SECTOR_SIZE 512

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

// From ntddstor.h
typedef enum _STORAGE_PROPERTY_ID {
    StorageDeviceProperty = 0,
    StorageAdapterProperty,
    StorageDeviceIdProperty
} STORAGE_PROPERTY_ID, *PSTORAGE_PROPERTY_ID;

typedef enum _STORAGE_QUERY_TYPE {
    PropertyStandardQuery = 0,          // Retrieves the descriptor
    PropertyExistsQuery,                // Used to test whether the descriptor is supported
    PropertyMaskQuery,                  // Used to retrieve a mask of writeable fields in the descriptor
    PropertyQueryMaxDefined     // use to validate the value
} STORAGE_QUERY_TYPE, *PSTORAGE_QUERY_TYPE;

typedef struct _STORAGE_PROPERTY_QUERY {

    STORAGE_PROPERTY_ID PropertyId;
    STORAGE_QUERY_TYPE QueryType;
    UCHAR AdditionalParameters[1];

} STORAGE_PROPERTY_QUERY, *PSTORAGE_PROPERTY_QUERY;

typedef struct _STORAGE_DESCRIPTOR_HEADER {
    ULONG Version;
    ULONG Size;
} STORAGE_DESCRIPTOR_HEADER, *PSTORAGE_DESCRIPTOR_HEADER;

typedef struct _STORAGE_DEVICE_DESCRIPTOR {
    ULONG Version;
    ULONG Size;
    UCHAR DeviceType;
    UCHAR DeviceTypeModifier;
    BOOLEAN RemovableMedia;
    BOOLEAN CommandQueueing;
    ULONG VendorIdOffset;
    ULONG ProductIdOffset;
    ULONG ProductRevisionOffset;
    ULONG SerialNumberOffset;
    STORAGE_BUS_TYPE BusType;
    ULONG RawPropertiesLength;
    UCHAR RawDeviceProperties[1];
} STORAGE_DEVICE_DESCRIPTOR, *PSTORAGE_DEVICE_DESCRIPTOR;

#define IOCTL_STORAGE_QUERY_PROPERTY   CTL_CODE(IOCTL_STORAGE_BASE, 0x0500, METHOD_BUFFERED, FILE_ANY_ACCESS)

#ifdef __cplusplus
}  // extern "C"
#endif // __cplusplus

namespace wipe_v1_0 {

inline bool check_for_wildcards(const std::wstring& _S)
{
	using namespace std;

	// Look for a wildcard ('*' or '?' in the path.
	// Technically, this will return true for an invalid
	// path that contains a wildcard outside of the file name
	// or extension.  However, this results in a harmless error.
	return (_S.find(L'*') != wstring::npos ||
		_S.find(L'?') != wstring::npos);
}

inline 	void add_trailing_path_separator_if(std::wstring& _S)
{
	using namespace std;

	typedef wstring::iterator iterator;

	if(_S.empty())
		return;

	iterator i = _S.end();
	
	if(i == _S.begin())
		throw(ERROR_INVALID_PARAMETER);

	if(*--i != L'\\' && *i != L'/')
	{
		//Both forward and backslashes are legitimate
		// path separators.  Try to figure out which type
		// of separator is being used and add that separator
		// to the end of the string.  Default to adding 
		// a backslash as a separator.

		if(_S.find(L'/') != wstring::npos)
			_S += L'/';
		else
			_S += L'\\';
	}
}

inline 	void remove_trailing_path_separator_if(std::wstring& _S)
{
	using namespace std;

	typedef wstring::iterator iterator;

	if(_S.empty())
		return;

	iterator i = _S.end();
	
	if(i == _S.begin())
		throw(ERROR_INVALID_PARAMETER);

	if(*--i == L'\\' || *i == L'/')
		_S.erase(i);
}

class _file_attributes 
{
public:
	inline explicit _file_attributes(unsigned long _A = 0UL) : m_dwAttributes(_A)
	{
	}
	inline _file_attributes(const _file_attributes& _A) : m_dwAttributes(_A.m_dwAttributes)
	{
	}
	inline _file_attributes& operator=(const _file_attributes& _A)
	{
		m_dwAttributes = _A.m_dwAttributes;
		return *this;
	}

	inline bool compressed() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_COMPRESSED) != 0UL;
	}
	inline bool directory() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0UL;
	}
	inline bool offline() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_OFFLINE) != 0UL;
	}
	inline bool readonly() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_READONLY) != 0UL;
	}
	inline bool set_read_only(bool bOn)
	{
		if(bOn)
			m_dwAttributes |= FILE_ATTRIBUTE_READONLY;
		else
			m_dwAttributes &= ~(FILE_ATTRIBUTE_READONLY);
		return true;
	}
	inline bool reparse_point() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_REPARSE_POINT) != 0UL;
	}
	inline bool sparse() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_SPARSE_FILE) != 0UL;
	}
	inline bool system_file() const
	{
		return (m_dwAttributes & FILE_ATTRIBUTE_SYSTEM) != 0UL;
	}
	inline bool empty() const
	{
		return (m_dwAttributes == 0UL);
	}
	inline _file_attributes& operator &= (unsigned long mask)
	{
		m_dwAttributes &= mask;
		return *this;
	}
	inline _file_attributes& operator |= (unsigned long mask)
	{
		m_dwAttributes |= mask;
		return *this;
	}
	inline operator unsigned long() const
	{
		return m_dwAttributes;
	}
	friend bool operator == (const _file_attributes& _A, unsigned long val);
private:
	unsigned long m_dwAttributes;
};

inline bool operator == (const _file_attributes& _A, unsigned long val)
{
	return (_A.m_dwAttributes == val);
}

class file_and_attributes
{
public:
	bool m_bReparsePoint;
	file_and_attributes(const wchar_t* file) 
		: m_szFile((file != (wchar_t*)0)? file : L""), 
		  m_szManufacturer((file != (wchar_t*)0)? file : L""),
		  m_szSerialNo((file != (wchar_t*)0)? file : L""),
		  m_hFile(INVALID_HANDLE_VALUE), m_dwVolumeFlags(0UL),
		  m_bDiskDevice(false), m_bTapeDevice(false), m_bLocked(false), m_bOwns(false),
		  m_bMountPoint(false), m_bReparsePoint(false),
		  m_szOther(L"")
	{
		initialize();
	}
	file_and_attributes(const file_and_attributes& _F) 
		: m_szFile(_F.m_szFile), m_szManufacturer(_F.m_szManufacturer), 
		  m_szSerialNo(_F.m_szSerialNo), m_Attributes(_F.m_Attributes), 
		  m_bDiskDevice(_F.m_bDiskDevice), m_bTapeDevice(_F.m_bTapeDevice), m_bLocked(_F.m_bLocked),
		  m_bMountPoint(_F.m_bMountPoint), m_dwVolumeFlags(_F.m_dwVolumeFlags),
		  m_bReparsePoint(_F.m_bReparsePoint),m_szOther(_F.m_szOther)
	{
		m_bOwns = _F.m_bOwns;
		m_hFile = _F.release();
	}
	~file_and_attributes()
	{
		close();		
		m_szFile.empty();
	}
	
	// attributes
	inline bool is_open() const
	{
		return(m_hFile != INVALID_HANDLE_VALUE);
	}
	inline bool is_disk_device() const
	{
		return m_bDiskDevice;
	}
	inline bool is_tape_device() const
	{
		return m_bTapeDevice;
	}
	inline bool is_physical_disk() const
	{
		return (wcsnicmp(m_szFile.c_str(), L"\\\\.\\PhysicalDrive", 17) == 0); 
	}
	inline bool is_mount_point() const
	{
		return m_bMountPoint;
	}
	inline bool is_shell_link() const
	{
		// This is rather a crude way of determining if a file is
		// a shell link, but it appears to be the method that the
		// shell uses.
		wchar_t szExt[_MAX_EXT];
		_wsplitpath(m_szFile.c_str(), NULL, NULL, NULL, szExt);

		if(wcsnicmp(szExt, L".LNK", 5) == 0)
			return true;

		return false;
	}
	inline bool is_locked() const
	{
		return m_bLocked;
	}
	inline bool is_compressed() const
	{
		return m_Attributes.compressed();
	}
	inline bool is_directory() const
	{
		return m_Attributes.directory();
	}
	inline bool is_offline() const
	{
		return m_Attributes.offline();
	}
	inline bool is_readonly() const
	{
		return m_Attributes.readonly();
	}
	inline bool is_reparse_point() const
	{
		return m_Attributes.reparse_point();
	}
	inline bool is_sparse() const
	{
		return m_Attributes.sparse();
	}
	inline bool is_system_file() const
	{
		return m_Attributes.system_file();
	}
	inline const wchar_t* name() const
	{
		return m_szFile.c_str();
	}
	inline const wchar_t* volume_name() const
	{
		return m_szOther.c_str();
	}
	inline const wchar_t* manufacturer() const
	{
		return m_szManufacturer.c_str();
	}
	inline const wchar_t* serial_no() const
	{
		return m_szSerialNo.c_str();
	}
	inline const wchar_t* raw_link_path()
	{
		if(!resolve_link())
			return L"";
		return m_szOther.c_str();
	}
	inline const wchar_t* search_pattern() const
	{
		return m_szOther.c_str();
	}
	inline bool has_secure_erase() const
	{
		if(!is_tape_device())
			return false;

		unsigned long dwSize = sizeof(TAPE_GET_DRIVE_PARAMETERS);

		TAPE_GET_DRIVE_PARAMETERS dp;
		
		unsigned long dwResult = GetTapeParameters(m_hFile,
			                                       GET_TAPE_DRIVE_INFORMATION,
												   &dwSize,
												   &dp);

		if(dwResult != NO_ERROR)
		{
			_RPT1(_CRT_WARN, "Failed to get tape drive information! Last Error = %ld\n", dwResult);
			throw((long) dwResult);
		}

		
		return (dp.FeaturesLow & TAPE_DRIVE_ERASE_LONG) != 0;
	}
	__int64 size(OVERLAPPED& ov)
	{
		_ASSERTE(is_open());

		if(!is_open())
			return false;

		if(is_disk_device())
			return volume_size(ov);
		else if(is_tape_device())
			return tape_size();
		else if(!is_directory())
			return file_size();
		
		// Not reached.
		_ASSERT(false);
		return (__int64)-1;
	}
	inline bool set_read_only(bool bOn)
	{
		if(m_Attributes.set_read_only(bOn) &&
			::SetFileAttributesW(name(), m_Attributes))
			return true;
		return false;
	}
	bool allocated_ranges(std::vector<FILE_ALLOCATED_RANGE_BUFFER>& _AR, OVERLAPPED& ov)
	{
		_ASSERTE(is_open());

		// guard against redundant calls to this function
		if(!_AR.empty())
			_AR.erase(_AR.begin(), _AR.end());
		
		FILE_ALLOCATED_RANGE_BUFFER rb;

		if(m_bDiskDevice)
		{
			// Disk drives may report their size inaccurately
			// so don't rely on purported disk size.  Write until
			// you can't write anymore.
			rb.FileOffset.QuadPart = (__int64) 0;
			rb.Length.QuadPart = _I64_MAX;
			_AR.push_back(rb);
			return true;
		}
		else if(m_bTapeDevice)
		{
			rb.FileOffset.QuadPart = (__int64) 0;

		}

		__int64 _S = size(ov);
		if(_S < (__int64)0)
			return false;


		// If the file is not sparse then the entire file contains meaningful data
		if(!is_sparse())
		{
			rb.FileOffset.QuadPart = (__int64) 0;
			rb.Length.QuadPart = _S;
			_AR.push_back(rb);
			return true;
		}

		FILE_ALLOCATED_RANGE_BUFFER sr;

		// Start searching at the beginning of the file
		sr.FileOffset.QuadPart = (__int64) 0;

		// Search the whole file.
		sr.Length.QuadPart = _S;

		
		while(sr.Length.QuadPart > (__int64)0 && // do not search zero length files or beyond EOF
			query_allocated_range(sr, rb, ov))     
		{
			_AR.push_back(rb);

			// Calculate the region covered by last query
			__int64 inc = rb.FileOffset.QuadPart + rb.Length.QuadPart;

			// Start searching at the end of the last allocated region 
			sr.FileOffset.QuadPart += inc;

			// Search the remaining
			sr.Length.QuadPart  -= inc;
		}

		return !_AR.empty();
	}
	unsigned long sector_size(unsigned long& dwSectorsPerCluster, OVERLAPPED& ov) const
	{
		unsigned long dwSectorSize = DEFAULT_SECTOR_SIZE;
		
		_ASSERTE(is_open());

		if((GetFileType(m_hFile) == FILE_TYPE_DISK  && !volume_sector_size(dwSectorSize, dwSectorsPerCluster) &&
			!disk_sector_size(dwSectorSize, dwSectorsPerCluster, ov)) || 
			(m_bTapeDevice && !tape_sector_size(dwSectorSize)))
				throw((long)GetLastError());
		return dwSectorSize;
	}

	// operations
	inline HANDLE release() const
	{
		if(m_bOwns)
			m_bOwns = false;
		return m_hFile;	
	}
	inline bool set_open_volume()
	{
		using namespace std;

		typedef wstring::reverse_iterator iterator;

		// This should only be called after determining 
		// that a path refers to a mount point.
		_ASSERTE(is_directory());
		_ASSERTE(is_mount_point());
		
		if(!is_directory() &&
			!is_mount_point())
			throw(ERROR_INVALID_PARAMETER);

		// Remove the directory bit in the file attributes
		m_Attributes &= ~(FILE_ATTRIBUTE_DIRECTORY);

		m_szFile = m_szOther;

		_ASSERTE(m_szFile.size() > 1);

		// Truncate the trailing backslash if it exists
		iterator i = m_szFile.rbegin();

		if(*++i == L'\\')
			*i = L'\0';
		
		m_bDiskDevice = true;

		return true;
	}
	inline void set_open_raw_link_path()
	{
		_ASSERTE(is_shell_link());
		
		m_szFile = m_szOther;
		initialize();
	}
	bool open(bool bUseBackupSemantics = false)
	{
		
		if(is_open())
			close();

		unsigned long dwFlags; 

		if(m_bTapeDevice)
			dwFlags = FILE_ATTRIBUTE_NORMAL;
		else
			dwFlags = FILE_FLAG_OVERLAPPED |     // enable asynchronous io
			          FILE_FLAG_NO_BUFFERING;    // provides maximum asynchronous performance

		if(bUseBackupSemantics)
			dwFlags |= FILE_FLAG_BACKUP_SEMANTICS;

		m_hFile = CreateFile(m_szFile.c_str(), // File name
							  GENERIC_WRITE |GENERIC_READ,    // desired access
							  FILE_SHARE_READ | FILE_SHARE_WRITE, // Share mode
							  NULL,    // No inheritance
							  OPEN_EXISTING, 
							  dwFlags,     
							  NULL);   // No template file

		if(m_hFile == INVALID_HANDLE_VALUE)
		{
			_RPT0(_CRT_WARN, "Failed to open ");
			OutputDebugStringW(m_szFile.c_str());
			_RPT1(_CRT_WARN, ": Last Error = %ld\n", GetLastError());
			return false;
		}
		m_bOwns = true;
		return true;

	}
	bool lock(OVERLAPPED& ov)
	{
		_ASSERTE(is_directory() || is_open());

		if(is_directory())
			return true;
		else if(!is_open())
			return false;
		
		ResetEvent(ov.hEvent);

		if(is_disk_device())
		{
			if(lock_device(ov))
				return true;
			else if(dismount_device(ov))
			{
				_ASSERTE(!lock_device(ov));
				return true;
			}
			else
				return false;
		}
		else if(is_tape_device())
		{
			return lock_tape();
		}
		else if(!is_directory())
		{
			return lock_file(ov);
		}
		else
		{
			return true;  // directories cannot be locked
		}
	}
	bool load()
	{
		if(!is_tape_device())
			return true;
		return load_tape();
	}
	bool unload()
	{
		if(!is_tape_device())
			return true;
		return unload_tape();
	}
	bool unlock(OVERLAPPED& ov)
	{
		_ASSERTE(is_open());

		if(!is_open())
			return false;
		
		if(is_disk_device())
			return unlock_device(ov);
		else if(is_tape_device())
			return unlock_tape();
		else if(!is_directory())
			return unlock_file(ov);
		else
			return true;  // directories cannot be locked
	}
	bool close()
	{
		if(is_open())
		{
			if(m_bOwns)
				CloseHandle(m_hFile);
			m_hFile = INVALID_HANDLE_VALUE;
		}

		if(m_bOwns)
			m_bOwns = false;

		//The file or volume is unlocked automatically when the handle is closed.
		if(m_bLocked)
			m_bLocked = false;

		return true;
	}
	inline bool flush() 
	{
		if(!is_open() ||
			!FlushFileBuffers(m_hFile))
		{
			// This function will fail with ERROR_INVALID_FUNCTION if there is no write cache
			long lError = GetLastError();
			if(lError != ERROR_INVALID_FUNCTION)
			{
				_RPT1(_CRT_ASSERT, "Failed to flush file buffers: Last Error = %ld", lError);
				return false;
			}
		}
		return true;
	}
	inline bool dismount(OVERLAPPED& ov)
	{
		if(is_disk_device())
			return dismount_device(ov);
		else if(is_tape_device())
			return unload_tape();
		else
			return true;
	}
	size_t write(unsigned char* pData, size_t nSize, OVERLAPPED& ov)
	{
		_ASSERTE(is_open());

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		unsigned long dwBytesWritten;

		if(!WriteFile(m_hFile,            // handle to a file
			          pData,              // data buffer
					  (unsigned long)nSize, // number of bytes to write
					  &dwBytesWritten,   // number of bytes written
					  &ov))                // OVERLAPPED structure
		{
			long lError = GetLastError();
			if(lError != ERROR_IO_PENDING &&
				lError != ERROR_HANDLE_EOF &&
				lError != ERROR_SECTOR_NOT_FOUND &&
				lError != ERROR_END_OF_MEDIA  &&
				lError != ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net
			{
				_RPT1(_CRT_ASSERT, "Failed to write %ld bytes of data to ", nSize);
				OutputDebugStringW(m_szFile.c_str());
				_RPT1(_CRT_ASSERT, ": Last Error = %ld\n", lError);
				if(m_bTapeDevice)
					_RPT1(_CRT_ASSERT, "The status of the tape is %ld\n", GetTapeStatus(m_hFile));
				throw(lError);
			}
			
			if(lError == ERROR_HANDLE_EOF || 
				lError == ERROR_SECTOR_NOT_FOUND ||
				lError == ERROR_END_OF_MEDIA ||
				lError == ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net)
				return (unsigned int)dwBytesWritten;

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesWritten, TRUE))
			{
				lError = GetLastError();
				if(lError == ERROR_HANDLE_EOF || 
					lError == ERROR_SECTOR_NOT_FOUND ||
					lError == ERROR_END_OF_MEDIA ||
					lError == ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net
					return (unsigned int)dwBytesWritten;

				_RPT1(_CRT_ASSERT, "Failed to write %ld bytes of data to ", nSize);
				OutputDebugStringW(m_szFile.c_str());
				_RPT1(_CRT_ASSERT, ": Last Error = %ld\n", lError);
				if(m_bTapeDevice)
					_RPT1(_CRT_ASSERT, "The status of the tape is %ld\n", GetTapeStatus(m_hFile));
				throw(lError);
			}
		}
		return (unsigned int)dwBytesWritten;
	}
	size_t write(unsigned char* pData, size_t nSize)
	{
		_ASSERTE(is_open());

		unsigned long dwBytesWritten;

		if(!WriteFile(m_hFile,            // handle to a file
			          pData,              // data buffer
					  (unsigned long)nSize, // number of bytes to write
					  &dwBytesWritten,   // number of bytes written
					  NULL))                // OVERLAPPED structure
		{
			long lError = GetLastError();
			if(lError != ERROR_HANDLE_EOF &&
				lError != ERROR_SECTOR_NOT_FOUND &&
				lError != ERROR_END_OF_MEDIA &&
				lError != ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net
			{
				_RPT1(_CRT_ASSERT, "Failed to write %ld bytes of data to ", nSize);
				OutputDebugStringW(m_szFile.c_str());
				_RPT1(_CRT_ASSERT, ": Last Error = %ld\n", lError);
				if(m_bTapeDevice)
					_RPT1(_CRT_ASSERT, "The status of the tape is %ld\n", GetTapeStatus(m_hFile));
				throw(lError);
			}
		}
		return (unsigned int)dwBytesWritten;
	}
 	size_t read(unsigned char* pData, size_t nSize, OVERLAPPED& ov)
	{
 		_ASSERTE(is_open());

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		unsigned long dwBytesRead;

		if(!ReadFile(m_hFile,            // handle to a file
			          pData,              // data buffer
					  (unsigned long)nSize, // number of bytes to read
					  &dwBytesRead,   // number of bytes read
					  &ov))                // OVERLAPPED structure
		{
			long lError = GetLastError();
			if(lError != ERROR_IO_PENDING &&
				lError != ERROR_HANDLE_EOF && 
				lError != ERROR_SECTOR_NOT_FOUND &&
				lError != ERROR_END_OF_MEDIA &&
				lError != ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net
			{
				_RPT1(_CRT_ASSERT, "Failed to read %ld bytes of data from ", nSize);
				OutputDebugStringW(m_szFile.c_str());
				_RPT1(_CRT_ASSERT, ": Last Error = %ld\n", lError);
				if(m_bTapeDevice)
					_RPT1(_CRT_ASSERT, "The status of the tape is %ld\n", GetTapeStatus(m_hFile));
				throw(lError);
			}
			
			if(lError == ERROR_HANDLE_EOF || 
				lError == ERROR_SECTOR_NOT_FOUND ||
				lError == ERROR_END_OF_MEDIA ||
				lError == ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net
				return (unsigned int)dwBytesRead;

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesRead, TRUE))
			{
				lError = GetLastError();
				if(lError == ERROR_HANDLE_EOF || 
					lError == ERROR_SECTOR_NOT_FOUND ||
					lError == ERROR_END_OF_MEDIA ||
					lError == ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net
					return (unsigned int)dwBytesRead;

				_RPT1(_CRT_ASSERT, "Failed to read %ld bytes of data from ", nSize);
				OutputDebugStringW(m_szFile.c_str());
				_RPT1(_CRT_ASSERT, ": Last Error = %ld\n", lError);
				if(m_bTapeDevice)
					_RPT1(_CRT_ASSERT, "The status of the tape is %ld\n", GetTapeStatus(m_hFile));
				throw(lError);
			}
		}
		return (unsigned int)dwBytesRead;
	}
 	size_t read(unsigned char* pData, size_t nSize)
	{
		_ASSERTE(is_open());

		unsigned long dwBytesRead;

		if(!ReadFile(m_hFile,            // handle to a file
			          pData,              // data buffer
					  (unsigned long)nSize, // number of bytes to read
					  &dwBytesRead,   // number of bytes read
					  NULL))                // OVERLAPPED structure
		{
			long lError = GetLastError();
			if(lError != ERROR_HANDLE_EOF && 
				lError != ERROR_SECTOR_NOT_FOUND &&
				lError != ERROR_END_OF_MEDIA &&
				lError != ERROR_INVALID_PARAMETER) //Attempting to write beyond end of Zip drive on .Net)
			{
				_RPT1(_CRT_ASSERT, "Failed to read %ld bytes of data from ", nSize);
				OutputDebugStringW(m_szFile.c_str());
				_RPT1(_CRT_ASSERT, ": Last Error = %ld\n", lError);
				if(m_bTapeDevice)
					_RPT1(_CRT_ASSERT, "The status of the tape is %ld\n", GetTapeStatus(m_hFile));
				throw(lError);
			}
		}
		return (unsigned int)dwBytesRead;
	}
	// This function fails if the file system does not support sparse files,
	// i.e. is not NTFS 3.0 or later.
	bool write_zero(const FILE_ZERO_DATA_INFORMATION& zd, OVERLAPPED& ov)
	{
		_ASSERTE(is_open());
		_ASSERTE(!is_sparse());

		if(is_sparse())
			return false;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		unsigned long dwBytesReturned;

		if(!DeviceIoControl(m_hFile,            // handle to a volume
							FSCTL_SET_ZERO_DATA,  // dwIoControlCode
							const_cast<PFILE_ZERO_DATA_INFORMATION>(&zd),// range to zero
							sizeof(FILE_ZERO_DATA_INFORMATION),// nInBufferSize
							NULL,               // lpOutBuffer
							0,                  // nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			long lError = GetLastError();
			if(lError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to set zero data: Last Error = %ld\n", lError);
				throw lError;
			}

			if(lError == ERROR_HANDLE_EOF)
				return true;

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				lError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to set zero data: Last Error = %ld\n", lError);
				throw lError;
			}
		}
		return true;
	}
	_ntfs_stream_infomation streams()
	{
		// There is no documented procedure for enumerating ntfs streams.
		// The following method, which relies upon an undocumented native 
		// api function exported by ntdll.dll, is an adaptation of the method 
		// published by http://www.sysinternals.com.

		if(m_pfnNtQueryInfomationFile == NULL || 
			m_pfnRtlNtStatusToDosError == NULL)
		{
			SetLastError(ERROR_PROC_NOT_FOUND);
			return _ntfs_stream_infomation((PFILE_STREAM_INFORMATION)0, 0);
		}

		_ASSERTE(is_open());

		unsigned long dwSize = 0UL;
		NTSTATUS status;
		IO_STATUS_BLOCK ioStatus;

		unsigned char* p = (unsigned char*)0;

		do {
			if(p != (unsigned char*)0)
				delete [] p;

			dwSize += 16384UL;
			p = new unsigned char[dwSize];

			status = (*m_pfnNtQueryInfomationFile)(m_hFile, 
				                                    &ioStatus,
													p, 
													dwSize,
													_ntfs_stream_infomation::information_class());

		} while(status == STATUS_BUFFER_OVERFLOW);
		
		if(NT_SUCCESS( status ) && ioStatus.Information)
		{
			SetLastError(ERROR_SUCCESS);
			return _ntfs_stream_infomation(reinterpret_cast<PFILE_STREAM_INFORMATION>(p), dwSize);
		}

		if(p != (unsigned char*)0)
			delete [] p;

		long lError = (*m_pfnRtlNtStatusToDosError)(status);
		SetLastError(lError);
		return _ntfs_stream_infomation((PFILE_STREAM_INFORMATION)0, 0);
	}
	bool wipe_tape(unsigned int nPartition = 0)
	{
		_ASSERTE(is_tape_device());

		long lError = ERROR_SUCCESS;

		if(!rewind_tape(nPartition) ||
			!erase_tape())
			return false;
		return true;
	}
	bool rewind_tape(unsigned int nPartition = 0)
	{
		_ASSERTE(is_tape_device());
		
		unsigned long dwResult = SetTapePosition(m_hFile,
												 (nPartition > 0)? TAPE_LOGICAL_BLOCK : TAPE_LOGICAL_BLOCK,
												 nPartition,
												 0UL,
												 0UL,
												 FALSE);

		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			_RPT2(_CRT_WARN, "Failed to rewind tape to beginning of partiton %ld!  Last Error = %ld", nPartition, dwResult);
			return false;
		}
		return true;
	}

	//operators
	inline file_and_attributes& operator=(const file_and_attributes& _F)
	{
		m_szFile = _F.m_szFile;
		m_szOther = _F.m_szOther;
		m_szManufacturer = _F.m_szManufacturer;
		m_szSerialNo = _F.m_szSerialNo;
		m_bOwns = _F.m_bOwns;
		m_hFile = _F.release();
		m_Attributes = _F.m_Attributes;
		m_bDiskDevice = _F.m_bDiskDevice;
		m_bTapeDevice = _F.m_bTapeDevice; 
		m_bLocked = _F.m_bLocked;
		m_bMountPoint = _F.m_bMountPoint;
		m_dwVolumeFlags = _F.m_dwVolumeFlags;
		m_bReparsePoint = _F.m_bReparsePoint;
		return (*this);
	}
private:
	void initialize()
	{
		if(m_szFile == L"")
		{
			_ASSERTE(false);
			throw(ERROR_INVALID_PARAMETER);
		}
		
		// if get_attributes() succeeds the file is either a directory object or a file.
		// if get_attributes() fails check to see if we can access the file.
		while(!get_attributes() &&	!file_exists())
		{
			
			if(check_for_wildcards(m_szFile))
			{
				// The file name contains a wild card which is valid for searches,
				// but not for much else.  Separate the name from the path and try again.
				if(!erase_file_name())
				{
					_ASSERT(false);
					throw(ERROR_FILE_NOT_FOUND); // This is not a valid path
				}
			}
			else
			{
				long lError = GetLastError();
				// The file doesn't exist or the user does not have the right to access it.
				_RPT1(_CRT_ASSERT, "Failed to get file attributes! Last Error = %ld\n", lError);
				throw(lError); // either the file does not exist or access was denied
			}
		}

		if(is_directory() && 
			!get_volume_information())
		{
			_ASSERT(false);
			throw((long)GetLastError());
		}

		if(is_directory() && 
			volume_supports_reparse_points())
			check_for_mount_point();

		// Reparse points are used for a number of other services in addition to mount
		// points, including Removable Storage Management (RSM), Native Structured Storage (NSS), 
		// and Encrypting File System (EFS).  We only know how to handle mount points.
		if(is_reparse_point() &&
			!is_mount_point())
		{
			_ASSERT(false);
			throw(ERROR_INVALID_FUNCTION);
		}

		// File searches require a file name or wild card in addition to the
		// root directory.
		if(is_directory() && 
			!is_reparse_point() && 
			!check_for_wildcards(m_szOther))
		{
			add_trailing_path_separator_if(m_szOther);
			if(m_szOther.empty())
				m_szOther = L"*";
			else
				m_szOther += L"*";
		}

		// The file exists but is not a directory or file object.  
		// It must be some sort of device.  
		//Check to see if it is a disk device.
		if(query_is_disk_device())
		{
			get_disk_device_properties();
		}
		else if(query_is_tape_device())
		{
			if(!tape_status())
				throw((long)GetLastError());
			get_disk_device_properties();
		}
		else if(m_Attributes.empty())
		{
			_ASSERT(false);
			throw(ERROR_BAD_DEV_TYPE);
		}

	}
	bool get_attributes()
	{
		WIN32_FILE_ATTRIBUTE_DATA fad;

		if(!GetFileAttributesEx(m_szFile.c_str(), GetFileExInfoStandard, &fad))
		{
			// Not a file or directory or not available (e.g. the file does not exist).
			long lError = GetLastError();
			_RPT1(_CRT_WARN, "Failed to get file attributes: Last Error = %ld\n", lError);
			OutputDebugString(m_szFile.c_str());
			_RPT0(_CRT_WARN, "\n");
			return false;
		}
		
		// This is a file or directory object.
		m_Attributes = _file_attributes(fad.dwFileAttributes);
		_RPT1(_CRT_WARN, "The file attributes are 0x%lx\n", (unsigned long)m_Attributes);

		if(is_directory())
			add_trailing_path_separator_if(m_szFile);

		return true;
	}
	bool file_exists() const
	{
		HANDLE hFile = CreateFile(m_szFile.c_str(), // File name
							  0UL,      // Query device access (does not read or write to device)
							  FILE_SHARE_READ | FILE_SHARE_WRITE, // Share mode
							  NULL,    // No inheritance
							  OPEN_EXISTING, 
							  FILE_FLAG_NO_BUFFERING,     
							  NULL);   // No template file

		if(hFile != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hFile);
			return true;
		}
		_RPT1(_CRT_WARN, "Unable to open file: Last Error = %ld\n", GetLastError());
		return false;
	}
	bool query_is_disk_device()
	{
		m_bDiskDevice = false;

		HANDLE hFile = INVALID_HANDLE_VALUE;

		__try
		{
			hFile = CreateFile(m_szFile.c_str(), // File name
								  0UL,      // Query device access (does not read or write to device)
								  FILE_SHARE_READ | FILE_SHARE_WRITE, // Share mode
								  NULL,    // No inheritance
								  OPEN_EXISTING, 
								  FILE_FLAG_NO_BUFFERING,     
								  NULL);   // No template file

			if(hFile != INVALID_HANDLE_VALUE)
			{
				LARGE_INTEGER li;

				// its either a disk file, directory, a logical volume or a disk device
				unsigned long dwType = GetFileType(hFile);
				if(dwType == FILE_TYPE_DISK &&
					!GetFileSizeEx(hFile, &li))
				{
					m_bDiskDevice = true;
				}

				_RPT1(_CRT_WARN, "The file type is %ld\n", dwType);
			}

		}
		__finally
		{
			if(hFile != INVALID_HANDLE_VALUE)
				CloseHandle(hFile);
		}

		return m_bDiskDevice;
	}
	bool query_is_tape_device()
	{
		m_bTapeDevice = false;
		if(wcsnicmp(m_szFile.c_str(), L"\\\\.\\Tape", 8) == 0)
			m_bTapeDevice = true;
		return m_bTapeDevice;
	}
	__int64 volume_size(OVERLAPPED& ov)
	{
		// Try to get volume or disk size using IOCTL_DISK_GET_LENGTH_INFO
		// which is faster but which is not supported prior to Windows XP and 
		// which also fails for various other reasons that are not clearly 
		// documented.  
		__int64 _S = volume_or_disk_size(ov);
		
		// If the file is a logical volume GetDiskFreeSpaceEx will return 
		// the volume size, among other things.
		if(_S < (__int64)0) 
			_S = volume_size();

		// The file must be a physical disk.  Use IOCTL_DISK_GET_DRIVE_GEOMETRY
		// to calculate the drive size.
		if(_S < (__int64)0 )
			_S = disk_size(ov);
		return _S;
	}
	__int64 volume_size()
	{
		_ASSERTE(is_open() && m_bDiskDevice);

		ULARGE_INTEGER ulFreeAvailable;
		ULARGE_INTEGER ulTotal;
		ULARGE_INTEGER ulTotalFree;

		if(!GetDiskFreeSpaceEx(m_szFile.c_str(),  // directory name
		                       &ulFreeAvailable,    // bytes available to caller
							   &ulTotal        ,    // bytes on disk
		                       &ulTotalFree))         // free bytes on disk
		{
			// This function fails with ERROR_ACCESS_DENIED if  the file is
			// a physical disk.
			long lError = GetLastError();
				
			_RPT1(_CRT_WARN, "GetDiskFreeSpaceEx failed: Last Error = %ld\n", lError);
			return (__int64) -1;
		}


		return ulTotalFree.QuadPart;
	}
	__int64 disk_size(OVERLAPPED& ov)
	{

		_ASSERTE(is_open() && m_bDiskDevice);
		unsigned long dwBytesReturned;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		
		DISK_GEOMETRY dg;
		if(!DeviceIoControl(m_hFile,              // handle to a volume
							IOCTL_DISK_GET_DRIVE_GEOMETRY, // dwIoControlCode
							NULL,                 // lpInBuffer
							0,                    // nInBufferSize
							&dg,                  // lpOutBuffer
							sizeof(DISK_GEOMETRY),// nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to get extended disk geometry: Last Error = %ld\n", dwError);
				return (__int64) -1;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to get extended disk geometry: Last Error = %ld\n", dwError);
				return (__int64) -1;
			}
			
		}


		_ASSERTE(dwBytesReturned == sizeof(DISK_GEOMETRY));
		
		return ((__int64) dg.BytesPerSector * (__int64) dg.SectorsPerTrack * (__int64) dg.TracksPerCylinder* dg.Cylinders.QuadPart);
	}	
	__int64 tape_size()
	{
 		unsigned long dwSize = sizeof(TAPE_GET_MEDIA_PARAMETERS);
		TAPE_GET_MEDIA_PARAMETERS mp;
		
		_ASSERTE(is_open());

		unsigned long dwResult = GetTapeParameters(m_hFile,
			                                        GET_TAPE_MEDIA_INFORMATION,
													&dwSize,
													&mp);		
		
		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			return (__int64) -1;
		}

		return mp.Capacity.QuadPart;
	}
	__int64 volume_or_disk_size(OVERLAPPED& ov)
	{

		_ASSERTE(is_open() && m_bDiskDevice);
		unsigned long dwBytesReturned;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		
		GET_LENGTH_INFORMATION li;
		if(!DeviceIoControl(m_hFile,              // handle to a volume
							IOCTL_DISK_GET_LENGTH_INFO, // dwIoControlCode
							NULL,                 // lpInBuffer
							0,                    // nInBufferSize
							&li,                  // lpOutBuffer
							sizeof(GET_LENGTH_INFORMATION),// nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to get disk length info: Last Error = %ld\n", dwError);
				return (__int64) -1;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to get disk length info: Last Error = %ld\n", dwError);
				return (__int64) -1;
			}
			
		}


		_ASSERTE(dwBytesReturned == sizeof(GET_LENGTH_INFORMATION));
		
		return li.Length.QuadPart;
	}
	__int64 file_size()
	{
		_ASSERTE(is_open() && !m_bDiskDevice);

		LARGE_INTEGER lTotal;
		if(!GetFileSizeEx(m_hFile, &lTotal))
		{
			_RPT1(_CRT_WARN, "GetFileSizeEx failed: Last Error = %ld\n", GetLastError());
			return (__int64) -1;
		}

		return lTotal.QuadPart;
	}
	bool lock_device(OVERLAPPED& ov)
	{
		_ASSERTE(is_open() && m_bDiskDevice);
		_ASSERTE(ov.hEvent != 0 && ov.hEvent != INVALID_HANDLE_VALUE);

		if(!is_open() || !m_bDiskDevice)
			return false;

		unsigned long dwBytesReturned;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		if(!DeviceIoControl(m_hFile,            // handle to a volume
							FSCTL_LOCK_VOLUME,  // dwIoControlCode
							NULL,               // lpInBuffer
							0,                  // nInBufferSize
							NULL,               // lpOutBuffer
							0,                  // nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to lock volume: Last Error = %ld\n", dwError);
				return false;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to lock volume: Last Error = %ld\n", dwError);
				return false;
			}
		}
		m_bLocked = true;
		return true;

	}
	bool unlock_device(OVERLAPPED& ov)
	{
		_ASSERTE(is_open() && m_bDiskDevice);
		_ASSERTE(ov.hEvent != 0 && ov.hEvent != INVALID_HANDLE_VALUE);

		if(!is_open() || !m_bDiskDevice)
			return false;

		unsigned long dwBytesReturned;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);

		if(!DeviceIoControl(m_hFile,            // handle to a volume
							FSCTL_UNLOCK_VOLUME,  // dwIoControlCode
							NULL,               // lpInBuffer
							0,                  // nInBufferSize
							NULL,               // lpOutBuffer
							0,                  // nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to unlock volume: Last Error = %ld\n", dwError);
				return false;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to unlock volume: Last Error = %ld\n", dwError);
				return false;
			}
		}
		m_bLocked = false;
		return true;

	}
	bool dismount_device(OVERLAPPED& ov)
	{
		_ASSERTE(is_open() && m_bDiskDevice);
		_ASSERTE(ov.hEvent != 0 && ov.hEvent != INVALID_HANDLE_VALUE);

		if(!is_open() || !m_bDiskDevice)
			return false;

		unsigned long dwBytesReturned;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);

		if(!DeviceIoControl(m_hFile,            // handle to a volume
							FSCTL_DISMOUNT_VOLUME,  // dwIoControlCode
							NULL,               // lpInBuffer
							0,                  // nInBufferSize
							NULL,               // lpOutBuffer
							0,                  // nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to dismount volume: Last Error = %ld\n", dwError);
				return false;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to dismount volume: Last Error = %ld\n", dwError);
				return false;
			}
		}
		return true;
	}
	bool lock_file(OVERLAPPED& ov)
	{
		_ASSERTE(is_open() && !m_bDiskDevice);
		_ASSERTE(ov.hEvent != 0 && ov.hEvent != INVALID_HANDLE_VALUE);

		if(!is_open() || m_bDiskDevice)
			return false;

		// directories cannot be locked
		if(is_directory())
		{
			m_bLocked = true;
			return true;
		}

		LARGE_INTEGER _S;
		_S.QuadPart = file_size();

		if(_S.QuadPart < (__int64)0)
			return false;

		// Starting offset of file range to lock
		// Lock the whole file
		ov.Offset = 0UL;
		ov.OffsetHigh = 0UL;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);

		if(!LockFileEx(m_hFile,                 // open file handle
			           LOCKFILE_EXCLUSIVE_LOCK, // type of lock requested
					   0UL,                     // reserved (must be set to 0)
					   _S.LowPart,              // low-order 32 bits of the length of the byte range to lock
			           _S.HighPart,             // high-order 32 bits of the length of the byte range to lock
					   &ov))                    // contains the file offset of the beginning of the lock range
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to lock file: Last Error = %ld\n", dwError);
				return false;
			}

			unsigned long dwBytesReturned = 0UL;

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to lock file: Last Error = %ld\n", dwError);
				return false;
			}
		}
		m_bLocked = true;
		return true;
	}
	bool unlock_file(OVERLAPPED& ov)
	{
		_ASSERTE(is_open() && !m_bDiskDevice);
		_ASSERTE(ov.hEvent != 0 && ov.hEvent != INVALID_HANDLE_VALUE);

		if(!is_open() || m_bDiskDevice)
			return false;

		// directories cannot be locked
		if(is_directory())
		{
			m_bLocked = false;
			return true;
		}

		LARGE_INTEGER _S;
		_S.QuadPart = file_size();

		if(_S.QuadPart < (__int64)0)
			return false;

		// Starting offset of file range to unlock
		// unlock the whole file
		ov.Offset = 0UL;
		ov.OffsetHigh = 0UL;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);

		if(!UnlockFileEx(m_hFile,                 // open file handle
					   0UL,                     // reserved (must be set to 0)
					   _S.LowPart,              // low-order 32 bits of the length of the byte range to lock
			           _S.HighPart,             // high-order 32 bits of the length of the byte range to lock
					   &ov))                    // contains the file offset of the beginning of the lock range
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to unlock file: Last Error = %ld\n", dwError);
				return false;
			}

			unsigned long dwBytesReturned = 0UL;

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to unlock file: Last Error = %ld\n", dwError);
				return false;
			}
		}
		m_bLocked = false;
		return true;

	}
	bool query_allocated_range(const FILE_ALLOCATED_RANGE_BUFFER& sr, FILE_ALLOCATED_RANGE_BUFFER& rb, OVERLAPPED& ov)
	{
		unsigned long dwBytesReturned;

		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		if(!DeviceIoControl(m_hFile,                         // handle to file
						FSCTL_QUERY_ALLOCATED_RANGES,    // dwIoControlCode
						const_cast<PFILE_ALLOCATED_RANGE_BUFFER>(&sr),// input buffer
						sizeof(FILE_ALLOCATED_RANGE_BUFFER),// size of input buffer
						&rb,                                // output buffer
						sizeof(FILE_ALLOCATED_RANGE_BUFFER),// size of output buffer
						&dwBytesReturned,                   // number of bytes returned
						&ov))     // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING &&
				dwError != ERROR_MORE_DATA)
			{
				_RPT1(_CRT_WARN, "Failed to query allocated range: Last Error = %ld\n", dwError);
				return false;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				if(dwError != ERROR_MORE_DATA)
				{
					_RPT1(_CRT_WARN, "Failed to query allocated range: Last Error = %ld\n", dwError);
					return false;
				}
			}
		}

		_ASSERTE(dwBytesReturned == sizeof(FILE_ALLOCATED_RANGE_BUFFER));
		return true;
	}
	wchar_t* root_path() const
	{
	    wchar_t drive[_MAX_DRIVE];
		
		// The directory length will be less than or equal to the size
		// of the full path plus one for the trailing null character.
		// Also add one for a trailing backslash which may be added 
		// by splitpath.  Add _MAX_DRIVE so that we can do makepath in place.
		size_t len = m_szFile.size() + 2 + _MAX_DRIVE;
		
		wchar_t* root = new wchar_t[len];
		wchar_t* dir = root + _MAX_DRIVE;

		// Separate the drive letter (if any) and directory
		_wsplitpath(m_szFile.c_str(), drive, dir, NULL, NULL);
		_wmakepath(root, drive, dir, NULL, NULL);
		
		return root;
	}
	bool volume_sector_size(unsigned long& dwSectorSize, unsigned long& dwSectorsPerCluster) const
	{
		bool bResult = false;

		wchar_t* root = root_path();

		unsigned long dwNumberOfFreeClusters;
		unsigned long dwTotalNumberOfClusters;

		__try
		{
			if(!GetDiskFreeSpace(root,
				                 &dwSectorsPerCluster,
								 &dwSectorSize,
								 &dwNumberOfFreeClusters,
								 &dwTotalNumberOfClusters))				
				__leave;
			
			OutputDebugString(root);
			_RPT2(_CRT_WARN, ": BytesPerSector = %ld, SectorsPerCluster = %ld\n", dwSectorSize, dwSectorsPerCluster);
			bResult = true;

		}
		__finally
		{
			if(root != (wchar_t*)0)
				delete [] root;
		}

		return bResult;
	}
	bool disk_sector_size(unsigned long& dwSectorSize, unsigned long& dwSectorsPerCluster, OVERLAPPED& ov) const
	{
		_ASSERTE(ov.hEvent != INVALID_HANDLE_VALUE);
		ResetEvent(ov.hEvent);
		
		unsigned long dwBytesReturned;
		DISK_GEOMETRY dg;

		if(!DeviceIoControl(m_hFile,              // handle to a volume
							IOCTL_DISK_GET_DRIVE_GEOMETRY, // dwIoControlCode
							NULL,                 // lpInBuffer
							0,                    // nInBufferSize
							&dg,                  // lpOutBuffer
							sizeof(DISK_GEOMETRY),// nOutBufferSize
							&dwBytesReturned,   // number of bytes returned
							&ov))                // OVERLAPPED structure
		{
			unsigned long dwError = GetLastError();
			if(dwError != ERROR_IO_PENDING)
			{
				_RPT1(_CRT_WARN, "Failed to get extended disk geometry: Last Error = %ld\n", dwError);
				return false;
			}

			if(!GetOverlappedResult(m_hFile, &ov, &dwBytesReturned, TRUE))
			{
				dwError = GetLastError();
				_RPT1(_CRT_WARN, "Failed to get extended disk geometry: Last Error = %ld\n", dwError);
				return false;
			}

		}

		_ASSERTE(dwBytesReturned == sizeof(DISK_GEOMETRY));
		dwSectorSize = dg.BytesPerSector;
		dwSectorsPerCluster = dg.SectorsPerTrack;

		return true;
	}
	bool tape_sector_size(unsigned long& dwSectorSize) const
	{
		unsigned long dwSize = sizeof(TAPE_GET_MEDIA_PARAMETERS);
		TAPE_GET_MEDIA_PARAMETERS mp;
		
		_ASSERTE(is_open());

		unsigned long dwResult = GetTapeParameters(m_hFile,
			                                        GET_TAPE_MEDIA_INFORMATION,
													&dwSize,
													&mp);		
		
		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			return false;
		}

		dwSectorSize = mp.BlockSize;
		return true;
	}
	bool get_volume_information()
	{
		wchar_t szFileSystem[FILESYSNAMEBUFSIZE];

		wchar_t* vp = volume_path_name();

		if(vp == NULL)
			return false;

		bool bResult = false;

		__try
		{
			// If the volume is not NTFS? 
			if(!GetVolumeInformation(vp, // Root path name 
									 NULL,             // volume name buffer
									 0,                // length of volume name buffer
									 NULL,             // volume serial number (unsigned long)
									 NULL,             // maximum file name length 
									 &m_dwVolumeFlags,      // flags
									 szFileSystem,   //
									 FILESYSNAMEBUFSIZE))
			{
				_RPT0(_CRT_WARN, "Failed to get volume information for ");
				OutputDebugString(m_szFile.c_str());
				_RPT1(_CRT_WARN, ": Last Error = %ld\n", GetLastError());
				__leave;
			}

			_RPT0(_CRT_WARN, "The file system is ");
			OutputDebugString(szFileSystem);
			_RPT0(_CRT_WARN, "\n");
			bResult = true;
		}
		__finally
		{
			if(vp != NULL)
				delete [] vp;
		}
		return bResult;
	}
	wchar_t* volume_path_name() const
	{
		_ASSERTE(!m_szFile.empty());

		if(m_szFile.empty())
			return (wchar_t*)0;

		unsigned long dwLen = (unsigned long) m_szFile.size() + 1;

		wchar_t* vp = new wchar_t[dwLen];

		if(!GetVolumePathNameW(m_szFile.c_str(),
			                  vp,
							  dwLen))
		{
			delete [] vp;
			return (wchar_t*)0;
		}
		return vp;
	}
	inline bool volume_supports_reparse_points() const
	{
		return  (m_dwVolumeFlags & FILE_SUPPORTS_REPARSE_POINTS) != 0UL;
	}
	bool check_for_mount_point()
	{
		wchar_t szVolumeName[50];

		if(!GetVolumeNameForVolumeMountPoint(m_szFile.c_str(), // volume mount point or directory
			                                 szVolumeName,     // volume name buffer
											 50))              // size of volume name buffer
		{
			_RPT0(_CRT_WARN, "Failed to get volume name for mount point ");
			OutputDebugString(m_szFile.c_str());
			_RPT1(_CRT_WARN, ": Last Error = %ld\n", GetLastError());
			return false;
		}

		m_bMountPoint = true;
		m_szOther = szVolumeName;
		
		_RPT0(_CRT_WARN, "The volume name is ");
		OutputDebugString(szVolumeName);
		_RPT0(_CRT_WARN, "\n");

		return true;
	}
	bool resolve_link()
	{
		IShellLinkWPtr psl;

		HRESULT hr = psl.CreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER);
		if(!SUCCEEDED(hr))
		{
			SetLastError(hr);
			return false;
		}

		IPersistFilePtr ppf;
		hr = psl->QueryInterface(__uuidof(IPersistFile), reinterpret_cast<void**>(&ppf));
		if(!SUCCEEDED(hr))
		{
			SetLastError(hr);
			return false;
		}

		hr = ppf->Load(m_szFile.c_str(), STGM_READ);
		if(!SUCCEEDED(hr))
		{
			SetLastError(hr);
			return false;
		}

		unsigned long dwFlags = SLR_NO_UI |     // Don't display ui to resolve link
			                    SLR_NOUPDATE;   // Don't update the link if the link location 
		                                        // has changed.
		hr = psl->Resolve(NULL, dwFlags); 
		if(!SUCCEEDED(hr))
		{
			SetLastError(hr);
			return false;
		}

		wchar_t szPath[_MAX_PATH];

		hr = psl->GetPath(szPath, 
							_MAX_PATH, NULL, 
							SLGP_RAWPATH ); 
		if(!SUCCEEDED(hr))
		{
			SetLastError(hr);
			return false;
		}
		
		m_szOther = szPath;

		return true;
	}
	bool erase_file_name()
	{
		using namespace std;

		wchar_t szFName[_MAX_FNAME];
		wchar_t szExt[_MAX_EXT];
		_wsplitpath(m_szFile.c_str(), NULL, NULL, szFName, szExt);
			
		m_szOther = szFName;
		m_szOther += szExt;

		size_t pos = m_szFile.rfind(L'\\');
		if(pos == wstring::npos)
			return false;
		m_szFile.erase(pos, wstring::npos);
		return true;
	}
	bool get_disk_device_properties()
	{
        os_handle_t Device = open_for_query();

		if(Device.empty())
			return false;

		long lError;
		unsigned long dwLength;

		STORAGE_PROPERTY_QUERY query;
		query.PropertyId = StorageDeviceProperty;
        query.QueryType = PropertyStandardQuery;
		
		unsigned char data[512];


        if(!DeviceIoControl(Device,                
                            IOCTL_STORAGE_QUERY_PROPERTY,
                            &query,
                            sizeof( STORAGE_PROPERTY_QUERY ),
                            data,                   
                            512,                      
                            &dwLength,
                            NULL                    
                            ))
		{
			lError = GetLastError();
			_RPT1(_CRT_WARN, "Attempt to query storage device property failed: Last Error = %ld\n", lError);
			return false;
		}
		
		PSTORAGE_DEVICE_DESCRIPTOR pSdd = reinterpret_cast<PSTORAGE_DEVICE_DESCRIPTOR>(data);
		
		if(pSdd -> VendorIdOffset != 0UL)
		{
			wchar_t szVendorId[_MAX_PATH];
			mbstowcs(szVendorId, (char*)data + pSdd -> VendorIdOffset, _MAX_PATH);
			m_szManufacturer = szVendorId;
		}
		else
			m_szManufacturer = L" ";

		if(pSdd -> ProductIdOffset != 0UL)
		{
			wchar_t szProductId[_MAX_PATH];
			mbstowcs(szProductId, (char*)data + pSdd -> ProductIdOffset, _MAX_PATH);
			m_szManufacturer += szProductId;
		}
		
		if(pSdd->SerialNumberOffset != 0UL)
		{
			wchar_t szSerial[_MAX_PATH];
			mbstowcs(szSerial, (char*) data + pSdd->SerialNumberOffset, _MAX_PATH);
			m_szSerialNo = szSerial;
		}

		return true;
	}
	os_handle_t open_for_query(unsigned long dwAccess = 0UL) const
	{
		HANDLE hFile = CreateFile(m_szFile.c_str(), // File name
							  dwAccess,       // dwDesiredAccess
							  FILE_SHARE_READ | FILE_SHARE_WRITE, // Share mode
							  NULL,    // No inheritance
							  OPEN_EXISTING, 
							  FILE_FLAG_NO_BUFFERING,     
							  NULL);   // No template file

		if(hFile != INVALID_HANDLE_VALUE)
		{
			return os_handle_t(hFile);
		}

		_RPT1(_CRT_WARN, "Unable to open file: Last Error = %ld\n", GetLastError());
		return false;
	}
	bool tape_status() const
	{
		_ASSERTE(m_bTapeDevice);

        os_handle_t Device = open_for_query(GENERIC_READ);

		if(Device.empty())
			return false;
		
		unsigned long dwError = GetTapeStatus(Device);

		if(dwError != NO_ERROR)
		{
			SetLastError(dwError);
			return false;
		}
		return true;
	}
	bool load_tape()
	{	
		_ASSERTE(m_bTapeDevice);
		_ASSERTE(is_open());
		
		unsigned long dwResult = PrepareTape(m_hFile,
			                                 TAPE_LOAD,
											 FALSE);

		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			return false;
		}
		return true;
	}
	bool lock_tape()
	{	
		_ASSERTE(m_bTapeDevice);
		_ASSERTE(is_open());
		
		unsigned long dwResult = PrepareTape(m_hFile,
			                                 TAPE_LOCK,
											 FALSE);

		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			return false;
		}

		m_bLocked = true;
		return true;
	}
	bool unload_tape()
	{	
		_ASSERTE(m_bTapeDevice);
		_ASSERTE(is_open());
		
		unsigned long dwResult = PrepareTape(m_hFile,
			                                 TAPE_UNLOAD,
											 FALSE);

		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			return false;
		}
		return true;
	}
	bool unlock_tape()
	{	
		_ASSERTE(m_bTapeDevice);
		_ASSERTE(is_open());
		
		unsigned long dwResult = PrepareTape(m_hFile,
			                                 TAPE_UNLOCK,
											 FALSE);

		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			return false;
		}
		m_bLocked = false;
		return true;
	}
	bool erase_tape()
	{	
		_ASSERTE(m_bTapeDevice);
		_ASSERTE(is_open());
		
		unsigned long dwResult = EraseTape(m_hFile,
			                                 TAPE_ERASE_LONG,
											 FALSE);

		if(dwResult != NO_ERROR)
		{
			SetLastError(dwResult);
			_RPT1(_CRT_WARN, "Failed to erase tape!  Last Error = %ld\n", dwResult);
			return false;
		}
		return true;
	}


	std::wstring m_szFile;
	std::wstring m_szOther;
	std::wstring m_szManufacturer;
	std::wstring m_szSerialNo;
	HANDLE m_hFile;
	_file_attributes m_Attributes;
	unsigned long m_dwVolumeFlags;
	bool m_bMountPoint;
	bool m_bDiskDevice;
	bool m_bTapeDevice;
	bool m_bLocked;
	mutable bool m_bOwns;

public:
	static NTQUERYINFORMATIONFILE m_pfnNtQueryInfomationFile;
	static RTLNTSTATUSTODOSERROR m_pfnRtlNtStatusToDosError;
};

class wiper_progress
{
public:
	enum { phase_none = 0L,
		phase_writing_FF,
		phase_writing_random,
		phase_writing_zero,
		phase_done,
	};

	virtual void __stdcall wipe_phase_start(int iPhase, const file_and_attributes& _F) const = 0;
	virtual void __stdcall wipe_phase_start_allocated_range(int iPhase, const file_and_attributes& _F, const FILE_ALLOCATED_RANGE_BUFFER& rb) const = 0;
	virtual void __stdcall wipe_phase_completed_allocated_range(int iPhase, const file_and_attributes& _F, const FILE_ALLOCATED_RANGE_BUFFER& rb, __int64 TotalWritten) const = 0;
	virtual void __stdcall wipe_phase_completed(int iPhase, const file_and_attributes& _F, __int64 TotalWritten, unsigned long interval) const = 0;
	virtual void __stdcall wipe_verify_phase_start(int iPhase, const file_and_attributes& _F) const = 0;
	virtual void __stdcall wipe_verify_phase_completed(int iPhase, const file_and_attributes& _F, bool bResult) const = 0;
	virtual void __stdcall wipe_progress(int iPhase, const file_and_attributes& _F, const FILE_ALLOCATED_RANGE_BUFFER& rb, __int64 TotalWritten) const = 0;
	virtual void __stdcall wipe_result(const file_and_attributes& _F, long lReason) const = 0;
	virtual long __stdcall wipe_done() const = 0;
	virtual void __stdcall wipe_complete() const = 0;
};

class wiper : public work_item<wiper>,
			  private OVERLAPPED
{
public:
	typedef work_item<wiper> base_class;
	friend base_class;
	
	
	wiper(const file_and_attributes& _F, const wiper_progress& _P, long lPattern, bool bVerify, size_t nBlockSize = 4096) 
		: m_F(_F), m_Progress(_P), m_lPhase(lPattern != wiper_progress::phase_none ? lPattern - 1L : wiper_progress::phase_none), 
		  m_lPattern(lPattern),
		  m_nBlockSize(nBlockSize), m_pBlock((unsigned char*)0),
		  m_hCryptProv((HCRYPTPROV)0), m_hSeedCryptProv((HCRYPTPROV)0),
		  m_pVerify((unsigned char*) 0), m_bVerify(bVerify)
	{
		Internal = (ULONG_PTR)0;
		InternalHigh = (ULONG_PTR)0;
		Offset = 0UL;
		OffsetHigh = 0UL;

		hEvent = INVALID_HANDLE_VALUE;
		
		if(!_F.is_tape_device())
		{
			hEvent = CreateEvent(NULL, TRUE, FALSE, NULL);
			if(hEvent == INVALID_HANDLE_VALUE)
				throw((long) GetLastError());
		}
	}
	~wiper()
	{
		cleanup();
		m_Progress.wipe_complete();
	}
private:
	unsigned long __stdcall run()
	{
		using namespace std;

		long lResult = E_UNEXPECTED;

		__try
		{
			if(!get_allocated_ranges())
				__leave;

			adjust_block_size();

			if(m_F.is_tape_device() &&
				m_F.has_secure_erase())
			{
				if(!m_F.wipe_tape())
				{
					lResult = GetLastError();
					__leave;
				}
				lResult = ERROR_SUCCESS;
			}
			else
			{
				m_pBlock = new unsigned char[m_nBlockSize];

				if(m_bVerify && m_pVerify == (unsigned char*)0)
					m_pVerify = new unsigned char[m_nBlockSize];
				
				while(!done() &&
					InterlockedIncrement(&m_lPhase) < wiper_progress::phase_done)
				{
					
					if(!write_next_phase() ||
						!m_F.flush())
						break;

					if(m_bVerify && 
						!done() &&
						!verify_next_phase())
						__leave;
					if(m_lPattern != wiper_progress::phase_none &&
						m_lPhase == m_lPattern)
						m_lPhase = wiper_progress::phase_done - 1L;
				}

				// If we have completed all three phases without an
				// error then declare success.
				if(m_lPhase == wiper_progress::phase_done)
					lResult = ERROR_SUCCESS;

			}

			// If the file is a device or logical volume,
			// it no longer contains a usable file system. 
			m_F.dismount(*this);

		}
		__finally
		{
			m_Progress.wipe_result(m_F, lResult);			
		}

		return 0UL;
	}
	void __stdcall cleanup()
	{
		if(hEvent != INVALID_HANDLE_VALUE)
		{
			CloseHandle(hEvent);
			hEvent = INVALID_HANDLE_VALUE;
		}
		if(m_pBlock != (unsigned char*)0)
		{
			delete [] m_pBlock;
			m_pBlock = (unsigned char*)0;
		}
		if(m_pVerify != (unsigned char*)0)
		{
			delete [] m_pVerify;
			m_pVerify = (unsigned char*)0;
		}
		if(m_hCryptProv != (HCRYPTPROV)0)
		{
			CryptReleaseContext(m_hCryptProv, 0);
			m_hCryptProv = (HCRYPTPROV)0;
		}
		if(m_hSeedCryptProv != (HCRYPTPROV)0)
		{
			CryptReleaseContext(m_hSeedCryptProv, 0);
			m_hSeedCryptProv = (HCRYPTPROV)0;
		}
	}
	inline bool done() const
	{
		return (m_Progress.wipe_done() == 1L);
	}
	bool write_next_phase()
	{
		typedef std::vector<FILE_ALLOCATED_RANGE_BUFFER>::iterator iterator;

		__int64 TotalWritten = (__int64) 0;
		__int64 Written = (__int64) 0;

		m_Progress.wipe_phase_start(m_lPhase, m_F);

		unsigned long now = GetTickCount();		

		// A non-sparse file will have just one allocated region comprising
		// the entire file.  A sparse file may have one or more allocated
		// regions.  Perform each phase once per allocated region.
		for(iterator i = m_AR.begin(); i != m_AR.end(); ++i)
		{
			if(m_F.is_tape_device() &&
				!m_F.rewind_tape())
				return false;

			if(done())
				break;

			m_Progress.wipe_phase_start_allocated_range(m_lPhase, m_F, *i);
			
			switch(m_lPhase)
			{
			case wiper_progress::phase_writing_FF:
				Written = write_FF(*i);
				break;
			case wiper_progress::phase_writing_random:
				Written = write_random(*i);
				break;
			case wiper_progress::phase_writing_zero:
				Written = write_zero(*i);
				break;
			default:
				_ASSERT(false);
				break;
			}
			
			m_Progress.wipe_phase_completed_allocated_range(m_lPhase, m_F, *i, Written);

			if(Written < (__int64)0)
				return false;

			TotalWritten += Written;
		}
		
		unsigned long then = GetTickCount();
		m_Progress.wipe_phase_completed(m_lPhase, m_F, TotalWritten, then - now);

		return (TotalWritten >= (__int64)0);
	}
	//Read the file back in and see if we have done what we think that we have done
	bool verify_next_phase()
	{
		using namespace std;

		typedef vector<FILE_ALLOCATED_RANGE_BUFFER>::iterator iterator;

		bool bResult = false;

		m_Progress.wipe_verify_phase_start(m_lPhase, m_F);

		// A non-sparse file will have just one allocated region comprising
		// the entire file.  A sparse file may have one or more allocated
		// regions.  Perform each phase once per allocated region.
		for(iterator i = m_AR.begin(); i != m_AR.end(); ++i)
		{
			if(m_F.is_tape_device() &&
				!m_F.rewind_tape())
				return false;

			if(done())
				break;

			switch(m_lPhase)
			{
			case wiper_progress::phase_writing_FF:
				bResult = verify_FF(*i);
				break;
			// We are skipping random verification because it is a pain.
			// Presummably if writing FF and writing zero works this does too.
			case wiper_progress::phase_writing_random:
				bResult = true;
				break;
			case wiper_progress::phase_writing_zero:
				bResult = verify_zero(*i);
				break;
			default:
				_ASSERT(false);
				break;
			}
			
			if(!bResult)
				break;
		}
		
		m_Progress.wipe_verify_phase_completed(m_lPhase, m_F, bResult);

		return bResult;
	}
	bool get_allocated_ranges()
	{
		return m_F.allocated_ranges(m_AR, *this);
	}
	bool adjust_block_size() 
	{
		
		try
		{
			unsigned long dwSectorsPerCluster;

			// Determine the sector size on the Volume or drive
			size_t size = m_F.sector_size(dwSectorsPerCluster, *this);

			_RPT1(_CRT_WARN, "Adjusting block size from %ld ", m_nBlockSize);
			if(m_nBlockSize == size)
			{
				// If the requested block size equals the sector size,
				// return true.
			}
			else if(m_nBlockSize < size)
			{
				// If the requested block size is smaller than the 
				// sector size, adjust the block size to at least the 
				// sector size.
				m_nBlockSize = __max(m_nBlockSize, size);
			}
			else
			{
				// If the requested block size is larger than the 
				// sector size, round the block size down to align 
				// on sector size boundary.
				m_nBlockSize = size * (m_nBlockSize/size);
			}
			_RPT1(_CRT_WARN, " to %ld \n", m_nBlockSize);
		}
		catch(...)
		{
			return false;
		}
	
		return true;
	}
	__int64 write_FF(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		using namespace std;

		_ASSERTE(m_pBlock != (unsigned char*)0);
		memset(m_pBlock, 0xff, m_nBlockSize);
		return write_data(rb);
	}
	bool verify_FF(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		using namespace std;

		_ASSERTE(m_pBlock != (unsigned char*)0);
		memset(m_pBlock, 0xff, m_nBlockSize);
		return verify_data(rb);
	}
	__int64 write_random(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		using namespace std;

		_ASSERTE(m_pBlock != (unsigned char*)0);
		
		return write_data(rb);
	}
	__int64 write_zero(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		using namespace std;
		
		_ASSERTE(m_pBlock != (unsigned char*)0);
		memset(m_pBlock, 0, m_nBlockSize);
		return write_data(rb);
	}
	bool verify_zero(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		using namespace std;

		_ASSERTE(m_pBlock != (unsigned char*)0);
		memset(m_pBlock, 0, m_nBlockSize);
		return verify_data(rb);
	}
	__int64 write_data(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		_ASSERTE(m_pBlock != NULL);

		__int64 TotalWritten = (__int64)0;

		FILE_ALLOCATED_RANGE_BUFFER Next;
		Next.FileOffset.QuadPart = rb.FileOffset.QuadPart;
		Next.Length.QuadPart = rb.Length.QuadPart;
		
		Offset = Next.FileOffset.LowPart;
		OffsetHigh = Next.FileOffset.HighPart;

		try
		{
			while(Next.Length.QuadPart > (__int64)0 && !done())
			{
				
				// Get new random bits for each write operation
				// when in writing random phase.  For other phases,
				// the bits stay the same (zero or FF) throughout the
				// write operation.
				if(m_lPhase == wiper_progress::phase_writing_random &&
					!generate_random_bits())
					return (__int64) -1;

				size_t nResult;

				if(m_F.is_tape_device())
					nResult = m_F.write(m_pBlock, m_nBlockSize);
				else
					nResult = m_F.write(m_pBlock, m_nBlockSize, *this);

				
				TotalWritten += (__int64) nResult;

				// We've reached the EOF
				if( nResult < m_nBlockSize)
				{
					//Adjust the allocated range to the writable disk size
					long lError = GetLastError();

					if((lError == ERROR_HANDLE_EOF || 
						lError == ERROR_SECTOR_NOT_FOUND) &&
						rb.Length.QuadPart == _I64_MAX)
					{
						FILE_ALLOCATED_RANGE_BUFFER& _RB = const_cast<FILE_ALLOCATED_RANGE_BUFFER&>(rb);

						Next.FileOffset.QuadPart += (__int64) nResult;
						_RB.Length.QuadPart = (Next.FileOffset.QuadPart - _RB.FileOffset.QuadPart);
					}
					break;
				}

				Next.FileOffset.QuadPart += (__int64) m_nBlockSize;
				Next.Length.QuadPart -= (__int64) m_nBlockSize;
				Offset = Next.FileOffset.LowPart;
				OffsetHigh = Next.FileOffset.HighPart;
			}

		}
		catch(long e)
		{
			_RPT3(_CRT_WARN, "Failed writing data to offset 0x%I64x length 0x%I64d, Last Error = %ld\n",
				Next.FileOffset.QuadPart, Next.Length.QuadPart, e);
			SetLastError(e);
			return (__int64) -1;
		}
		return TotalWritten;
	}
	bool verify_data(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		_ASSERTE(m_pVerify != NULL);
		_ASSERTE(m_pBlock != NULL);

		FILE_ALLOCATED_RANGE_BUFFER Next;
		Next.FileOffset.QuadPart = rb.FileOffset.QuadPart;
		Next.Length.QuadPart = rb.Length.QuadPart;
		
		Offset = Next.FileOffset.LowPart;
		OffsetHigh = Next.FileOffset.HighPart;

		try
		{
			while(Next.Length.QuadPart > (__int64)0 && !done())
			{
				size_t nResult;
				
				if(m_F.is_tape_device())
					nResult= m_F.read(m_pVerify, m_nBlockSize);
				else
					nResult= m_F.read(m_pVerify, m_nBlockSize, *this);
				
				if(memcmp(m_pVerify, m_pBlock, nResult) != 0)
					return false;

				// We've reached the EOF
				if( nResult < m_nBlockSize)
					break;

				Next.FileOffset.QuadPart += (__int64) m_nBlockSize;
				Next.Length.QuadPart -= (__int64) m_nBlockSize;
				Offset = Next.FileOffset.LowPart;
				OffsetHigh = Next.FileOffset.HighPart;
			}

		}
		catch(long e)
		{
			_RPT3(_CRT_WARN, "Failed reading data to offset 0x%I64x length 0x%I64d, Last Error = %ld\n",
				Next.FileOffset.QuadPart, Next.Length.QuadPart, e);
			SetLastError(e);
			return false;
		}
		return true;
	}
	bool write_zero_data(const FILE_ALLOCATED_RANGE_BUFFER& rb)
	{
		FILE_ALLOCATED_RANGE_BUFFER Next;
		Next.FileOffset.QuadPart = rb.FileOffset.QuadPart;
		Next.Length.QuadPart = rb.Length.QuadPart;
		
		FILE_ZERO_DATA_INFORMATION zd;
		zd.FileOffset.QuadPart = Next.FileOffset.QuadPart;
		zd.BeyondFinalZero.QuadPart = zd.FileOffset.QuadPart;
		zd.BeyondFinalZero.QuadPart += (__int64) m_nBlockSize;

		try
		{
			while(Next.Length.QuadPart > (__int64)0 && !done())
			{
				if(!m_F.write_zero(zd, *this))
					break;

				Next.FileOffset.QuadPart += (__int64) m_nBlockSize;
				Next.Length.QuadPart -= (__int64) m_nBlockSize;
				zd.FileOffset.QuadPart = Next.FileOffset.QuadPart;
				zd.BeyondFinalZero.QuadPart += (__int64) m_nBlockSize;
			}

		}
		catch(long e)
		{
			_RPT3(_CRT_WARN, "Failed writing zero data to offset 0x%I64x length 0x%I64d, Last Error = %ld\n",
				Next.FileOffset.QuadPart, Next.Length.QuadPart, e);
			SetLastError(e);
			return false;
		}
		return true;
	}
	bool generate_random_bits()
	{
		if(m_hCryptProv == (HCRYPTPROV)0 &&
			!CryptAcquireContext(&m_hCryptProv,
								 NULL,
								 MS_ENHANCED_PROV,
								 PROV_RSA_FULL,
								 CRYPT_VERIFYCONTEXT) && 
			!CryptAcquireContext(&m_hCryptProv,
								 NULL,
								 NULL,
								 PROV_RSA_FULL,
								 CRYPT_VERIFYCONTEXT )) 
		{
			long lError = GetLastError();
			_RPT1(_CRT_ASSERT, "Failed to acquire cryptographic context!  Last Error = %ld\n", lError);
			return false;
		}

		if(!generate_random_seed())
			return false;

		if(!CryptGenRandom(m_hCryptProv, 
			               (unsigned long)m_nBlockSize, 
						   m_pBlock))
		{
			long lError = GetLastError();
			_RPT1(_CRT_ASSERT, "Failed to generate random bits!  Last Error = %ld\n", lError);
			return false;
		}

		return  true;
	}
	bool generate_random_seed()
	{
		_ASSERTE(m_pBlock != NULL);
		//TODO: Get random bits from Intel or other RNG, if present
		return true;
	}

	std::vector<FILE_ALLOCATED_RANGE_BUFFER> m_AR; // allocated ranges in file
	                                          // for a file that is not sparse 
	                                          // the entire file is the allocated range

	file_and_attributes m_F;                  // The stream that is to be wiped.
	                                          // The "stream" may constitute a file,
	                                          // an alternate stream, a logical volume,
	                                          // a physical storage device.

	HCRYPTPROV m_hCryptProv;                 // Cryptographic provider
	HCRYPTPROV m_hSeedCryptProv;             // Hardware Cryptographic provider (future)
	unsigned char* m_pBlock;      // pointer to fill buffer (FF, random data or zero filled)
	unsigned char* m_pVerify;     // used to read from the wiped file
	size_t m_nBlockSize;   // recommended block size (treated as suggestion)
	long m_lPhase; // phase of wipe operation
	long m_lPattern; //added 8/17/2004
	const wiper_progress& m_Progress;
	bool m_bVerify;
};

} //namespace wipe_v1_0

#endif //_WIPER_V_1_0_H_