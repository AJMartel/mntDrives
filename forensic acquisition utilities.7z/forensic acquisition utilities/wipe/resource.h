//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by wipe.rc
//
#define IDS_E_OS_VERSION                2
#define IDS_HELP                        10
#define IDS_MICROSOFTWINDOWS            12
#define IDS_PERSONAL                    13
#define IDS_PROFESSIONAL                14
#define IDS_DATACENTER                  15
#define IDS_ADVANCEDSERVER              16
#define IDS_SERVER                      17
#define IDS_VERSION                     18
#define IDS_YESORNO                     19
#define IDS_WIPE_PROMPT                 20
#define IDS_Yy                          21
#define IDS_WARNING_WILL_DESTROY        22
#define IDS_MOUNT_VOLUME_REFERS         23
#define IDS_MOUNT_VOLUME_PROMPT         24
#define IDS_Vv                          25
#define IDS_VOLUME_OR_ROOT              26
#define IDS_PROMPT_RESOLVE_LINK         27
#define IDS_LINK_REFERS                 28
#define IDS_LINK_PATH_PROMPT            29
#define IDS_LINK_OR_OBJECT              30
#define IDS_Oo                          31
#define IDS_COMMANDLINE                 32
#define IDS_MODULE                      33
#define IDS_CURRENT_USER                34
#define IDS_NOSTREAMS_WARNING1          35
#define IDS_NOBACKUP_PRIV_WARNING       36
#define IDS_NOSTREAMS_WARNING2          37
#define IDS_WIPE_FAILED                 38
#define IDS_FF_PHASE_BEGIN              39
#define IDS_RANDOM_PHASE_BEGIN          40
#define IDS_ZERO_PHASE_BEGIN            41
#define IDS_PHASE_COMPLETE              42
#define IDS_VERIFYING                   43
#define IDS_OK                          44
#define IDS_FAILED                      45
#define IDS_CHANGE_READONLY_PROMPT      101

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
