/*physmem.c*/

/* Adapted from the source originally published at http://www.sysinternals.com/files/physmem.zip
/* by George M. Garner Jr. 01/07/2002*/

#include <wtypes.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/types.h>
#include <errno.h>
#include <crtdbg.h>
#include "native.h"


	static int initialized = 0;

//
// Functions in NTDLL that we dynamically locate
//

NTUNMAPVIEWOFSECTION NtUnmapViewOfSection;
NTOPENSECTION NtOpenSection;
NTMAPVIEWOFSECTION NtMapViewOfSection;
RTLINITUNICODESTRING RtlInitUnicodeString;
RTLNTSTATUSTODOSERROR RtlNtStatusToDosError;

//--------------------------------------------------------
//
// LocateNtdllEntryPoints
//
// Finds the entry points for all the functions we 
// need within NTDLL.DLL.
//
//--------------------------------------------------------
int initialize_physmem()
{
	if( !(RtlInitUnicodeString = (RTLINITUNICODESTRING) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"), "RtlInitUnicodeString" )) ) 
		return 0;
	if( !(NtUnmapViewOfSection = (NTUNMAPVIEWOFSECTION) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"),	"NtUnmapViewOfSection" )) ) 
		return 0;
	if( !(NtOpenSection = (NTOPENSECTION) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"),	"NtOpenSection" )) ) 
		return 0;
	if( !(NtMapViewOfSection = (NTMAPVIEWOFSECTION) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"), "NtMapViewOfSection" )) ) 
		return 0;
	if( !(RtlNtStatusToDosError = (RTLNTSTATUSTODOSERROR) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"),"RtlNtStatusToDosError" )) ) 
		return 0;
	return 1;
}

//--------------------------------------------------------
//
// OpensPhysicalMemory
//
// This function opens the physical memory device. It
// uses the native API since 
//
//--------------------------------------------------------
uintptr_t open_physical_memory()
{
	NTSTATUS		status;
	HANDLE			hDevice = INVALID_HANDLE_VALUE;
	UNICODE_STRING	deviceString;
	OBJECT_ATTRIBUTES attributes;

	if(!initialized && !(initialized = initialize_physmem()))
			return (uintptr_t)-1;

	RtlInitUnicodeString( &deviceString, L"\\Device\\PhysicalMemory");	

	InitializeObjectAttributes( &attributes, &deviceString,
								OBJ_CASE_INSENSITIVE, NULL, NULL );			
	status = NtOpenSection( &hDevice, SECTION_MAP_READ, &attributes );

	if( !NT_SUCCESS( status )) 
	{
		//SetLastError(RtlNtStatusToDosError(status));
			if(status == STATUS_OBJECT_NAME_NOT_FOUND)
				errno = ENOENT;
			else if (status == STATUS_ACCESS_DENIED)
				errno = EACCES;
			else if (status == STATUS_INVALID_HANDLE)
				errno = EBADF;
			else if(status == STATUS_OBJECT_NAME_INVALID)
				errno = EINVAL;
			else if(status == STATUS_OBJECT_TYPE_MISMATCH)
				errno = EINVAL;

			return (uintptr_t)-1;
	}

	return (uintptr_t)hDevice;
}


//--------------------------------------------------------
//
// MapPhysicalMemory
//
// Maps a view of a section.
//
//--------------------------------------------------------
LPVOID map_physical_memory(intptr_t hMem, LPVOID pMem, size_t offset, size_t nSize)
{
	if(hMem == -1)
		return (LPVOID)0;

	if(pMem != (LPVOID) 0)
		UnmapViewOfFile(pMem);

	return MapViewOfFile((HANDLE)hMem,          // section handle
		                 FILE_MAP_READ, // desired access
						 0UL,
						 (unsigned long)offset,
						 nSize);
}

