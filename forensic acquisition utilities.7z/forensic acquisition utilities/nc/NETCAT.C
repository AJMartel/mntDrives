/* Netcat 1.00 1 951010

   A damn useful little "backend" utility begun 950915 or thereabouts,
   as *Hobbit*'s first real stab at some sockets programming.  Something that
   should have and indeed may have existed ten years ago, but never became a
   standard Unix utility.  IMHO, "nc" could take its place right next to cat,
   cp, rm, mv, dd, ls, and all those other cryptic and Unix-like things.

   Read the README for the whole story, doc, applications, etc.

   Layout:
	conditional includes:
	includes:
	handy defines:
	globals:
	malloced globals:
	cmd-flag globals:
	support routines:
	main:

  todo:
	more of the portability swamp, and an updated generic.h
	frontend progs to generate various packets, raw or otherwise...
	TCHAR-mode [cbreak, fcntl-unbuffered, etc...]
	connect-to-all-A-records hack
  bluesky:
	RAW mode!
	backend progs to grab a pty and look like a real telnetd?!
*/

#include "generic.h"		/* same as with L5, skey, etc */

/* conditional includes -- a very messy section: */
/* #undef _POSIX_SOURCE		/* might need this for something? */
#define HAVE_BIND		/* XXX -- for now, see below... */
#define HAVE_HELP		/* undefine if you dont want the help text */
/* #define ANAL			/* if you want case-sensitive DNS matching */
#ifdef HAVE_STDLIB_H
#include <stdlib.h>
#else
#include <malloc.h>		/* xxx: or does it live in sys/ ?? */
#endif

#include <sys/types.h>		/* *now* do it.  Sigh, this is broken */

#ifdef HAVE_RANDOM
#define SRAND srandom
#define RAND random
#else
#define SRAND srand
#define RAND rand
#endif /* HAVE_RANDOM */

/* xxx: these are rsh leftovers, move to new generic.h */
/* will we even need any nonblocking shit?  Doubt it. */
/* get FIONBIO from sys/filio.h, so what if it is a compatibility feature */
/* #include <sys/filio.h> */
/*
#include <sys/ioctl.h>
#include <sys/file.h>
*/

/* includes: */
#ifdef _WIN32
#include "getopt.h"
#include <winsock2.h>
#include <mswsock.h>
#include <Ws2tcpip.h>
#include <ipexport.h>
#include <tchar.h>
#include <time.h>
#include <fcntl.h>
#include <sys/stat.h> // S_IREAD
#include <io.h>
#include <conio.h>
#include <crtdbg.h>
#include <wincrypt.h>
#include <security.h>
int __stdcall control_handler ( unsigned long sig );
BOOL file_system_supports(const TCHAR* volume, unsigned long dwMask);
size_t adjust_block_size(size_t size, const TCHAR* _Path);
BOOL set_sparse(int fd);
BOOL is_sparse(int fd);
int begin_sparse(size_t rnleft);
int complete_sparse(size_t rnleft);

#define MAX_PROTOCOLS 5
unsigned long o_capabilities = 0UL;
int o_supports_compression = FALSE;

LPCTSTR system_error(long lerror, LPTSTR lpBuf, unsigned long dwSize);
LPWSAPROTOCOL_INFO get_supporting_protocol(LPWSAPROTOCOL_INFO pInfo, int* max_entries, int af, int type, int protocol, unsigned long flags);
SOCKET create_socket(int af, int type, int protocol, unsigned long flags);
#ifdef lseek
#undef lseek
#endif // lseek
#define lseek _lseeki64
#else
#include <sys/time.h>		/* timeval, time_t */
#include <sys/socket.h>		/* basics, SO_ and AF_ defs, sockaddr, ... */
#include <netinet/in.h>		/* sockaddr_in, htons, in_addr */
#include <netinet/in_systm.h>	/* misc crud that netinet/ip.h references */
#include <netinet/ip.h>		/* IPOPT_LSRR, header stuff */
#include <netdb.h>		/* hostent, gethostby*, getservby* */
#include <arpa/inet.h>		/* inet_ntoa */
#include <netsupp.h>
#endif

#include <setjmp.h>		/* jmp_buf et al */

#include <stdio.h>
#include <string.h>		/* strcpy, strchr, yadda yadda */
#include <errno.h>
#include <signal.h>
#include <md5.h>
#include <zlib.h>
#if !defined(HAVE_GETOPT) && !defined(_WIN32) 
  extern TCHAR * optarg;
  extern int optind, optopt;
#endif
TCHAR* program_name = NULL;
#define INPUT_FILE 0
#define OUTPUT_FILE 1
extern int o_disk_device[];
extern int o_disk_file[];
extern int o_physical_drive[];

int is_disk_device(int fd, unsigned int which);
int display_device_info(int fd, const TCHAR* file, unsigned int which);
void cleanup(void);
void* interlocked_exchange_ptr(void* volatile* target, void* value);
TCHAR* full_path(const TCHAR* lpszPath);

/* handy stuff: */
#define SA struct sockaddr	/* socket overgeneralization braindeath */
#define SAI struct sockaddr_in	/* ... whoever came up with this model */
#define IA struct in_addr	/* ... should be taken out and shot, */
				/* ... not that TLI is any better.  sigh.. */
#define SLEAZE_PORT 31337	/* for UDP-scan RTT trick, change if ya want */
#define USHORT unsigned short	/* use these for options an' stuff */
#define BIGSIZ 8192		/* big buffers */
#define SMALLSIZ 256		/* small buffers, hostnames, etc */
#define DEFAULT_BLOCK_SIZE 8192
#define NETBUFFIXUP 2 * (sizeof(struct sockaddr_in) + 16)

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif
#ifdef MAXHOSTNAMELEN
#undef MAXHOSTNAMELEN		/* might be too small on aix, so fix it */
#endif

#ifndef NI_MAXHOST
#define NI_MAXHOST 1025
#endif //NI_MAXHOST
#define MAXHOSTNAMELEN NI_MAXHOST

#define MAX_HOPS 8

#ifndef HAVE_ADDRINFO
typedef struct addrinfo {
    int ai_flags;              /* AI_PASSIVE, AI_CANONNAME, AI_NUMERICHOST */
    int ai_family;             /* PF_xxx */
    int ai_socktype;           /* SOCK_xxx */
    int ai_protocol;           /* 0 or IPPROTO_xxx for IPv4 and IPv6 */
    size_t ai_addrlen;         /* Length of ai_addr */
    TCHAR *ai_canonname;        /* Canonical name for nodename */
    struct sockaddr *ai_addr;  /* Binary address */
    struct addrinfo *ai_next;  /* Next structure in linked list */
} ADDRINFO, FAR * LPADDRINFO;
#endif // HAVE_ADDRINFO

void free_host_poop(ADDRINFO* poop);
ADDRINFO* gates = NULL; /* LSRR hop hostpoop */
ADDRINFO** next_gate = &gates; 

typedef struct port_poop 
{
  char name [64];		/* name in /etc/services */
  char anum [32];		/* ascii-format number */
  USHORT num;			/* real host-order number */
} PINF;

USHORT o_lport;
static int o_lock = FALSE;
int lock_file(int fd, unsigned __int64 size, unsigned int which);
int unlock_file(int fd, unsigned __int64 size, unsigned int which);
int dismount_device(int fd, unsigned int which);

/* globals: */
jmp_buf jbuf;			/* timer crud */
int jval = 0;			/* timer crud */
//SOCKET netfd = INVALID_SOCKET;
SOCKET nnetfd = INVALID_SOCKET;
int ofd = 0;			/* hexdump output fd */
static TCHAR unknown[] = _T("(UNKNOWN)");
static char p_tcp[] = "tcp";	/* for getservby* */
static char p_udp[] = "udp";

#ifndef _WIN32
#ifdef HAVE_BIND
extern int h_errno;
#endif //HAVE_BIND
#endif //_WIN32

#define DEFAULT_LSRR_VALUE 4
int gatesidx = 0;		/* LSRR hop count */
int gatesptr = DEFAULT_LSRR_VALUE;		/* initial LSRR pointer, settable */
USHORT Single = 1;		/* zero if scanning */
size_t insaved = 0;	/* stdin-buffer size for multi-mode */
size_t netsaved = 0;
static int cycle = 0;
static int o_help = 0;
static int o_detach = 0;
static int o_verify = 0;

enum { NETCAT_COMPRESSION_ALGORITHM_UNSUPPORTED = -1,
	NETCAT_COMPRESSION_ALGORITHM_NONE = 0,
	NETCAT_COMPRESSION_ALGORITHM_ZLIB = 1,
	NETCAT_COMPRESSION_ALGORITHM_DEFAULT = NETCAT_COMPRESSION_ALGORITHM_ZLIB,
};

__int64 wrote_out = (__int64) 0;	/* total stdout bytes */
__int64 wrote_net = (__int64) 0;	/* total net bytes */
static TCHAR wrote_txt[] = _T(" sent %I64d, rcvd %I64d");
static char hexnibs[20] = "0123456789abcdef  ";
struct sockaddr_in remend;

char * bigbuf = NULL;		/* data buffers */
//fd_set ding1;			/* for select loop */
PINF portpoop;		/* for getportpoop / getservby* */
//unsigned char * stage = NULL;	/* hexdump line buffer */
//unsigned char* sstage = NULL;
char * randports = NULL;
TCHAR** arrgv = NULL;
size_t o_block = DEFAULT_BLOCK_SIZE;
ALG_ID o_checksum = CALG_NOALG;
ALG_ID string_to_algid(const TCHAR* algorithm);
size_t hash_signature_size(ALG_ID id);
void free_hast_ctx(HCRYPTHASH ctx);
void write_checksum(unsigned char* buffer, size_t len, const TCHAR* ofile);
void write_checksum_fname(FILE* fd, const TCHAR* file);
HCRYPTHASH create_and_initialize_hash_context(ALG_ID algorithm);
void hash_process_block(unsigned char* pBlock, size_t len, HCRYPTHASH ctx);
void hash_process_bytes(unsigned char* pData, size_t len, HCRYPTHASH ctx);
unsigned char* hash_finish_ctx (HCRYPTHASH ctx, unsigned char* buffer, size_t len);


#define MAX_HASHBUFFER_SIZE MD5_SIGNATURE_SIZE

ADDRINFO * ouraddr = NULL;
ADDRINFO * themaddr = NULL;

char local_host[NI_MAXHOST + 1];
char local_service[NI_MAXSERV + 1];
char remote_host[NI_MAXHOST + 1];
char remote_service[NI_MAXHOST + 1];

#ifdef _WIN32
int o_sparse = FALSE;
extern int in_sparse;
extern unsigned char* zbuf;
void init_sparse();
void free_sparse();
HANDLE hEvent = INVALID_HANDLE_VALUE;
#define INVALID_SECTOR_SIZE -1
int o_input_physical_memory = FALSE;
//intptr_t hInputFile = -1;
BOOL is_physical_memory_device(const TCHAR* pinput_file);
uintptr_t open_physical_memory();
LPVOID map_physical_memory(intptr_t hMem, LPCVOID pMem, size_t offset, size_t nSize);
void display_physical_memory();
BOOL bWindowsXP = FALSE;
#endif //_WIN32

#define MAX_ARGUMENTS 128

/* global cmd flags: */
USHORT o_alla = 0;
unsigned int o_interval = 0;
static int o_listen = 0;
static int o_nflag = 0;
static int o_wfile = 0;
static int o_random = 0;
static int o_udpmode = 0;
static int o_verbose = 0;
static unsigned int o_wait = DEFAULT_TIMEOUT;
static int o_zero = 0;

TCHAR* input_file = NULL;
TCHAR* output_file = NULL;

	enum { runtime_handle = 0,
		socket_handle,
		zlib_handle,
#ifdef _WIN32
		native_handle,
#endif //_WIN32
	};
 
struct io_file 
{
	int type;
	union {
		int file;
		SOCKET s;
		gzFile gz;
#ifdef _WIN32
		uintptr_t h;
#endif //_WIN32
	} u;
#ifdef _WIN32
	OVERLAPPED ov;
#endif //_WIN32
};

typedef struct io_file IO_FILE, *PIO_FILE;
static void close_io_file(PIO_FILE pio);

PIO_FILE p_input_fd = (PIO_FILE)0; 
PIO_FILE p_output_fd = (PIO_FILE)0; 

static int o_decompress = NETCAT_COMPRESSION_ALGORITHM_NONE;
static int o_compress = NETCAT_COMPRESSION_ALGORITHM_NONE;
static int parse_compression_algorithm(const TCHAR* algorithm);
static int open_compressed_stream(PIO_FILE pio, int mode, int algorithm, char* buf, size_t len);
static int verify_output_file(PIO_FILE out_fd, unsigned char* hash_buffer, size_t len);

/* Debug macro: squirt whatever to stderr and sleep a bit so we can see it go
   by.  need to call like Debug ((stuff)) [with no ; ] so macro args match!
   Beware: writes to stdOUT... */
#if defined(DEBUG) || defined(_DEBUG)
#ifdef _WIN32
#define Debug0(format) _RPTF0(_CRT_WARN, format) 	
#define Debug1(format, x) _RPTF1(_CRT_WARN, format, x)
#define Debug2(format, x, y) _RPTF2(_CRT_WARN, format, x, y)
#define Debug3(format, x, y, z) _RPTF3(_CRT_WARN, format, x, y, z)
#else
#define Debug0(format) fprintf(stderr, format), fflush (stderr), SLEEP (1000)
#define Debug1(format, x) fprintf(stderr, format, x), fflush (stderr), SLEEP (1000)
#define Debug2(format, x, y) fprintf(stderr, format, x, y), fflush (stderr), SLEEP (1000)
#define Debug3(format, x, y, z) fprintf(stderr, format, x, y, z), fflush (stderr), SLEEP (1000)
#endif //_WIN32
#else
#define Debug0(format)	/* nil... */
#define Debug1(format, x)	/* nil... */
#define Debug2(format, x, y)	/* nil... */
#define Debug3(format, x, y, z)	/* nil... */
#endif

static int cmdline_prompt_yes_or_no(const TCHAR* format, const TCHAR* lpszTarget)
{
	int result = 1;
	int ch;

	_ASSERTE(lpszTarget != NULL);

	_ftprintf(stderr, format, lpszTarget);
		
	fflush(stdin);
	if((ch = _fgettc(stdin)) == EOF ||
		(ch != _T('Y') && ch != _T('y')))
		result = 0;

	return result;
}

void* interlocked_exchange_ptr(void* volatile* target, void* value)
{
#ifdef _WIN32

#if defined(_X86_)
#pragma warning(disable : 4311)
#pragma warning(disable : 4312)
#endif //_X86

	return InterlockedExchangePointer(target, value);

#if defined(_X86_)
#pragma warning(default : 4311)
#pragma warning(default : 4312)
#endif //_X86
#else
	// TODO
#endif //_WIN32
}

SOCKET interlocked_exchange_socket(SOCKET volatile* target, SOCKET value)
{
#ifdef _WIN32
	return (SOCKET) interlocked_exchange_ptr((void* volatile *) target, (void*)value); 
#else
	// TODO
#endif //_WIN32
}

#ifdef _WIN32
int os_write(uintptr_t fd, const unsigned char* buf, size_t size, LPOVERLAPPED ov)
{
	unsigned long dwWritten;
	ULARGE_INTEGER _O;

	if(fd == (uintptr_t) -1)
	{
		errno = EBADF;
#ifdef _WIN32
		SetLastError(ERROR_INVALID_PARAMETER);
#endif //_WIN32
        return -1;
	}
	if(size == 0)
		return 0;

	//If this is an overlapped file, the position pointer is
	// contained in the overlapped structure and we have to 
	// increment it manually.  Store the current offset for later
	// use
	if(ov != NULL)
	{
		_O.LowPart = ov->Offset;
		_O.HighPart = ov->OffsetHigh;
	}

	ResetEvent(ov->hEvent);

	if(!WriteFile((HANDLE) fd,
		          buf, 
				  (unsigned long)size,
				  &dwWritten,
				  ov))
	{
		long lError = GetLastError();
		if(lError != ERROR_IO_PENDING ||
			!GetOverlappedResult((HANDLE) fd,
			                    ov,
								&dwWritten,
								TRUE))
		{
			_RPT3(_CRT_WARN, "Failed writing %ld bytes to %ld: Last Error = %ld\n", size, fd, lError);
			return -1;
		}
	}

	//If this is an overlapped file, the position pointer is
	// contained in the overlapped structure and we have to 
	// increment it manually.
	if(ov != NULL)
	{
		_O.QuadPart += dwWritten;
		ov->Offset = _O.LowPart;
		ov->OffsetHigh = _O.HighPart;
	}
	
	SetLastError(ERROR_SUCCESS);
	return dwWritten;
}

int os_read(uintptr_t fd, unsigned char* buf, size_t size, LPOVERLAPPED ov)
{
	unsigned long dwRead;
	ULARGE_INTEGER _O;

	if(fd == (uintptr_t) -1)
	{
		errno = EBADF;
#ifdef _WIN32
		SetLastError(ERROR_INVALID_PARAMETER);
#endif //_WIN32
        return -1;
	}
	if(size == 0)
		return 0;

	//If this is an overlapped file, the position pointer is
	// contained in the overlapped structure and we have to 
	// increment it manually.  Store the current offset for later
	// use
	if(ov != NULL)
	{
		_O.LowPart = ov->Offset;
		_O.HighPart = ov->OffsetHigh;
	}

	ResetEvent(ov->hEvent);

	if(!ReadFile((HANDLE) fd,
		          buf, 
				  (unsigned long)size,
				  &dwRead,
				  ov))
	{
		long lError = GetLastError();
		if(lError != ERROR_IO_PENDING ||
			!GetOverlappedResult((HANDLE) fd,
			                    ov,
								&dwRead,
								TRUE))
		{
			_RPT3(_CRT_WARN, "Failed reading %ld bytes to %ld: Last Error = %ld\n", size, fd, lError);
			return -1;
		}
	}

	//If this is an overlapped file, the position pointer is
	// contained in the overlapped structure and we have to 
	// increment it manually.
	if(ov != NULL)
	{
		_O.QuadPart += dwRead;
		ov->Offset = _O.LowPart;
		ov->OffsetHigh = _O.HighPart;
	}
	
	SetLastError(ERROR_SUCCESS);
	return dwRead;
}

#define BIG_BUFFER_SIZE 1024
#define DRIVE_TYPE_LENGTH 32

BOOL display_current_user(EXTENDED_NAME_FORMAT NameFormat)
{
	long lError;
	unsigned long dwSize = 0UL;
	TCHAR* pszName;

	if(GetUserNameEx(NameFormat, 
		              NULL,
					  &dwSize) ||
		(lError = GetLastError()) != ERROR_MORE_DATA)
	{
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return FALSE;
	}

	pszName = (TCHAR*)_alloca(dwSize * sizeof(TCHAR));

	if(!GetUserNameEx(NameFormat, 
		              pszName,
					  &dwSize))
	{
		lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return FALSE;
	}

	_ftprintf(stderr, _T("Current User: %s\n"), pszName);
	return TRUE;
}

void display_system_time()
{
	unsigned long dwResult;
	SYSTEMTIME now;
	TIME_ZONE_INFORMATION ti;
	SYSTEMTIME local;

	GetSystemTime(&now);

	_ftprintf(stderr, L"\n%02d/%02d/%d  %02d:%02d:%02d (UTC)\n",
		    now.wDay, now.wMonth, now.wYear,
			now.wHour, now.wMinute, now.wSecond);

	dwResult = GetTimeZoneInformation(&ti);
	
	if(dwResult == TIME_ZONE_ID_INVALID ||
		dwResult == TIME_ZONE_ID_UNKNOWN)
		return;
	
	if(!SystemTimeToTzSpecificLocalTime(&ti, &now, &local))
		return;

	_ftprintf(stderr, L"%02d/%02d/%d  %02d:%02d:%02d (local time)\n\n",
		    local.wDay, local.wMonth, local.wYear,
			local.wHour, local.wMinute, local.wSecond);

}

int display_os_version()
{
	OSVERSIONINFOEX osvi;

	// Try calling GetVersionEx using the OSVERSIONINFOEX structure.
	//
	// If that fails, try using the OSVERSIONINFO structure.

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if(!GetVersionEx ((OSVERSIONINFO *) &osvi))
		return FALSE;

	switch (osvi.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		_ftprintf(stderr, _T("Microsoft Windows: Version %ld.%ld (Build %ld."), 
				osvi.dwMajorVersion, osvi.dwMinorVersion, (osvi.dwBuildNumber & 0xFFFF));
		
		if ( osvi.wProductType == VER_NT_WORKSTATION )
		{
			if( osvi.wSuiteMask & VER_SUITE_PERSONAL )
				_ftprintf(stderr, _T("Personal\n"));
			else
				_ftprintf(stderr, _T("Professional\n"));
		}

		else if ( osvi.wProductType == VER_NT_SERVER )
		{
		   if( osvi.wSuiteMask & VER_SUITE_DATACENTER )
			  _ftprintf(stderr, _T("DataCenter\n"));
		   else if( osvi.wSuiteMask & VER_SUITE_ENTERPRISE )
			  _ftprintf(stderr, _T("Advanced Server\n"));
		   else
			  _ftprintf(stderr, _T("Server\n"));
		}
		if(osvi.szCSDVersion[0] != L'\0')
			_ftprintf(stderr, _T(" %s"), osvi.szCSDVersion);

		_ftprintf(stderr, _T(")\n\n"));
        break;
	default:
		;

   }

   return TRUE; 
}

void banner()
{
	unsigned long dwHandle;
	unsigned char* pbData;
	unsigned long dwSize = GetFileVersionInfoSize(program_name, &dwHandle);
	TCHAR* lpszFileDescription;
	TCHAR* lpszProductVersion;
	TCHAR* lpszLegalCopyright;
	TCHAR* lpszProductName;
	TCHAR* lpszFileVersion;
	TCHAR* lpszComment;

	unsigned int nSize;

	if(dwSize == 0UL)
	{
		_ASSERTE(FALSE);
		return;
	}

	pbData = (unsigned char*)_alloca(dwSize * sizeof(unsigned char));
	if(!GetFileVersionInfo(program_name, dwHandle, dwSize, pbData))
	{
		_ASSERT(FALSE);
		return;
	}

	if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\FileDescription"), 
					  (void**)&lpszFileDescription, 
					  &nSize))
	{
		_ASSERT(FALSE);
		return;
	}

    if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\ProductVersion"), 
					  (void**)&lpszProductVersion, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }

    if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\ProductName"), 
					  (void**)&lpszProductName, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }


     if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\FileVersion"), 
					  (void**)&lpszFileVersion, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }

	 if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\LegalCopyright"), 
					  (void**)&lpszLegalCopyright, 
					  &nSize))
	  {
		 _ASSERT(FALSE);
		  return;
	  }

	 if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\Comments"), 
					  (void**)&lpszComment, 
					  &nSize))
	  {
		 _ASSERT(FALSE);
		  return;
	  }

	 _ftprintf(stderr, _T("%s, %s\n"), lpszProductName, lpszProductVersion);
	_ftprintf(stderr, _T("%s, %s\n"), lpszFileDescription, lpszFileVersion);
	_ftprintf(stderr, _T("%s\n\n"), lpszLegalCopyright);
	_ftprintf(stderr, _T("Command Line: %s\n"), GetCommandLine());
	_ftprintf(stderr, lpszComment);
	_ftprintf(stderr, _T("\n\n"));

	display_os_version();
	display_system_time();
	if(!display_current_user(NameCanonical))
		display_current_user(NameSamCompatible);
}

#else
void banner()
{
	if (show_version)
	{
	  _tprintf (_T("dd (%s) %s\n"), GNU_PACKAGE, VERSION);
	  exit (0);
	}
}
#endif //_WIN32

/* support routines -- the bulk of this thing.  Placed in such an order that
   we don't have to forward-declare anything: */

int helpme(); /* oop */

#if     _INTEGRAL_MAX_BITS >= 64
#pragma message("N.B.: _INTEGRAL_MAX_BITS >= 64")
#endif //_INTEGRAL_MAX_BITS >= 64

BOOL is_numeric(const TCHAR* _N)
{
	unsigned int i;

	if(_N == (const TCHAR*)0 || _N[0] == _T('\0'))
		return FALSE;

	for(i = 0; i < 32, _N[i] != _T('\0'); ++i)
		if(!_istdigit(_N[i]))
			return FALSE;
	return TRUE;
}


/* holler :*/
void _holler ()
{
#ifdef WIN32
	if (h_errno)
	{
		TCHAR szBuf[_MAX_PATH];
		_ftprintf (stderr, system_error(h_errno, szBuf, _MAX_PATH));
	}
#else
	if (errno) 
	{		/* this gives funny-looking messages, but */
		perror (" ");		/* it's more portable than sys_errlist[]... */
	}				/* xxx: do something better.  */
#endif
	else
	fprintf (stderr, "\n");
	fflush (stderr);
} /* holler */

void holler (const TCHAR* format, ...)
{
	int x;
	va_list argptr;

	if(!o_verbose)
		return;

	TRY
	{
		va_start(argptr, format);
		_vftprintf (stderr, format, argptr);
		_holler();
	}
	CATCH_ALL(x);
}

/* bail :
   error-exit handler, callable from anywhere */
void bail (const TCHAR* format, ...)
{
	va_list argptr;

	o_verbose = 1;
	va_start(argptr, format);
	_vftprintf (stderr, format, argptr);
	_holler();
	exit (1);
} /* bail */


#ifdef _WIN32

/* res_init
   winsock needs to be initialized. Might as well do it as the res_init
   call for Win32 */
BOOL is_windows_xp()
{
	OSVERSIONINFOEX osvi;
    DWORDLONG dwlConditionMask = 0;

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	osvi.dwMajorVersion = 5;
	osvi.dwMinorVersion = 1;

	// Initialize the condition mask.
	VER_SET_CONDITION(dwlConditionMask, VER_MAJORVERSION, 
	  VER_GREATER_EQUAL);
	VER_SET_CONDITION(dwlConditionMask, VER_MINORVERSION, 
	  VER_GREATER_EQUAL);

	// Perform the test.
	return VerifyVersionInfo(
	  &osvi, 
	  VER_MAJORVERSION | VER_MINORVERSION,
	  dwlConditionMask);
}

void res_init()
{
WSADATA wsaData; 
int err; 
 
err = WSAStartup(WINSOCK_VERSION, &wsaData); 
 
if (err != 0) 
    /* Tell the user that we couldn't find a useable */ 
    /* winsock.dll.     */ 
    bail(_T("Unable to initialize windows sockets!\n"));
 
/* Confirm that the Windows Sockets DLL supports 1.1.*/ 
/* Note that if the DLL supports versions greater */ 
/* than 1.1 in addition to 1.1, it will still return */ 
/* 1.1 in wVersion since that is the version we */ 
/* requested. */ 
 
if ( LOBYTE( wsaData.wVersion ) != LOBYTE(WINSOCK_VERSION) || 
        HIBYTE( wsaData.wVersion ) != HIBYTE(WINSOCK_VERSION) ) 
	{ 
		/* Tell the user that we couldn't find a useable */ 
		/* winsock.dll. */ 
		bail(_T("Wrong winsock version!\n"));    
    }
	
	hEvent = CreateEvent(NULL, TRUE, FALSE,NULL);
	if(hEvent == INVALID_HANDLE_VALUE)
		bail(_T("failed to create event handle!\n"));

	bWindowsXP = is_windows_xp();
}

LPCTSTR system_error(long lerror, LPTSTR lpBuf, unsigned long dwSize)
{
	if((FormatMessage( 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		lerror,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		lpBuf,
		dwSize,
		NULL 
	)) == 0UL)
		return _T("");

	return lpBuf;
}

#endif //_WIN32

void cleanup()
{
	TCHAR** pp;
	SOCKET s;
	struct addrinfo* themp;
	PIO_FILE pio;

	void* p = interlocked_exchange_ptr(&bigbuf, 0);
	
	if(p != NULL)
		free(p);
	free_sparse();

	p = interlocked_exchange_ptr(&randports, 0);
	if(p != NULL)
		free(p);

	pp = (TCHAR**)interlocked_exchange_ptr((void*)&arrgv, 0);

	if(pp)
	{
		unsigned int i;
		for(i = 1; i < MAX_ARGUMENTS; ++i)
		{
			if(pp[i] == (TCHAR*)0)
				break;
			free(pp[i]);
		}
		free(pp);
	}

//	p = interlocked_exchange_ptr(&sstage, 0);
//	if(p != NULL)
//		free(p);

	pio = (PIO_FILE) interlocked_exchange_ptr(&p_input_fd, 0);
	close_io_file(pio);
	free(pio);

	pio = (PIO_FILE) interlocked_exchange_ptr(&p_output_fd, 0);
	close_io_file(pio);
	free(pio);

//	s = interlocked_exchange_socket(&netfd, INVALID_SOCKET);
//	if(s != INVALID_SOCKET)
//		CLOSESOCKET(s);

	s = interlocked_exchange_socket(&nnetfd, INVALID_SOCKET);
	if(s != INVALID_SOCKET)
		CLOSESOCKET(s);
	
	themp = (struct addrinfo*)interlocked_exchange_ptr(&themaddr, 0);
		free_host_poop(themp);
	themp = (struct addrinfo*)interlocked_exchange_ptr(&ouraddr, 0);
		free_host_poop(themp);
	themp = (struct addrinfo*)interlocked_exchange_ptr(&gates, 0);
		free_host_poop(themp);

	p = interlocked_exchange_ptr(&program_name, 0);
	if(p != NULL)
		free(p);

	p = interlocked_exchange_ptr(&input_file, 0);
	if(p != NULL)
		free(p);

	p = interlocked_exchange_ptr(&output_file, 0);
	if(p != NULL)
		free(p);

//	p = interlocked_exchange_ptr(&stage, 0);
//	if(p != NULL)
//		free(p);

#ifdef _WIN32
	p = interlocked_exchange_ptr(&hEvent, INVALID_HANDLE_VALUE);
	if(p != INVALID_HANDLE_VALUE)
		CloseHandle(p);

	WSACleanup(); 
#endif // _WIN32
  SLEEP (1000);
}

#ifdef _WIN32
void __stdcall handle_termination_request()
{
	__try
	{
		InterlockedExchange(&cycle, 1);

		if(o_listen)
		{
			SOCKET s = nnetfd;
			if(s != INVALID_SOCKET)
				shutdown(s, SD_BOTH );

			if(p_input_fd != NULL)
			{
				_ASSERTE(p_input_fd->type == socket_handle);
				s = p_input_fd->u.s;
				if(s != INVALID_SOCKET)
					shutdown(s, SD_BOTH);
			}

		}
		else
		{
			if(p_output_fd != NULL)
			{
				SOCKET s;
				_ASSERTE(p_output_fd->type == socket_handle ||
					p_output_fd->type == zlib_handle);

				if(p_output_fd->type == socket_handle)
				{
					s = p_input_fd->u.s;
					if(s != INVALID_SOCKET)
						shutdown(s, SD_SEND);
				}
				else if(p_output_fd->type == zlib_handle)
				{
					s = _gz_sockhandle(p_input_fd->u.gz);
					if(s != INVALID_SOCKET)
						shutdown(s, SD_SEND);
				}
			}

		}
	}
	__except(1)
	{
	}
}

#endif //_WIN32

/* catch :
   no-brainer interrupt handler */
void catch ()
{
  errno = 0;
  cycle = 0;
   if (o_verbose > 1)		/* normally we don't care */
    bail (wrote_txt, wrote_net, wrote_out);

  bail (_T(" punt!\n"));
}

/* timeout and other signal handling cruft */
void tmtravel ()
{
#ifdef NTFIXTHIS
  signal (SIGALRM, SIG_IGN);
  alarm (0);
#endif
  if (jval == 0)
    bail (_T("spurious timer interrupt!\n"));
  longjmp (jbuf, jval);
}



UINT theTimer;

/* arm :
   set the timer.  Zero secs arg means unarm  */
void arm (num, secs)
  unsigned int num;
  unsigned int secs;
{

#ifdef WIN32
	HANDLE stdhnd;
	stdhnd = GetStdHandle(STD_OUTPUT_HANDLE);
#ifdef DEBUG
	if (stdhnd != INVALID_HANDLE_VALUE)
		printf("handle is %ld\n", stdhnd);
	else
		printf("failed to get stdhndl\n");
#endif
#else
if (secs == 0) 
{			/* reset */
	signal (SIGALRM, SIG_IGN);
    alarm (0);
    jval = 0;
} 
else 
{				/* set */
    signal (SIGALRM, tmtravel);
    alarm (secs);
    jval = num;
  } /* if secs */
#endif /* WIN32 */
} /* arm */

/* xmalloc :
   malloc up what I want, rounded up to *4, and pre-zeroed.  Either succeeds
   or bails out on its own, so that callers don't have to worry about it. */
unsigned char * xmalloc (size_t size)
{
#ifdef _WIN32
	return malloc(size);
#else
  unsigned int s = (size + 4) & 0xfffffffc;	/* 4GB?! */
  TCHAR * p = malloc (s);
  if (p != NULL)
    memset (p, 0, s);
  else
    bail ("xmalloc %d failed", s);
  return (p);
#endif // _WIN32
} /* xmalloc */

/* findline :
   find the next newline in a buffer; return inclusive size of that "line",
   or the entire buffer size, so the caller knows how much to then write().
   Not distinguishing \n vs \r\n for the nonce; it just works as is... */
unsigned int findline (buf, siz)
  TCHAR * buf;
  unsigned int siz;
{
  register TCHAR * p;
  register int x;
  if (! buf)			/* various sanity checks... */
    return (0);
  if (siz > (unsigned int)o_block)
    return (0);

  x = siz;
  for (p = buf; x > 0; x--) 
  {
    if (*p == '\n') 
	{
		x = (int) (p - buf);
		x++;			/* 'sokay if it points just past the end! */
		Debug1("findline returning %d", x);
		return (x);
    }
    p++;
  } /* for */
	Debug1 ("findline returning whole thing: %d", siz);
  return (siz);
} /* findline */

/* comparehosts :
   cross-check the host_poop we have so far against new gethostby*() info,
   and holler about mismatches.  Perhaps gratuitous, but it can't hurt to
   point out when someone's DNS is fukt.  Returns 1 if mismatch, in case
   someone else wants to do something about it. */
int comparehosts (ADDRINFO *poop, struct hostent *hp)
{
	errno = 0;
	SETSOCKERRNO(0);

	_ASSERTE(poop != NULL);
	_ASSERTE(hp != NULL);
/* The DNS spec is officially case-insensitive, but for those times when you
   *really* wanna see any and all discrepancies, by all means define this. */
#ifdef ANAL			
  if (poop->ai_canonname && strcmp (poop->ai_canonname, hp->h_name) != 0) 
  {		/* case-sensitive */
#else
  if (poop->ai_canonname && strcasecmp (poop->ai_canonname, hp->h_name) != 0) 
  {	/* normal */
#endif
		TCHAR canonname[NI_MAXHOST];
		TCHAR hostname[NI_MAXHOST];

#ifdef _UNICODE
		mbstowcs(canonname, poop->ai_canonname, NI_MAXHOST);
		mbstowcs(hostname, hp->h_name, NI_MAXHOST);
#else
		strncpy(canonname, poop->ai_canonname, NI_MAXHOST);
		strncpy(hostname, hp->h_name, NI_MAXHOST);
#endif //_UNICODE

		SETSOCKERRNO(0);
		holler (_T("DNS fwd/rev mismatch: %s != %s"), canonname, hostname);
		return (1);
  }
  return (0);
/* ... do we need to do anything over and above that?? */
} /* comparehosts */

/* gethostpoop :
   resolve a host 8 ways from sunday; return a new host_poop struct with its
   info.  The argument can be a name or [ascii] IP address; it will try its
   damndest to deal with it.  "numeric" governs whether we do any DNS at all,
   and we also check o_verbose for what's appropriate work to do. */
ADDRINFO * gethostpoop (char *host, char* service, int numeric)
{
#ifdef HAVE_ADDRINFO	
	ADDRINFO * poop;
	ADDRINFO hints;

	memset(&hints, 0, sizeof(ADDRINFO));

	hints.ai_flags = AI_PASSIVE | AI_CANONNAME;

	if(numeric)
		hints.ai_flags |= AI_NUMERICHOST;

	hints.ai_family = PF_INET;
	hints.ai_socktype = (o_udpmode)? SOCK_DGRAM : SOCK_STREAM;
	hints.ai_protocol = (o_udpmode)? IPPROTO_UDP : IPPROTO_TCP;

	if(getaddrinfo(host,
		           service,
				   &hints,
				   &poop) == SOCKET_ERROR)
	{
		// this is pretty much critical so bail if the call fails.
		bail(gai_strerror(h_errno));

		// not reached
		return NULL;
	}
#else
	ADDRINFO * poopnext;
	ADDRINFO * pooplast;
	struct sockaddr_in* pSA;
	struct hostent * hostent;
	struct in_addr iaddr;
	register int x;

// This is a reworking of Hobbit's original gethostpoop interms of RFC 2553
// ADDRINFO/gethostinfo.  It is deprecated and has not been fully tested.

/* I really want to strangle the twit who dreamed up all these sockaddr and
   hostent abstractions, and then forced them all to be incompatible with
   each other so you *HAVE* to do all this ridiculous casting back and forth.
   If that wasn't bad enough, all the doc insists on referring to local ports
   and addresses as "names", which makes NO sense down at the bare metal.

   What an absolutely horrid paradigm, and to think of all the people who
   have been wasting significant amounts of time fighting with this stupid
   deliberate obfuscation over the last 10 years... then again, I like
   languages wherein a pointer is a pointer, what you put there is your own
   business, the compiler stays out of your face, and sheep are nervous.
   Maybe that's why my C code reads like assembler half the time... */

/* If we want to see all the DNS stuff, do the following hair --
   if inet_addr, do reverse and forward with any warnings; otherwise try
   to do forward and reverse with any warnings.  In other words, as long
   as we're here, do a complete DNS check on these clowns.  Yes, it slows
   things down a bit for a first run, but once it's cached, who cares? */

	errno = 0;
	SETSOCKERRNO(0);

	poop = (ADDRINFO*)xmalloc(sizeof(ADDRINFO));
	memset(poop, 0, sizeof(ADDRINFO));

	poop->ai_flags = AI_PASSIVE;

	if(numeric)
		poop->ai_flags |= AI_NUMERICHOST;

	poop->ai_family = PF_INET;
	poop->ai_socktype = (o_udpmode)? SOCK_DGRAM : SOCK_STREAM;
	poop->ai_protocol = (o_udpmode)? IPPROTO_UDP : IPPROTO_TCP;

	poop->ai_canonname = (TCHAR*) xmalloc(NI_MAXHOST + 1);
	strncpy (poop->ai_canonname, unknown, NI_MAXHOST);		/* preload it */

	poop->ai_addr = ( struct sockaddr*) xmalloc(sizeof (struct sockaddr_in));
	poop->ai_addrlen = sizeof(SA);
	memset(poop->ai_addr, 0, poop->ai_addrlen);
	pSA = (struct sockaddr_in*) poop->ai_addr;
	pSA->sin_family = AF_INET;
	
	/* see wzv:workarounds.c for dg/ux return-a-struct inet_addr lossage */
	iaddr.s_addr = inet_addr (host);

	if (iaddr.s_addr == INADDR_NONE) 
	{	

		/* here's the great split: names... */
		if (numeric)
		{
			bail ("Can't parse %s as an IP address", host);
		}
		hostent = gethostbyname (host);
		if (! hostent)
		{
			/* failure to look up a name is fatal, since we can't do anything with it */
			/* XXX: h_errno only if BIND?  look up how telnet deals with this */

			bail ("%s: forward host lookup failed: h_errno %d", host, h_errno);
		}
		strncpy (poop->ai_canonname, hostent->h_name, NI_MAXHOST);

		memcpy (&pSA->sin_addr, hostent->h_addr_list[0], sizeof (IA));
		
		pooplast = poop;

		for (x = 1; hostent->h_addr_list[x] && (x < MAX_HOPS); x++) 
		{
			poopnext = (ADDRINFO*) xmalloc(sizeof(ADDRINFO));	
			memset(poopnext->ai_next, 0, sizeof(ADDRINFO));
			poopnext->ai_flags = AI_PASSIVE;
			poopnext->ai_family = PF_INET;
			poopnext->ai_socktype = (o_udpmode)? SOCK_DGRAM : SOCK_STREAM;
			poopnext->ai_protocol = (o_udpmode)? IPPROTO_UDP : IPPROTO_TCP;

			poopnext->ai_addr = ( struct sockaddr*) xmalloc(sizeof (struct sockaddr_in));
			poopnext->ai_addrlen = sizeof(SA);
			memset(poop->ai_addr, 0, poopnext->ai_addrlen);
			pSA = (struct sockaddr_in*) poop->ai_addr;
			pSA->sin_family = AF_INET;
			memcpy (&pSA->sin_addr, hostent->h_addr_list[0], sizeof (IA));

			pooplast->ai_next = poopnext;
			poopnext = pooplast;
		} /* for x -> addrs, part A */

		if (! o_verbose)			/* if we didn't want to see the */
			return (poop);			/* inverse stuff, we're done. */
	/* do inverse lookups in separate loop based on our collected forward addrs,
	since gethostby* tends to crap into the same buffer over and over */
		for(poopnext = poop; poopnext != NULL; poopnext = poopnext->ai_next)
		{
			hostent = gethostbyaddr ((TCHAR *)&poopnext->ai_addr, sizeof (IA), AF_INET);
			
			if ((! hostent) || (! hostent-> h_name))
				holler ("Warning: inverse host lookup failed for %s: h_errno %d",
					poopnext->ai_addr, h_errno);
			else
				(void) comparehosts (poopnext, hostent);
		} /* for x -> addrs, part B */
	} 
	else 
	{			
		/* not INADDR_NONE: numeric addresses... */
		memcpy (&pSA->sin_addr, &iaddr, sizeof (IA));

		if (numeric || !o_verbose)			/* if numeric-only, we're done */
			return (poop);

		hostent = gethostbyaddr ((TCHAR *) &iaddr, sizeof (IA), AF_INET);
		/* numeric or not, failure to look up a PTR is *not* considered fatal */
		if (! hostent)
			holler ("%s: inverse host lookup failed: h_errno %d", host, h_errno);
		else 
		{
			strncpy (poop->ai_canonname, hostent->h_name, NI_MAXHOST);
			
			hostent = gethostbyname (poop->ai_canonname);

			if ((! hostent) || (! hostent->h_addr_list[0]))
				holler ("Warning: forward host lookup failed for %s: h_errno %d",
				poop->ai_canonname, h_errno);
			else
				(void) comparehosts (poop, hostent);
		} /* if hostent */
	} /* INADDR_NONE Great Split */

	/* whatever-all went down previously, we should now have a host_poop struct
	with at least one IP address in it. */
	SETSOCKERRNO(0);
#endif //HAVE_ADDRINFO
   return (poop);
} /* gethostpoop */

void free_host_poop(ADDRINFO* poop)
{
#ifdef HAVE_ADDRINFO
	if(poop != NULL)
		freeaddrinfo(poop);
#else
	ADDRINFO* next;

	for(next = poop; ; next != NULL)
	{
		ADDRINFO* previous = next;

		if(next->ai_canonname != NULL)
			free(next->ai_canonname);
		if(next->ai_addr != NULL)
			free(next->ai_addr);
		next = next->ai_next;
		free(previous);
	}
#endif //HAVE_ADDRINFO
}

/* getportpoop :
   Same general idea as gethostpoop -- look up a port in /etc/services, fill
   in global port_poop, but return the actual port *number*.  Pass ONE of:
	pstring to resolve stuff like "23" or "exec";
	pnum to reverse-resolve something that's already a number.
   If o_nflag is on, fill in what we can but skip the getservby??? stuff.
   Might as well have consistent behavior here... */
USHORT getportpoop (char* pstring, unsigned int pnum)
{
  struct servent * servent;
#ifndef _WIN32
  register int x;
  register int y;
#else
  u_short x;
  u_short y;
#endif
  char * whichp = (o_udpmode)? p_udp : p_tcp;

  portpoop.name[0] = '?';		/* fast preload */
  portpoop.name[1] = '\0';

/* case 1: reverse-lookup of a number; placed first since this case is much
   more frequent if we're scanning */
  if (pnum) 
  {
    if (pstring)			/* one or the other, pleeze */
      return (0);
    x = pnum;
    if (o_nflag)			/* go faster, skip getservbyblah */
	{
		sprintf (portpoop.anum, "%d", x);	/* always load any numeric specs! */
		portpoop.num = (x & 0xffff);		/* ushort, remember... */
		return (portpoop.num);
	}
    y = htons (x);			/* gotta do this -- see Fig.1 below */
    servent = getservbyport (y, whichp);
    if (servent) 
	{
		y = ntohs (servent->s_port);
		if (x != y)			/* "never happen" */
			holler (_T("Warning: port-bynum mismatch, %d != %d"), x, y);
		strncpy ((char*)&portpoop.name, servent->s_name, sizeof (portpoop.name));
    } /* if servent */

	/* Fall here whether or not we have a valid servent at this point, with
	x containing our [host-order and therefore useful, dammit] port number */
	sprintf (portpoop.anum, "%d", x);	/* always load any numeric specs! */
	portpoop.num = (x & 0xffff);		/* ushort, remember... */
	return (portpoop.num);
  } /* if pnum */
  else if (pstring && pstring[0] != '\0') 

  /* case 2: resolve a string, but we still give preference to numbers instead
   of trying to resolve conflicts.  None of the entries in *my* extensive
   /etc/services begins with a digit, so this should "always work" unless
   you're at 3com and have some company-internal services defined... */
  
  {
    if (pnum)				/* one or the other, pleeze */
      return (0);
    x = atoi (pstring);
    if (x)
      return (getportpoop (NULL, x));	/* recurse for numeric-string-arg */
    if (o_nflag)			/* can't use names! */
      return (0);
    servent = getservbyname (pstring, whichp);
    if (servent) {
      strncpy (portpoop.name, servent->s_name, sizeof (portpoop.name));
      x = ntohs (servent->s_port);
	  {
		sprintf (portpoop.anum, "%d", x);	/* always load any numeric specs! */
		portpoop.num = (x & 0xffff);		/* ushort, remember... */
		return (portpoop.num);
	  }
    } /* if servent */
  } /* if pstring */

  return (0);				/* catches any problems so far */

/* Obligatory netdb.h-inspired rant: servent.s_port is supposed to be an int.
   Despite this, we still have to treat it as a short when copying it around.
   Not only that, but we have to convert it *back* into net order for
   getservbyport to work.  Manpages generally aren't clear on all this, but
   there are plenty of examples in which it is just quietly done.  More BSD
   lossage... since everything getserv* ever deals with is local to our own
   host, why bother with all this network-order/host-order crap at all?!
   That should be saved for when we want to actually plug the port[s] into
   some real network calls -- and guess what, we have to *re*-convert at that
   point as well.  Fuckheads. */

} /* getportpoop */

/* nextport :
   Come up with the next port to try, be it random or whatever.  "block" is
   a ptr to randports array, whose bytes [so far] carry these meanings:
	0	ignore
	1	to be tested
	2	tested [which is set as we find them here]
   returns a USHORT random port, or 0 if all the t-b-t ones are used up. */
USHORT nextport (char *block)
{
  register unsigned int x;
  register unsigned int y;
	
  y = 70000;			/* high safety count for rnd-tries */
  while (y > 0) 
  {
    x = (RAND() & 0xffff);
    if (block[x] == 1) 
	{	/* try to find a not-done one... */
      block[x] = 2;
      break;
    }
    x = 0;			/* bummer. */
    y--;
  } /* while y */
  if (x)
    return (x);

  y = 65535;			/* no random one, try linear downsearch */
  while (y > 0) 
  {		/* if they're all used, we *must* be sure! */
		if (block[y] == 1) 
		{
		block[y] = 2;
		break;
		}
		y--;
  } /* while y */

  if (y)
    return (y);			/* at least one left */

  return (0);			/* no more left! */
} /* nextport */

/* loadports :
   set "to be tested" indications in BLOCK, from LO to HI.  Almost too small
   to be a separate routine, but makes main() a little cleaner... */
void loadports (char* block, USHORT lo, USHORT hi)
{
  USHORT x;

  if (! block)
    bail (_T("loadports: no block?!\n"));
  if ((! lo) || (! hi))
    bail (_T("loadports: bogus values %d, %d"), lo, hi);
  x = hi;
  while (lo <= x) 
  {
    block[x] = 1;
    x--;
  }
} /* loadports */

#ifdef GAPING_SECURITY_HOLE
TCHAR * pr00gie = NULL;			/* global ptr to -e arg */
#ifdef WIN32
BOOL doexec(SOCKET  ClientSocket);  // this is in doexec.c
#else

/* doexec :
   fiddle all the file descriptors around, and hand off to another prog.  Sort
   of like a one-off "poor man's inetd".  This is the only section of code
   that would be security-critical, which is why it's ifdefed out by default.
   Use at your own hairy risk; if you leave shells lying around behind open
   listening ports you deserve to lose!! */
doexec (int fd)
{
  register TCHAR * p;

  dup2 (fd, fileno(stdin));				/* the precise order of fiddlage */
  CLOSE(fd);
  dup2 (fileno(stdin), fileno(stdout));				/* swiped directly out of "inetd". */
  dup2 (fileno(stdin), fileno(stderr));
  p = strrchr (pr00gie, '/');		/* shorter argv[0] */
  if (p)
    p++;
  else
    p = pr00gie;
Debug2 (("gonna exec %s as %s...", pr00gie, p))
  execl (pr00gie, p, NULL);
  bail ("exec %s failed", pr00gie);	/* this gets sent out.  Hmm... */
} /* doexec */
#endif
#endif /* GAPING_SECURITY_HOLE */

SOCKET prepare_connect(SA * lad)
{
	register SOCKET fd;
	register int rr;
	int setsockopt_c = 1;

	/* grab a socket; set opts */
	if (o_udpmode)
	{
		// try to get a socket that supports pseudo-streams
		// if that doesn't work fall back on a standard connectionless socket
		if((fd = create_socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP, XP1_CONNECTIONLESS | XP1_PSEUDO_STREAM )) == INVALID_SOCKET)
			fd = create_socket (AF_INET, SOCK_DGRAM, IPPROTO_UDP, XP1_CONNECTIONLESS);
	}
	else 
	{
		// try to get a socket that supports connect and disconnect data.
		// if that doesn't work accept a socket that supports guaranteed delivery and ordering
		if((fd = create_socket (AF_INET, SOCK_STREAM, IPPROTO_TCP, XP1_GUARANTEED_DELIVERY | XP1_GUARANTEED_ORDER | XP1_CONNECT_DATA | XP1_DISCONNECT_DATA )) == INVALID_SOCKET)
			fd = create_socket (AF_INET, SOCK_STREAM, IPPROTO_TCP, XP1_GUARANTEED_DELIVERY | XP1_GUARANTEED_ORDER);
	}

	if (fd == INVALID_SOCKET)
		bail (_T("Can't get socket\n"));

	rr = setsockopt (fd, SOL_SOCKET, SO_REUSEADDR, (p_setsockopt)&setsockopt_c, sizeof (setsockopt_c));

	if (rr == SOCKET_ERROR)
	    holler (_T("soc reuseaddr failed\n"));		/* ??? */

	if(o_wait != 0)
	{
		setsockopt_c = o_wait;
		rr = setsockopt (fd, SOL_SOCKET, SO_SNDTIMEO, (p_setsockopt)&setsockopt_c, sizeof(setsockopt_c));
		if (rr == SOCKET_ERROR)
			holler (_T("failed setting send timeout\n"));		/* ??? */
		
		rr = setsockopt (fd, SOL_SOCKET, SO_RCVTIMEO, (p_setsockopt)&setsockopt_c, sizeof(setsockopt_c));
		if (rr == SOCKET_ERROR)
			holler (_T("failed setting receive timeout\n"));		/* ??? */
	}

/*  if(o_block != DEFAULT_BLOCK_SIZE)
  {
		setsockopt_c = (int)o_block;
	    rr = setsockopt (fd, SOL_SOCKET, SO_SNDBUF, (p_setsockopt)&setsockopt_c, sizeof(setsockopt_c));
		if (rr == SOCKET_ERROR)
			holler ("failed setting send buffer size");	
	    rr = setsockopt (fd, SOL_SOCKET, SO_RCVBUF, (p_setsockopt)&setsockopt_c, sizeof(setsockopt_c));
		if (rr == SOCKET_ERROR)
			holler ("failed setting receive buffer size");	
  }*/

#ifdef SO_REUSEPORT	/* doesnt exist everywhere... */
  setsockopt_c = 1;
  rr = setsockopt (fd, SOL_SOCKET, SO_REUSEPORT, (p_setsockopt)&setsockopt_c, sizeof (setsockopt_c));
  if (rr == SOCKET_ERROR)
    holler ("soc reuseport failed");		/* ??? */
#endif

	rr = 0;
	if (lad == NULL) 
		return fd;
	/* try a few times for the local bind, a la ftp-data-port... */
	for (setsockopt_c = 4; setsockopt_c > 0; --setsockopt_c) 
	{
		rr = bind (fd, lad, sizeof(SA));
		if (rr == 0)
			break;
		if (h_errno != EADDRINUSE)
		{
			holler(_T("binding to local address failed\n"));
			break;
		}
		else 
		{
			SETSOCKERRNO(0);
			holler (_T("retrying local %s:%s"), local_host, local_service);
			SLEEP (1000);
			SETSOCKERRNO(0);			/* clear from sleep */
		} /* if EADDRINUSE */
	} /* for y counter */

	if (rr == INVALID_SOCKET)
	{
		CLOSESOCKET(fd);	
		bail (_T("Can't grab %s:%d with bind"),	local_host, local_service);
	}

	return fd;
}

/* doconnect :
   do all the socket stuff, and return an fd for one of
	an open outbound TCP connection
	a UDP stub-socket thingie
   with appropriate socket options set up if we wanted source-routing, or
	an unconnected TCP or UDP socket to listen on.
   Examines various global o_blah flags to figure out what-all to do. */
SOCKET doconnect (SOCKET fd, SA* rad, SA * lad)
{
  register int rr;
#ifndef _WIN32
  int x;
  char optbuf[48];
#endif //_WIN32

  errno = 0;
  SETSOCKERRNO(0);

	if(fd != INVALID_SOCKET)
	{
		if(o_udpmode)
			return fd;
		else
			CLOSESOCKET(fd);
	}
	 
	fd = prepare_connect(lad);

	if (o_listen)
  {
   	  return (fd);			/* thanks, that's all for today */
  }

/* rough format of LSRR option and explanation of weirdness.
-Option comes after IP-hdr dest addr in packet, padded to *4, and ihl > 5.
-IHL is multiples of 4, i.e. real len = ip_hl << 2.
-	type 131	1	; 0x83: copied, option class 0, number 3
-	len		1	; of *whole* option!
-	pointer		1	; nxt-hop-addr; 1-relative, not 0-relative
-	addrlist...	var	; 4 bytes per hop-addr
-	pad-to-32	var	; ones, i.e. "NOP"
-
-If we want to route A -> B via hops C and D, we must add C, D, *and* B to the
-options list.  Why?  Because when we hand the kernel A -> B with list C, D, B
-the "send shuffle" inside the kernel changes it into A -> C with list D, B and
-the outbound packet gets sent to C.  If B wasn't also in the hops list, the
-final destination would have been lost at this point.
-
-When C gets the packet, it changes it to A -> D with list C', B where C' is
-the interface address that C used to forward the packet.  This "records" the
-route hop from B's point of view, i.e. which address points "toward" B.  This
-is to make B better able to return the packets.  The pointer gets bumped by 4,
-so that D does the right thing instead of trying to forward back to C.
-
-When B finally gets the packet, it sees that the pointer is at the end of the
-LSRR list and is thus "completed".  B will then try to use the packet instead
-of forwarding it, i.e. deliver it up to some application.
-
-Note that by moving the pointer yourself, you could send the traffic directly
-to B but have it return via your preconstructed source-route.  Playing with
-this and watching "tcpdump -v" is the best way to understand what's going on.
-
-Only works for TCP in BSD-flavor kernels.  UDP is a loss; udp_input calls
-stripoptions() early on, and the code to save the srcrt is notdef'ed.
-Linux is also still a loss at 1.3.x it looks like; the lsrr code is { }...
-*/


/* if any -g arguments were given, set up source-routing.  We hit this after
   the gates are all looked up and ready to rock, any -G pointer is set,
   and gatesidx is now the *number* of hops */
  if (gatesidx) 
  {		/* if we wanted any srcrt hops ... */
		/* don't even bother compiling if we can't do IP options here! */
		/* #ifdef IP_OPTIONS */
#ifdef IP_OPTIONS
#pragma message("Implementing source routing option.")
	    int  x = 0;
		char optbuf[48];
		ADDRINFO* next = gates;

			/* and don't already *have* a srcrt set */
		char *opp = optbuf; /* then do all this setup hair */

		*opp++ = IP_OPT_LSRR;					/* option */

		*opp++ = (TCHAR) (((gatesidx + 1) * sizeof (IA)) + 3) & 0xff;		/* length */
		*opp++ = gatesptr;					/* pointer */

		
		/* opp now points at first hop addr -- insert the intermediate gateways */
		while(next != NULL)
		{
			struct sockaddr_in* addr = (struct sockaddr_in*) next->ai_addr;

			if(addr != NULL)
			{
				memcpy (opp, &addr->sin_addr, sizeof (IA));
				opp += sizeof (IA);
			}
			next = next->ai_next;
			if(++x >= gatesidx)
			{
				_ASSERTE(FALSE);
				break;
			}
		}
		/* and tack the final destination on the end [needed!] */
		memcpy (opp, rad, sizeof (IA));
		opp += sizeof (IA);
		*opp = IP_OPT_NOP;			/* alignment filler */
		/* if empty optbuf */
		/* calculate length of whole option mess, which is (3 + [hops] + [final] + 1),
		and apply it [have to do this every time through, of course] */
		x = ((gatesidx + 1) * sizeof (IA)) + 4;
		rr = setsockopt (fd, IPPROTO_IP, IP_OPTIONS, optbuf, x);
		if (rr == SOCKET_ERROR)
		{
			CLOSESOCKET(fd);
			bail (_T("srcrt setsockopt fuxored\n"));
		}
	} /* if gatesidx */
#endif // IP_OPTIONS

	if (o_udpmode)
  {
   	  return (fd);			/* thanks, that's all for today */
  }

  /* wrap connect inside a timer, and hit it */
  arm (1, o_wait/1000);
  if (setjmp (jbuf) == 0) 
  {
		rr = connect (fd, rad, sizeof (SA));
  } 
  else 
  {				/* setjmp: connect failed... */
    rr = SOCKET_ERROR;
	SETSOCKERRNO(0);
  }
  arm (0, 0);
  SETSOCKERRNO(0);
  if (rr == 0)
    return (fd);

   CLOSESOCKET (fd);
  return (SOCKET_ERROR);
} /* doconnect */

#ifdef _WIN32
LPVOID get_extension_function(SOCKET s, LPGUID func)
{
	unsigned long dwBytesReturned;
	unsigned long dwFlags;
	LPVOID pfnEx = NULL;
	WSAOVERLAPPED ov;

	if(o_udpmode)
		return NULL;
	else if(!ResetEvent(hEvent))
		return NULL;

	memset(&ov, 0, sizeof(WSAOVERLAPPED));
	ov.hEvent = hEvent;

	if(WSAIoctl(s,
		        SIO_GET_EXTENSION_FUNCTION_POINTER,
				func,
				sizeof(GUID),
				&pfnEx,
				sizeof(LPVOID),
				&dwBytesReturned,
				&ov,
				NULL) != NO_ERROR)
	{
		if(h_errno != WSA_IO_PENDING ||
			!WSAGetOverlappedResult(s, &ov, &dwBytesReturned, TRUE, &dwFlags))
		{
			_RPT1(_CRT_WARN, "Failed to get extension pointer, sock error = %ld\n", h_errno);
			return NULL;
		}
	}
	_ASSERTE(dwBytesReturned == sizeof(LPVOID));
	return pfnEx;
}
#endif //_WIN32

int connect_socket(PIO_FILE *out_fd, ADDRINFO * rad, USHORT rp, ADDRINFO * lad, USHORT lp)
{
	int x, flags = 0;
	struct sockaddr_in lclend;

#ifdef _WIN32	
	static GUID guid1 = WSAID_CONNECTEX;

	unsigned long dwBytesSent;
	LPFN_CONNECTEX pfnConnectEx;
	OVERLAPPED ov;

	_ASSERTE(out_fd != NULL);
	if(*out_fd == (PIO_FILE)0)
	{
		*out_fd = (PIO_FILE)xmalloc(sizeof(IO_FILE));
		memset(*out_fd, 0, sizeof(IO_FILE));
		(*out_fd)->u.s = INVALID_SOCKET;
	}
	else
	{
		if((*out_fd)->type != socket_handle)
			close_io_file(*out_fd);
	}

	(*out_fd)->type = socket_handle;

	_ASSERTE(rad && rad->ai_addrlen == sizeof(struct sockaddr_in));
	memcpy(&remend, rad->ai_addr, rad->ai_addrlen);

	remend.sin_port = htons(rp);
	memset(&lclend, 0, sizeof(struct sockaddr_in));

	if(lad != NULL)
	{
		_ASSERTE(lad->ai_addrlen == sizeof(struct sockaddr_in));
		memcpy(&lclend, lad->ai_addr, lad->ai_addrlen);
	}

	if(lp != 0)
	{
		lclend.sin_port = htons(lp);
	}

	if(rad == NULL)
		return FALSE;

	if((*out_fd)->u.s == INVALID_SOCKET ||
		o_udpmode || 
		o_listen ||
		hEvent == INVALID_HANDLE_VALUE ||
		(pfnConnectEx = (LPFN_CONNECTEX) get_extension_function((*out_fd)->u.s, &guid1)) == NULL)
	{
		(*out_fd)->u.s = doconnect((*out_fd)->u.s, (SA*)&remend, (lad != NULL || lp) ? (SA*)&lclend : NULL); 

		if(o_compress != NETCAT_COMPRESSION_ALGORITHM_NONE &&
			(*out_fd)->u.s != INVALID_SOCKET)
		{
			if(!open_compressed_stream(*out_fd, O_BINARY |  O_RDWR, o_compress, NULL, 0))
				bail(_T("unable to open compressed stream"));
		}
		return ((*out_fd)->u.s != INVALID_SOCKET);
	}

	memset(&ov, 0, sizeof(OVERLAPPED));
	ResetEvent(hEvent);
	ov.hEvent = hEvent;

	if(!(*pfnConnectEx)((*out_fd)->u.s,
					   (SA*) &remend,
					   sizeof(struct sockaddr_in),
					   NULL,
					   0UL,
					   &dwBytesSent,
					   &ov))
	{
		if(h_errno != ERROR_IO_PENDING ||
			!GetOverlappedResult((HANDLE)(*out_fd)->u.s, &ov, &dwBytesSent, TRUE))
		{
			_RPT1(_CRT_WARN, "ConnectEx failed, sock error = %ld\n", h_errno);

			// If the error was ERROR_CONNECTION_REFUSED or WSAETIMEDOUT, then we want to 
			// fail this call but hang onto the socket for future calls (e.g. when scanning).
			// If the error is anything else then the socket is screwed so close it.
			if(h_errno != ERROR_CONNECTION_REFUSED &&
				h_errno != WSAETIMEDOUT)
				close_io_file(*out_fd);
			return FALSE;
		}
	}
	
	if(setsockopt((*out_fd)->u.s, 
					SOL_SOCKET, 
					SO_UPDATE_CONNECT_CONTEXT, 
					NULL, 
					0) == SOCKET_ERROR)
	{
			_RPT1(_CRT_WARN, "ConnectEx failed, sock error = %ld\n", h_errno);
			close_io_file(*out_fd);
			return FALSE;
	}

#else
	if(out_fd == (PIO_FILE)0)
	{
		*out_fd = (PIO_FILE)xmalloc(sizeof(IO_FILE));
		memset(out_fd, 0, sizeof(IO_FILE));
		(*out_fd)->u.s = INVALID_SOCKET;
	}
	else
	{
		if((*out_fd)->type != socket_handle)
			close_io_file(*out_fd);
	}

	(*out_fd)->type = socket_handle;
	(*out_fd)->u.s = doconnect(*out_fd->u.s, &remend, (lad != NULL) ? (SA*)&lclend : NULL); 
#endif //_WIN32

	x = sizeof(struct sockaddr_in);

	if(o_nflag)
		flags |= (NI_NUMERICHOST | NI_NUMERICSERV);

	if(o_udpmode)
		flags |= NI_DGRAM;

	if ((*out_fd)->u.s == INVALID_SOCKET ||
		getsockname ((*out_fd)->u.s, (SA *) &lclend, &x) == SOCKET_ERROR)
	{
		return ((*out_fd)->u.s != INVALID_SOCKET);
	}
	else if(getnameinfo((SA*)&remend, 
		            sizeof(struct sockaddr_in), 
					remote_host, 
					NI_MAXHOST, 
					remote_service, 
					NI_MAXSERV, 
					flags) == SOCKET_ERROR)
	{
		
		return ((*out_fd)->u.s != INVALID_SOCKET);
	}

	ouraddr = gethostpoop(local_host, local_service, o_nflag);

	if(o_compress != NETCAT_COMPRESSION_ALGORITHM_NONE)
	{
		if(!open_compressed_stream(*out_fd, O_BINARY |  O_RDWR, o_compress, NULL, 0))
			bail(_T("unable to open compressed stream"));
	}

	return ((*out_fd)->u.s != INVALID_SOCKET);
}

size_t read_hash_from_output_file(int fd, unsigned char* buf, int len)
{
	size_t ret = 0;
	int signature_size;
	u_long algorithm;
	__int64 _S;

	// The checksum will be the last MD5_SIGNATURE_SIZE bytes written to the output file.
	// Rewind the output file pointer MD5_SIGNATURE_SIZE bytes and read the checksum into the 
	// buffer stored in buf and return the number of bytes read.
	_ASSERTE(fd != -1);

	if(lseek(fd, -((int)sizeof(u_long)), SEEK_END) < 0 ||
		 read(fd, (char*)&algorithm, sizeof(u_long)) < 0 ||
		 (signature_size = (int)hash_signature_size(o_checksum = ntohl(algorithm))) == 0 ||
		 signature_size > MAX_HASHBUFFER_SIZE ||
		 signature_size > len)
		 return 0;
	
	if(lseek(fd, -(int)(signature_size + sizeof(__int32)), SEEK_END) < 0 ||
		(len = read(fd, buf, signature_size)) < 0)
		return 0;

		
	_ASSERTE(len == MD5_SIGNATURE_SIZE); 					
	ret = len;

	// roll the file pointer back to the beginning of
	// the hash and set the eof marker.
	_S = lseek(fd, -(int)(signature_size + sizeof(__int32)), SEEK_END);

	if(_S > 0)
	{
		// The ANSI chsize() does not support large files
		// and there is no 64-bit version.  If your platform 
		// has a 64-bit version, re-define chsize in generic.h,
		// otherwise you will (should) get a compilter warning about
		// truncating _S to a long.

#ifdef _WIN32
		SetEndOfFile((HANDLE)_get_osfhandle(fd));
#else
			
		chsize(fd, _S);
#endif //_WIN32		
	}
	
	return ret;
}

size_t write_hash_data_to_net(SOCKET s, unsigned char* buf, int len)
{
	size_t ret;
	u_long algorithm = htonl((u_long) o_checksum);

	_ASSERTE(len == hash_signature_size(o_checksum));

	if((ret = send(s, buf, len, 0)) == SOCKET_ERROR) 
		ret = 0;
	else if(send(s, (unsigned char*) &algorithm, sizeof(u_long), 0) == SOCKET_ERROR)
		ret = 0;
	return ret;
}

size_t readwrite_hash_data(SOCKET s, PIO_FILE pio, unsigned char* buf, int len)
{
	size_t ret;

	if(len == 0 || pio == NULL)
		return 0;

	if(o_listen)
	{
		_ASSERTE(pio->type == runtime_handle);

		if(pio->type != runtime_handle)
			return 0;
		ret = read_hash_from_output_file(pio->u.file, buf, len);
	}
	else
	{
		if(o_checksum != CALG_NOALG)
			ret = write_hash_data_to_net(s, buf, len);		
	}
	
	return ret;
}

void disconnect_socket(PIO_FILE pio, unsigned char* buf, size_t* len)
{
#ifdef _WIN32
	unsigned long dwSent;
	LPFN_DISCONNECTEX pfnDisconnectEx;
	OVERLAPPED ov;
	static GUID guid2 = WSAID_DISCONNECTEX;
	SOCKET s;

	_ASSERTE(pio->type == socket_handle ||
		pio->type == zlib_handle);

	if(pio->type == socket_handle)
		s = pio->u.s;
	else
	{
		s = gz_socketdetach(pio->u.gz);
		pio->type = socket_handle;
		pio->u.s = s;
	}
	
	if(s == INVALID_SOCKET ||
		o_udpmode || 
		hEvent == INVALID_HANDLE_VALUE)
	{
		if(s != INVALID_SOCKET && !o_udpmode )
		{
			if(len != NULL)
				*len = readwrite_hash_data(s, p_output_fd, buf, (int) *len);

			// DisconnectEx is not supported on this platform.
			// Fall back on shutdown.
			shutdown(s, o_listen ? SD_BOTH : SD_SEND); 
		}
		else if(o_udpmode)
			return;
	} 
	// this is a great idea but none of the default transport providers
	// support disconnect data right now.
#ifdef SUPPORT_DISCONNECT_DATA
	else if((o_capabilities & XP1_DISCONNECT_DATA) == XP1_DISCONNECT_DATA &&
		len != NULL && *len != (size_t)0) 
	{
		if(o_checksum != CALG_NOALG && len != NULL)
		{
			WSABUF _Buf;
			_Buf.len = (u_long)*len;
			_Buf.buf = buf;
		
			if(o_listen)
			{
				if(WSARecvDisconnect(s, &_Buf) == SOCKET_ERROR)
				{
					holler("Unable to receive disconnect data");
					*len = 0;
				}
				else if(len != NULL)
					*len = _Buf.len;
			}
			else
			{
				if(WSASendDisconnect(s, &_Buf) == SOCKET_ERROR)
					holler("Unable to send disconnect data");
				else if(len != NULL) 
					*len = _Buf.len;
			}
		}
		else if(len != NULL)
			*len = 0;

		// sockets aren't guaranteed reusable after sending or receiving
		// disconnect data.
		close_io_file(pio);
		s = INVALID_SOCKET;
	}
#endif //SUPPORT_DISCONNECT_DATA
	else if((pfnDisconnectEx = 
		  (LPFN_DISCONNECTEX) get_extension_function(s, &guid2)) == NULL)
	{
		if(s != INVALID_SOCKET && !o_udpmode )
		{
			if(len != NULL)
				*len = readwrite_hash_data(s, p_output_fd, buf, (int) *len);

			// DisconnectEx is not supported on this platform.
			// Fall back on shutdown.
			shutdown(s, o_listen ? SD_BOTH : SD_SEND); 
		}

		return;
	}

	if(len != NULL)
		*len = readwrite_hash_data(s, p_output_fd, buf, (int) *len);

	memset(&ov, 0, sizeof(OVERLAPPED));
	ResetEvent(hEvent);
	ov.hEvent = hEvent;

	if(!(*pfnDisconnectEx)(s,
		               &ov,
					   TF_REUSE_SOCKET,
					   0UL))

	{
		if(h_errno != ERROR_IO_PENDING ||
			!GetOverlappedResult((HANDLE)s, &ov, &dwSent, TRUE))
		{
			_RPT1(_CRT_WARN, "DisconnectEx failed, sock error = %ld\n", h_errno);
			CLOSESOCKET(s);
			return;
		}
	}
#else
	if(s == INVALID_SOCKET || o_udpmode)
	{
		if( len != NULL)
			*len = 0;
		return s;
	}

	if(len != NULL)
		*len = readwrite_hash_data(s, output_fd, buf, (int) *len);
	shutdown(s, o_listen ? SD_BOTH : SD_SEND); 
#endif //_WIN32
}

SOCKET accept_udp_connection(SOCKET s, SA* from)
{
	int x, rr;

#ifdef IP_OPTIONS
	char optbuf[40];
#endif //IP_OPTIONS

	if(s == INVALID_SOCKET)
	{
		s = doconnect(s, NULL, from); 
		if(s == INVALID_SOCKET)
			bail(_T("unable to get socket\n"));
	}

	/* apparently UDP can listen ON */
	if (from == NULL || 
		((struct sockaddr_in*) from)->sin_port == 0)				/* "port 0",  but that's not useful */
	{
        CLOSESOCKET(s);
		bail (_T("UDP listen needs -p arg\n"));
	}

/* UDP is a speeeeecial case -- we have to do I/O *and* get the calling
   party's particulars all at once, listen() and accept() don't apply.
   At least in the BSD universe, however, recvfrom/PEEK is enough to tell
   us something came in, and we can set things up so straight read/write
   actually does work after all.  Yow.  YMMV on strange platforms!  */
	x = sizeof (SA);		/* retval for recvfrom */
	_ASSERTE(bigbuf != NULL);
	rr = recvfrom		/* and here we block... */
		(s, bigbuf, (int) o_block, 0UL, (SA *) &remend, &x);

	if(rr == SOCKET_ERROR)
	{
		if(from)
			holler(_T("Failed listening on udp %s %ld, sock error = %ld\n"),
			inet_ntoa(((struct sockaddr_in*) from)->sin_addr), ntohl(((struct sockaddr_in*) from)->sin_port), h_errno);

#ifdef _WIN32
		RaiseException(WSAEBADF, EXCEPTION_NONCONTINUABLE, 0, 0); 
#endif 
		return INVALID_SOCKET;
	}

	netsaved = rr;

	if(o_verbose)
	{
		char buf[_MAX_PATH];
		char num_buf[32];
#ifdef _UNICODE 
		__wchar_t wbuf[_MAX_PATH];
#endif //_UNICODE 

		/* find out what address the connection was *to* on our end, in case we're
		doing a listen-on-any on a multihomed machine.  This allows one to
		offer different services via different alias addresses, such as the
		"virtual web site" hack. */
		strcpy (buf, "connecting to [");	/* buffer reuse... */
		strcat (buf, inet_ntoa (remend.sin_addr));
		strcat(buf, " ");
		strcat (buf, itoa(ntohs (remend.sin_port), num_buf, 10));
		strcat(buf, "]");

		SETSOCKERRNO(0);

#ifdef _UNICODE
		mbstowcs(wbuf, buf, _MAX_PATH);
		holler(wbuf);
#else
		holler (buf);
#endif //_UNICODE
#ifdef IP_OPTIONS 
#pragma message("Compiling with IP_OPTIONS support.")

		/* If we can, look for any IP options.  Useful for testing the receiving end of
		such things, and is a good exercise in dealing with it.  We do this before
		the connect message, to ensure that the connect msg is uniformly the LAST
		thing to emerge after all the intervening crud.  Doesn't work for UDP on
		any machines I've tested, but feel free to surprise me. */
		x = sizeof(optbuf);
		rr = getsockopt (s, IPPROTO_IP, IP_OPTIONS, optbuf, &x);
		if (rr == SOCKET_ERROR)
				holler (_T("getsockopt failed\n"));
		Debug1("ipoptions ret len %d", x);
		if (x) 
		{				/* we've got options, lessee em... */
			unsigned char * q = optbuf;
			char * p = buf;		/* local variables, yuk! */
			char * pp = &buf[128];	/* get random space farther out... */
			memset(buf, 0, 256);	/* clear it all first */
			while (x > 0) 
			{
				sprintf (pp, "%2.2x ", *q);	/* clumsy, but works: turn into hex */
				strcat (p, pp);			/* and build the final string */
				q++; p++;
				x--;
			}
			
			SETSOCKERRNO(0);
			holler (_T("IP options: \n"));
			
			SETSOCKERRNO(0);
#ifdef _UNICODE
			mbstowcs(wbuf, buf, _MAX_PATH);
			holler(wbuf);
#else
			holler(buf);
#endif //_UNICODE
		} /* if x, i.e. any options */
#endif /* IP_OPTIONS */
	}
	
	return s;
}

SOCKET accept_tcp_connection(SOCKET s, SA* from)
{
	int rr;
	struct sockaddr_in lclend;
	int x = sizeof (struct sockaddr_in);		/* retval for accept */
	
#ifdef _WIN32
	OVERLAPPED ov;
	int lc_len = sizeof(struct sockaddr_in);
	int rem_len = sizeof(struct sockaddr_in);
	unsigned long dwReceived;
	struct sockaddr * lc, *rm;
#endif // _WIN32

#ifdef IP_OPTIONS
	char optbuf[40];
#endif //IP_OPTIONS
	
	if(nnetfd == INVALID_SOCKET)
	{
		nnetfd = doconnect(INVALID_SOCKET, NULL, from); 
		if(nnetfd == INVALID_SOCKET)
			bail(_T("unable to get socket\n"));
	}

	rr = listen (nnetfd, 1);		/* gotta listen() before we can get */
    if (rr ==SOCKET_ERROR)				/* our local random port.  sheesh. */
	{
#ifdef _WIN32
		RaiseException(WSAEBADF, EXCEPTION_NONCONTINUABLE, 0, 0); 
#endif 
		return INVALID_SOCKET;
	}
	
/* I can't believe I have to do all this to get my own goddamn bound address
   and port number.  It should just get filled in during bind() or something.
   All this is only useful if we didn't say -p for listening, since if we
   said -p we *know* what port we're listening on.  At any rate we won't bother
   with it all unless we wanted to see it, although listening quietly on a
   random unknown port is probably not very useful without "netstat". */
  if (o_verbose) 
  {
		char buf[_MAX_PATH];
		char num_buf[32];
#ifdef _UNICODE
		__wchar_t wbuf[_MAX_PATH];
#endif //_UNICODE

	   x = sizeof (SA);		/* how 'bout getsockNUM instead, pinheads?! */
		rr = getsockname (nnetfd, (SA *) &lclend, &x);
		if (rr == SOCKET_ERROR)
			holler (_T("local getsockname failed\n"));
		strcpy (buf, "listening on [");	/* buffer reuse... */
		if (lclend.sin_addr.s_addr)
			strcat (buf, inet_ntoa (lclend.sin_addr));
		else
			strcat (buf, "any");

		strcat (buf, "] ");
		strcat(buf, itoa(ntohs (lclend.sin_port), num_buf, 10));
		strcat(buf, "...");
		
		SETSOCKERRNO(0);
#ifdef _UNICODE
		mbstowcs(wbuf, buf, _MAX_PATH);
		holler(wbuf);
#else
		holler (buf);
#endif //_UNICODE
  } /* verbose -- whew!! */

#ifdef _WIN32
	if(s == INVALID_SOCKET)
	{
		s = socket (AF_INET, SOCK_STREAM, IPPROTO_TCP);		
		if (s == INVALID_SOCKET)
			bail (_T("Can't get socket\n"));
	}
	
	_ASSERTE(hEvent != INVALID_HANDLE_VALUE);
	memset(&ov, 0, sizeof(OVERLAPPED));
	ResetEvent(hEvent);
	ov.hEvent = hEvent;

	if(!AcceptEx(nnetfd, 
		         s, 
				 bigbuf, 
				 (unsigned long)(o_block), 
				 NETBUFFIXUP/2, 
	             NETBUFFIXUP/2, 
				 &dwReceived, 
				 &ov))
		{
			if(h_errno != ERROR_IO_PENDING ||
				!GetOverlappedResult((HANDLE) nnetfd, &ov, &dwReceived, TRUE))
			{
				_RPT1(_CRT_WARN, "AcceptEx failed, sock error = %ld\n", h_errno);
				CLOSESOCKET(s);
				return INVALID_SOCKET;
			}
		}
	_ASSERTE(dwReceived <= (unsigned long)(o_block + NETBUFFIXUP));
	netsaved = dwReceived;// - NETBUFFIXUP;

	if(setsockopt(s, 
					SOL_SOCKET, 
					SO_UPDATE_ACCEPT_CONTEXT, 
					(char*) &nnetfd, 
					sizeof(nnetfd)) == SOCKET_ERROR)
	{
			_RPT1(_CRT_ASSERT, "SO_UPDATE_ACCEPT_CONTEXT failed, sock error = %ld\n", h_errno);
			CLOSESOCKET(s);
			return INVALID_SOCKET;
	}
		
	if(o_verbose)
	{
		GetAcceptExSockaddrs(bigbuf,       
							 (unsigned long) o_block,
							 NETBUFFIXUP/2, 
							 NETBUFFIXUP/2,
							 &lc,
							 &lc_len,
							 &rm,
							 &rem_len);
		
		_ASSERTE(lc_len == sizeof(struct sockaddr_in));
		memcpy(&lclend, lc, lc_len);
		_ASSERTE(rem_len == sizeof(struct sockaddr_in));
		memcpy(&remend, rm, rem_len);
  	}  
#else
	
	if(s != INVALID_SOCKET)
		CLOSESOCKET(s);
	s = accept (nnetfd, (SA*)&remend, &x);

	if(s == INVALID_SOCKET)
		return s;

	x = sizeof (SA);		/* how 'bout getsockNUM instead, pinheads?! */
	rr = getsockname (s, (SA*)&lclend, &x);
	if (rr == SOCKET_ERROR)
		holler ("local getsockname failed");
#endif //_WIN32

	if(o_verbose)
	{
		char buf[_MAX_PATH];
		char num_buf[32];
#ifdef _UNICODE
		__wchar_t wbuf[_MAX_PATH];
#endif //_UNICODE
		/* find out what address the connection was *to* on our end, in case we're
		doing a listen-on-any on a multihomed machine.  This allows one to
		offer different services via different alias addresses, such as the
		"virtual web site" hack. */
		strcpy (buf, "connecting on [");	/* buffer reuse... */
		strcat (buf, inet_ntoa (lclend.sin_addr));
		strcat(buf, " ");
		strcat (buf, itoa(ntohs (lclend.sin_port), num_buf, 10));
		strcat(buf, "] to [");
		strcat (buf, inet_ntoa (remend.sin_addr));
		strcat(buf, " ");
		strcat (buf, itoa(ntohs (remend.sin_port), num_buf, 10));
		strcat(buf, "]");

		SETSOCKERRNO(0);
#ifdef _UNICODE
		mbstowcs(wbuf, buf, _MAX_PATH);
		holler(wbuf);
#else
		holler (buf);
#endif //_UNICODE
#ifdef IP_OPTIONS 
		/* If we can, look for any IP options.  Useful for testing the receiving end of
		such things, and is a good exercise in dealing with it.  We do this before
		the connect message, to ensure that the connect msg is uniformly the LAST
		thing to emerge after all the intervening crud.  Doesn't work for UDP on
		any machines I've tested, but feel free to surprise me. */
		x = 40;
		rr = getsockopt (s, IPPROTO_IP, IP_OPTIONS, optbuf, &x);
		if (rr < 0)
				holler (_T("getsockopt failed\n"));
		Debug1 ("ipoptions ret len %d", x);
		if (x) 
		{				/* we've got options, lessee em... */
			unsigned char * q = optbuf;
			char * p = buf;		/* local variables, yuk! */
			char * pp = &buf[128];	/* get random space farther out... */
			memset(buf, 0, 256 * sizeof(char));	/* clear it all first */
			while (x > 0) 
			{
				sprintf (pp, "%2.2x ", *q);	/* clumsy, but works: turn into hex */
				strcat (p, pp);			/* and build the final string */
				q++; p++;
				x--;
			}
			
			SETSOCKERRNO(0);
			holler (_T("IP options: \n"));
#ifdef _UNICODE
			mbstowcs(wbuf, buf, _MAX_PATH);
			holler(wbuf);
#else
			holler(buf);
#endif //_UNICODE
		} /* if x, i.e. any options */
#endif /* IP_OPTIONS */
	}
	return s;
}

SOCKET do_accept(SOCKET s, char* lh, USHORT ls)
{
	SOCKET client = INVALID_SOCKET;
	struct sockaddr_in lclend;
	lclend.sin_family = AF_INET;
	lclend.sin_addr.s_addr = inet_addr(lh);

	lclend.sin_port = htons(ls);

	/* Pass everything off to doconnect, who in o_listen mode just gets a socket */
	if (o_udpmode) 
		client = accept_udp_connection(s, (SA*)&lclend);
	else
		client= accept_tcp_connection(s, (SA*)&lclend);

	return client;
}

/* dolisten :
   just like doconnect, and in fact calls a hunk of doconnect, but listens for
   incoming and returns an open connection *from* someplace.  If we were
   given host/port args, any connections from elsewhere are rejected.  This
   in conjunction with local-address binding should limit things nicely... */
int dolisten (PIO_FILE *in_fd, char* rh, USHORT rs, char * lh, USHORT ls)
{
	int flags = 0;
	ADDRINFO* whozis = NULL;
	struct sockaddr_in* them;
	struct sockaddr_in* maybe_them;

	_ASSERTE(in_fd != NULL);

#ifdef _WIN32
	__try
	{
#endif //_WIN32

		if(*in_fd == (PIO_FILE)0)
		{
			*in_fd = (PIO_FILE)xmalloc(sizeof(IO_FILE));
			memset(*in_fd, 0, sizeof(IO_FILE));
		}
		else
			close_io_file(*in_fd);

		(*in_fd)->u.s = INVALID_SOCKET;
		(*in_fd)->type = socket_handle;
		(*in_fd)->u.s = do_accept((*in_fd)->u.s, lh, ls);

		if(o_nflag)
			flags |= (NI_NUMERICHOST | NI_NUMERICSERV);

		if(o_udpmode)
			flags |= NI_DGRAM;
		
		if((*in_fd)->u.s == INVALID_SOCKET ||
			getnameinfo((SA*)&remend, 
						sizeof(struct sockaddr_in), 
						remote_host, 
						NI_MAXHOST, 
						remote_service, 
						NI_MAXSERV, 
						flags) == SOCKET_ERROR)
		{
			return 0;
		}

		/* now check out who it is.  We don't care about mismatched DNS names here,
		but any ADDR and PORT we specified had better fucking well match the caller.
		Converting from addr to inet_ntoa and back again is a bit of a kludge, but
		gethostpoop wants a string and there's much gnarlier code out there already,
		so I don't feel bad.
		The *real* question is why BFD sockets wasn't designed to allow listens for
		connections *from* specific hosts/ports, instead of requiring the caller to
		accept the connection and then reject undesireable ones by closing. */

		if((themaddr = gethostpoop(remote_host, remote_service, o_nflag)) == NULL)
		{
			return 0;
		}
		
		maybe_them = (struct sockaddr_in*) themaddr->ai_addr;
		if(maybe_them == NULL)
		{
			return 0;
		}

		if(rs != 0)
		{
			if(ntohs (maybe_them->sin_port) != rs)
			{
				if(themaddr && themaddr->ai_addr != NULL)
					bail (_T("invalid connection to %s [%d]"), themaddr->ai_canonname, ((struct sockaddr_in*)themaddr->ai_addr)->sin_port);
				else
					bail(_T("invalid connection"));
			}
		}

		if(rh != NULL && rh[0] != '\0')
		{
			char name_buf[32];

			if(rh && 
				(whozis = gethostpoop(rh, itoa(rs, name_buf, 10), o_nflag)) != NULL)
			{
				them = (struct sockaddr_in*) whozis->ai_addr;
				
				if(them != NULL && 
					memcmp (&maybe_them->sin_addr, &them->sin_addr, sizeof(IA)) != 0)
				{
#ifdef _UNICODE
					__wchar_t wremote_host[NI_MAXHOST];
					__wchar_t wremote_service[NI_MAXSERV];

					mbstowcs(wremote_host, remote_host, NI_MAXHOST);
					mbstowcs(wremote_service, remote_service, NI_MAXSERV);
#endif //_UNICODE
					free_host_poop(whozis);
#ifdef _UNICODE
					bail (L"invalid connection to %s [%s]", wremote_service, wremote_host);
#else
					bail ("invalid connection to %s [%s]", remote_service, remote_host);
#endif //_UNICODE
				}
			}
		}

		if(o_decompress != NETCAT_COMPRESSION_ALGORITHM_NONE)
		{
			if(!open_compressed_stream(*in_fd, O_BINARY | O_RDONLY, o_decompress, bigbuf, netsaved))
				bail(_T("unable to open compressed stream"));
			netsaved = 0;
		}

#ifdef _WIN32			
	}
	__finally
	{
#endif //_WIN32
		if(whozis)
		{
			free_host_poop(whozis);
			whozis = NULL;
		}
#ifdef _WIN32
	}
#endif //_WIN32

	return 1;				/* open! */
} /* dolisten */

/* udptest :
   fire a couple of packets at a UDP target port, just to see if it's really
   there.  On BSD kernels, ICMP host/port-unreachable errors get delivered to
   our socket as ECONNREFUSED write errors.  On SV kernels, we lose; we'll have
   to collect and analyze raw ICMP ourselves a la satan's probe_udp_ports
   backend.  Guess where could swipe the appropriate code from...

   Use the time delay between writes if given, otherwise use the "tcp ping"
   trick for getting the RTT.  [I got that idea from pluvius, and warped it.]
   Return either the original fd, or clean up and return SOCKET_ERROR. */
BOOL test_socket(SOCKET fd, SA* where)
{
  register int rr, saved_wait;
  char a, b;
  
  if(fd == INVALID_SOCKET)
	  return FALSE;
  else if(!o_udpmode || !o_zero)
	  return TRUE;
  else if(where == NULL)
	  return FALSE;
  else
  {
		rr = sendto(fd, &a, 1, 0UL, where, sizeof(SA));
		_RPT2(_CRT_WARN, "sendto returned %ld, sock error = %ld\n", rr, h_errno);

		if (rr != SOCKET_ERROR)
				return TRUE;
		else if (o_wait)
			SLEEP (o_wait);
		else 
		{
			register SOCKET client = INVALID_SOCKET;
			struct sockaddr_in to;

			memcpy(&to, where, sizeof(SA));
			to.sin_port = SLEAZE_PORT;

			/* use the tcp-ping trick: try connecting to a normally refused port, which
			causes us to block for the time that SYN gets there and RST gets back.
			Not completely reliable, but it *does* mostly work. */

			o_udpmode = 0;			/* so doconnect does TCP this time */

			
			/* Set a temporary connect timeout, so packet filtration doesnt cause
			us to hang forever, and hit it */
			saved_wait = o_wait;
			o_wait = 5000;				/* XXX: enough to notice?? */

			client = doconnect (client, (SA*)&to, NULL);
			if (client != INVALID_SOCKET)
				CLOSESOCKET (client);
			o_wait = saved_wait;				/* reset it */
			o_udpmode++;			/* we *are* still doing UDP, right? */
		} /* if o_wait */
	  
		errno = 0;				/* clear from sleep */
		rr = sendto(fd, &b, 1, 0UL, where, sizeof(SA));

		if (rr != SOCKET_ERROR)				/* if write error, no UDP listener */
			return TRUE;
	}
	return (FALSE);
} /* udptest */

#if 0
 /* oprint :
   Hexdump bytes shoveled either way to a running logfile, in the format:
D offset       -  - - - --- 16 bytes --- - - -  -     # .... ascii .....
   where "which" sets the direction indicator, D:
	0 -- sent to network, or ">"
	1 -- rcvd and printed to stdout, or "<"
   and "buf" and "n" are data-block and length.  If the current block generates
   a partial line, so be it; we *want* that lockstep indication of who sent
   what when.  Adapted from dgaudet's original example -- but must be ripping
   *fast*, since we don't want to be too disk-bound... */
void oprint (int which, char* buf, int n)
{
  int bc;			/* in buffer count */
  __int64 obc;			/* current "global" offset */
  int soc;			/* stage write count */
  register unsigned char * p;	/* main buf ptr; m.b. unsigned here */
  register unsigned char * op;	/* out hexdump ptr */
  register unsigned char * a;	/* out asc-dump ptr */
  register int x;
  register unsigned int y;

  if (! ofd)
    bail (_T("oprint called with no open fd?!\n"));
  if (n == 0)
    return;

  op = sstage;
  if (which) 
  {
    *op = '<';
    obc = wrote_out;		/* use the globals! */
  } 
  else 
  {
    *op = '>';
    obc = wrote_net;
  }
  op++;				/* preload "direction" */
  *op = ' ';
  p = (unsigned char *) buf;
  bc = n;
  stage[59] = '#';		/* preload separator */
  stage[60] = ' ';

  while (bc) 
  {			/* for chunk-o-data ... */
    x = 16;
    soc = 78;			/* len of whole formatted line */
    if (bc < x) 
	{
      soc = soc - 16 + bc;	/* fiddle for however much is left */
      x = (bc * 3) + 11;	/* 2 digits + space per, after D & offset */
      op = &stage[x];
      x = 16 - bc;
      while (x) 
	  {
	*op++ = ' ';		/* preload filler spaces */
	*op++ = ' ';
	*op++ = ' ';
	x--;
      }
      x = bc;			/* re-fix current linecount */
    } /* if bc < x */

    bc -= x;			/* fix wrt current line size */
    sprintf (sstage + 2, "%8.8I64x ", obc);		/* xxx: still slow? */
    obc += x;			/* fix current offset */
    op = sstage + 11;		/* where hex starts */
    a = sstage + 61;		/* where ascii starts */

    while (x) 
	{			/* for line of dump, however long ... */
      y = (int)(*p >> 4);	/* hi half */
      *op = hexnibs[y];
      op++;
      y = (int)(*p & 0x0f);	/* lo half */
      *op = hexnibs[y];
      op++;
      *op = ' ';
      op++;
      if ((*p > 31) && (*p < 127))
	*a = *p;		/* printing */
      else
	*a = '.';		/* nonprinting, loose def */
      a++;
      p++;
      x--;
    } /* while x */
    *a = '\n';			/* finish the line */
    x = write (ofd, sstage, soc);
    if (x < 0)
      bail (_T("ofd write err\n"));
  } /* while bc */
} /* oprint */

#endif // 0
#ifdef TELNET
static int o_tn = 0;		/* global -t option */

/* atelnet :
   Answer anything that looks like telnet negotiation with don't/won't.
   This doesn't modify any data buffers, update the global output count,
   or show up in a hexdump -- it just shits into the outgoing stream.
   Idea and codebase from Mudge@l0pht.com. */
void atelnet (SOCKET fd, unsigned char* buf, size_t size)
{
  static unsigned char obuf [4];  /* tiny thing to build responses into */
  register int x;
  register unsigned char y;
  register unsigned char * p;

  y = 0;
  p = buf;
  x = (int) size;
  while (x > 0) 
  {
    if (*p != 255)			/* IAC? */
	{
      ++p; --x;
	  continue;
	}

    obuf[0] = 255;
    p++; x--;
    if ((*p == 251) || (*p == 252))	/* WILL or WONT */
      y = 254;				/* -> DONT */
    if ((*p == 253) || (*p == 254))	/* DO or DONT */
      y = 252;				/* -> WONT */
    if (y) {
      obuf[1] = y;
      p++; x--;
      obuf[2] = *p;			/* copy actual option byte */
      (void) WRITE (fd, obuf, 3);
/* if one wanted to bump wrote_net or do a hexdump line, here's the place */
      y = 0;
    } /* if y */

	++p; --x;
  } /* while x */
} /* atelnet */
#endif /* TELNET */

int shovel_to_file(PIO_FILE pio, char* np, size_t len)
{
	int rr = SOCKET_ERROR;
	_ASSERTE(np != NULL);
	_ASSERTE(pio != NULL && 
		(pio->type == runtime_handle || pio->type == zlib_handle));

	if(pio->type == runtime_handle
#ifdef _WIN32
			|| pio->type == native_handle			
#endif //_WIN32
		)
	{
#ifdef _WIN32

		if(len < o_block)
			_ftprintf(stderr, _T("rnleft = %ld\n"), len);

		if(o_sparse && 
			memcmp(np, zbuf, len) == 0)
		{
			rr = begin_sparse(len);
		}
		else
			if((rr = complete_sparse(len)) >= 0)
#endif //_WIN32
			{
				if(pio->type == runtime_handle)
					rr = write(pio->u.file, np, (unsigned int) len);
				else 
					rr = os_write(pio->u.h, np, len, &pio->ov);
			}
	}
	else
	{
		rr = gzwrite(pio->u.gz, np, (unsigned int) len);
	}
	return rr;
}

int shovel_to_net(SOCKET fd, char* np, size_t len)
{
	int rr;

	if(o_udpmode)
		rr = sendto(fd, np, (int) len, 0UL, (SA*) &remend, sizeof(struct sockaddr_in));
	else
		rr = WRITE (fd, np, (int) len);	/* one line, or the whole buffer */
	Debug2 ("wrote %d to net, errno %d\n", rr, errno);
	return rr;
}

int shovel(PIO_FILE out_fd, char* np, size_t left)
{
    USHORT wretry = 8200;		/* net-write sanity counter */
	int total = 0;

	_ASSERTE(out_fd != (PIO_FILE)0);

	/* shovel that shit till they ain't */	
	while(left && wretry)
	{
		int rr;

		// Avoid processor tieups
		Sleep(0);

		/* net write retries sometimes happen on UDP connections */
		if(out_fd->type == runtime_handle ||
			out_fd->type == zlib_handle
#ifdef _WIN32
			|| out_fd->type == native_handle			
#endif //_WIN32
			)
		{
			rr = shovel_to_file(out_fd, np, left);
			Debug3 ("wrote %d to %s, errno %d\n", rr, output_file, errno);			
		}
		else if(out_fd->type == socket_handle)
		{
			rr = shovel_to_net(out_fd->u.s, np, (o_interval)? findline (np, left) : left);
			Debug3 ("wrote %d to %s, errno %d\n", rr, "net", h_errno);			
		}

		if(rr < 0)
		{
			// We don't need to retry writes to a file, or to
			// a tcp port if the error indicates that the connection
			// is permanently screwed.
			if(o_listen || 
				(!o_udpmode && h_errno != ETIMEDOUT))
				break;
			--wretry;
		}
		else
		{
//			if (o_wfile)
//				oprint (fileno(stderr), np, rr);		/* log what got sent */
			
			np += rr;			/* fix up ptrs and whatnot */
			left -= rr;			/* will get sanity-checked above */
			total += rr;

			if(o_listen)
			{
				wrote_out += (__int64) rr;		/* global count */
			}
			else
			{
				wrote_net += (__int64) rr;		/* global count */				
			}
			if (o_interval) 
			{			/* cycle between slow lines, or ... */
				SLEEP (o_interval);
				errno = 0;			/* clear from sleep */
				SETSOCKERRNO(0);
			}
		}
	}

	if (wretry == 0) 
	{			/* is something hung? */
		holler (_T("too many output retries\n"));
		return (SOCKET_ERROR);
	}

	return total;
}

#ifdef _WIN32
// Returns total physical memory in kilobytes
unsigned __int64 physical_memory()
{
	MEMORYSTATUSEX ms;
	ms.dwLength = sizeof(MEMORYSTATUSEX);

	if(!GlobalMemoryStatusEx(&ms))
		return (unsigned __int64)0;

	return ms.ullTotalPhys/(unsigned __int64)1024;
}

void display_physical_memory()
{
	DWORDLONG mem = physical_memory();

	_ftprintf(stderr, _T("Total physical memory reported: %I64d KB\n"), mem);
}

void handle_bad_memory_region(LPVOID Start, LPVOID End)
{
	_ftprintf(stderr, _T("Physical memory in the range 0x%08lx-0x%08lx could not be read.\n"), Start, End);
}

int shovel_physical_memory_to_net(PIO_FILE in_fd, PIO_FILE out_fd, HCRYPTHASH hash_ctx)
{
	LPCVOID bufstart = (LPCVOID)0; /* Input buffer. */
	LPCVOID ibuf = (LPCVOID)0;
	LPVOID BadStart = NULL;
	LPVOID BadLast = NULL;
	BOOL bInBadRegion = FALSE;
	int exit_status = 0;
	int nwritten = 0;
	int records_read = 0;
	unsigned int count = 0;
	long lError = ERROR_SUCCESS;

	_ASSERTE(in_fd != (PIO_FILE) 0 &&
		out_fd != (PIO_FILE) 0);
	_ASSERTE(in_fd->type == native_handle);
	_ASSERTE(out_fd->type == socket_handle);

	_ftprintf(stderr, _T("Copying physical memory...\n\n"));

	SetLastError(lError);

	memset(bigbuf, 0, o_block * sizeof(char));		
	wrote_net = 0;

	__try
	{

		while ((ibuf = map_physical_memory(in_fd->u.h, ibuf, 
					records_read * o_block, o_block)) != NULL || 
			(lError = GetLastError()) != ERROR_INVALID_PARAMETER)
		{
			
			if(ibuf != NULL)
			{
				if(bInBadRegion)
				{
					handle_bad_memory_region(BadStart, BadLast);
					bInBadRegion = FALSE;
				}

				memcpy(bigbuf, ibuf, o_block * sizeof(unsigned char));
			}
			else if(lError == ERROR_INVALID_ADDRESS)
			{
				// Unable to map this region.  
				// Record the start and end of the region and move on.
				
				BadLast = (LPVOID)(records_read * o_block);
				if(!bInBadRegion)
				{
					BadStart = BadLast;
					bInBadRegion = TRUE;
				}
			}
			else
			{
				// Shouldn't reach here.
				_ASSERT(FALSE);
				break;
			}

			records_read++;

			if(hash_ctx != (HCRYPTHASH)0)
				hash_process_block(bigbuf, o_block, hash_ctx);					

			if((nwritten = shovel(out_fd, bigbuf, (int)o_block)) < 0)
			{
				holler (_T("failed writing %s to net"), output_file);
				break;
			}
			else
			{
				//++records_written;
				wrote_net += nwritten;
			}

			memset(bigbuf, 0, o_block * sizeof(unsigned char));		
			SetLastError(ERROR_SUCCESS);
		}
		
		if(bInBadRegion)
		{
			handle_bad_memory_region(BadStart, BadLast);
			bInBadRegion = FALSE;
		}
		
		SETSOCKERRNO(0);
		holler(_T("Stopped reading physical memory:\n\t\n"));
	}
	__except(1)
	{
		holler(_T("Reading from memory at 0xlx generated exception %0xlx\n"), ibuf, GetExceptionCode());
	}

	return (int) wrote_net;
}

int shovel_file_to_net(SOCKET fd, int file)
{
	unsigned long dwBytesSent = 0UL;
	LARGE_INTEGER _S;
	OVERLAPPED ov;

	if(hEvent == INVALID_HANDLE_VALUE)
		return SOCKET_ERROR;

	// Synchronous transfers are faster for small files.
	if(!GetFileSizeEx((HANDLE)_get_osfhandle(file), &_S) ||
		_S.QuadPart < 8192)
		return SOCKET_ERROR;

	memset(&ov, 0, sizeof(OVERLAPPED));

	ResetEvent(hEvent);
	ov.hEvent = hEvent;
	
	_ftprintf(stderr, _T("Copying file to the net using Windows TransmitFile\n"));

	if(lseek(file, 0, SEEK_SET) < 0  ||// non-seeking devices won't work anyway
		!TransmitFile(fd,          // destination socket
					(HANDLE) _get_osfhandle(file), //file to send
					0UL,       // send the whole file
					(unsigned long)o_block,   // send o_block number of bytes at a time
					&ov,       // overlapped structure
					NULL,      // just send file
					TF_DISCONNECT | TF_REUSE_SOCKET | TF_USE_KERNEL_APC)) // flags
	{
		if(h_errno != ERROR_IO_PENDING ||
			!GetOverlappedResult((HANDLE)fd, &ov, &dwBytesSent, TRUE))
		{
			_RPT2(_CRT_WARN, "Failed to transmit file %s:  Last Error = %ld\n", input_file, h_errno);
			holler(_T("Unable to transmit file %s, socket error is %ld"), input_file, h_errno);
			return SOCKET_ERROR;
		}
	}
	SETSOCKERRNO(0);
	holler(_T("sent %ld bytes"), dwBytesSent);
	return dwBytesSent;
}
#endif //_WIN32

/* readwrite :
   handle stdin/stdout/network I/O.  Bwahaha!! -- the select loop from hell.
   In this instance, return what might become our exit status. */
int readwrite (PIO_FILE in_fd, PIO_FILE out_fd)
{
	register int rr;
	register int bSeek = FALSE;   /*Is the input from a seeking device?*/
	size_t left;
	USHORT netretry;		/* net-read retry counter */
	USHORT wfirst;		/* one-shot flag to skip first net read */
	HCRYPTHASH hash_ctx = (HCRYPTHASH)0;  		
	unsigned char hash_buffer[MAX_HASHBUFFER_SIZE];

#ifdef _WIN32
	_ASSERTE(in_fd != (PIO_FILE)0);
	_ASSERTE(out_fd != (PIO_FILE)0);
  // If we are sending a file over the net from a Windows platform
  // we can use the Winsock TransmitFile() extension.
  // This method is incompatible with send interval, and hex dump,
  // and checksum options.  Also, synchronous calls (send()) is faster
  // for small files.
  if(!o_listen &&
	   !o_wfile &&
		!o_interval &&
		!o_udpmode &&
		(in_fd->type == runtime_handle &&
			in_fd->u.file != fileno(stdin)) &&
		o_checksum == CALG_NOALG &&
		o_compress == NETCAT_COMPRESSION_ALGORITHM_NONE &&
		!o_input_physical_memory)
  {
	  rr = shovel_file_to_net(out_fd->u.s, in_fd->u.file);
	  if(rr > 0)
			return 0;
		/* else 
			try it the old fashion way*/
  }

	init_sparse();
#endif // _WIN32

	netretry = 2;
	wfirst = 0;
	left = 0;
	
	if(!o_listen)
		hash_ctx = create_and_initialize_hash_context(o_checksum);

	TRY
	{
#ifdef _WIN32
		if(o_input_physical_memory)
		{
			_ASSERTE(in_fd->type == native_handle);

			rr = shovel_physical_memory_to_net(in_fd, out_fd, hash_ctx);
		}
		else
#endif //_WIN32
		{
			if (insaved) 
			{
				left = insaved; /* preload multi-mode fakeouts */
				_ASSERTE(bigbuf != NULL);

				wfirst = 1;
				if (Single)			/* if not scanning, this is a one-off first */
					insaved = 0;		/* buffer left over from argv construction, */
				else 
				{
					// This is probably superfluous since input_fd will have been 
					// closed the first time through
					if(o_lock)
					{
						if(in_fd != NULL &&
							in_fd->type == runtime_handle)
							unlock_file(in_fd->u.file, (__int64) -1, INPUT_FILE);
					}
					close_io_file(in_fd);		/* so we won't need any more stdin */

				} /* Single */
			} /* insaved */

			if(netsaved)
			{
				left = (int) netsaved;
				netsaved = 0;
			}

			if (o_interval)
				SLEEP (o_interval);		/* pause *before* sending stuff, too */

			errno = 0;			/* clear from sleep, close, whatever */
			SETSOCKERRNO(0);

			wrote_net = 0;
			wrote_out = 0;

			if(!o_listen)
			{
				_ASSERTE(in_fd != NULL);
				if(in_fd->type == runtime_handle)
					bSeek = (lseek(in_fd->u.file, 0, SEEK_SET) >= 0);
				else if(in_fd->type == zlib_handle)
					bSeek = (gztell(in_fd->u.gz) >= 0);
			}

			/* and now the big ol' select shoveling loop ... */
		while (1) 
		{	/* i.e. till the *net* closes! */
			if (wfirst) 
			{			/* any saved stdin buffer? */
			wfirst = 0;			/* clear flag for the duration */
			_ASSERTE(out_fd->type == socket_handle ||
				out_fd->type == zlib_handle);
			rr = shovel(out_fd, bigbuf, left);			/* and go handle it first */
			if(rr ==  SOCKET_ERROR)
				break;

			netretry = 2;
			continue;
			}

			// CTRL-C events are serviced in a separate thread on Windows.
			// Yield the processor for one cycle so that CTRL-C events are
			// scheduled promptly
			if(o_listen)
				SLEEP(0);

		/* Ding!!  Something arrived, go check all the incoming hoppers, net first */
			if(o_listen)
			{		
				/* net: ding! */
				if(left)
				{
					rr = (int)left;
				}
				else
				{
					_ASSERTE(in_fd->type == socket_handle ||
						in_fd->type == zlib_handle);

					if(in_fd->type == socket_handle)
						rr = recv(in_fd->u.s, bigbuf, (int) o_block, 0UL);
					else if(in_fd->type == zlib_handle)
						rr = gzread(in_fd->u.gz, bigbuf, o_block);
					else 
						rr = -1;
				}

				// A socket provider may handle a SD_SEND event either by
				// returning SOCKET_ERROR or by returning 0.  We need to be
				// to handle both.
				if (rr < 0) 
				{
					// This netretry stuff was in Hobbit's original code.
					// It really doesn't make any sense unless the error is 
					// recoverable.  I have added the h_errno == ETIMEDOUT 
					// condition.  Perhaps there are other recoverable errors
					// that should be added.
					if(h_errno == ETIMEDOUT && 
						--netretry)
						continue;
					
						if(h_errno != NO_ERROR);
							holler(_T("Failed reading from socket, sock error = %ld"), rr);
						break;
				} 
				else if(rr == 0)
				{
					// SD_SEND has been received and graceful close
					// is in progress.
					break;
					}
					else
					{
					
					left = rr;
					netretry = 2;
#ifdef TELNET
					if (o_tn)
					{
						_ASSERTE(in_fd->type == socket_handle);
						atelnet (in_fd->u.s, bigbuf, rr);		/* fake out telnet stuff */
					}
#endif /* TELNET */
					} /* if rr */
					Debug2 ("got %d from the net, errno %d\n", rr, errno);
				} /* net:ding */
				else 
				{
					/* if we're in "slowly" mode there's probably still stuff in the stdin
					buffer, so don't read unless we really need MORE INPUT!  MORE INPUT! */

					if(left)
					{
						rr = (int)left;
					}
					else
					{
						/* okay, suck more stdin */
						_ASSERTE(bigbuf != NULL);
						if(in_fd != NULL &&
							in_fd->type == runtime_handle)
							rr = read (in_fd->u.file, bigbuf, (int) o_block);
						else if(in_fd->type == zlib_handle)
							rr = gzread (in_fd->u.gz, bigbuf, (int) o_block);
#ifdef _WIN32
						else if(in_fd->type == native_handle)
							rr = os_read(in_fd->u.h, bigbuf, o_block, &in_fd->ov);
#endif //_WIN32
						else
						{
							rr = -1;
							_ASSERT(FALSE);
						}
							
					}
					/* Considered making reads here smaller for UDP mode, but 8192-byte
					mobygrams are kinda fun and exercise the reassembler. */

					if (rr < 0) 
					{			/* at end, or fukt, or ... */
						close_io_file(in_fd);/* disable and close stdin */
						if(in_sparse)
							rr = complete_sparse(0);
						break;
					} 
					else if(rr == 0)
					{
						break;
					}
					else
					{
						left = rr;
						_ASSERTE(bigbuf != NULL);
			/* special case for multi-mode -- we'll want to send this one buffer to every
			open TCP port or every UDP attempt, so save its size and clean up stdin */
						if (Single) 
						{
							if(hash_ctx != (HCRYPTHASH)0)
							{
								if(left == o_block)
									hash_process_block(bigbuf, left, hash_ctx);					
								else
									hash_process_bytes(bigbuf, left, hash_ctx);						
							}
						}
						else
						{		
							// If this is a seeking device (e.g. a disk file) rewind.
							// otherwise close the file to prevent further reads.
							if(!bSeek)
							{
								/* we might be scanning... */
								insaved = rr;		/* save len */
								close_io_file(in_fd);			/* really, I mean it */
							}

						} /* Single */

					} /* if rr/read */
				} /* stdin:ding */

				rr = shovel(out_fd, bigbuf, left);
				if(rr < 0)
					break;
				left = 0;
				netretry = 2;
			} /* while ding1:netfd is open */
		}

		/* XXX: maybe want a more graceful shutdown() here, or screw around with
		linger times??  I suspect that I don't need to since I'm always doing
		blocking reads and writes and my own manual "last ditch" efforts to read
		the net again after a timeout.  I haven't seen any screwups yet, but it's
		not like my test network is particularly busy... */
		//  CLOSESOCKET(fd);
	  
		SETSOCKERRNO(0);
		holler(_T("%I64d bytes %s"), (o_listen)? wrote_out : wrote_net, (o_listen)? L"written" : L"sent");

		if(o_listen)
		{
			if(o_compress == NETCAT_COMPRESSION_ALGORITHM_NONE)
				left =  MAX_HASHBUFFER_SIZE;
			else
				// zlib compression is not compatible with hashing
				// when listening because there is no way to extract
				// the hash from the compressed stream.
				left = 0;  
		}
		else
		{
			left = hash_signature_size(o_checksum);
		}

		disconnect_socket(o_listen? in_fd : out_fd, 
								  o_listen ? hash_buffer : hash_finish_ctx (hash_ctx, hash_buffer, left), 
								  &left);

		if(o_listen)
		{
			__int64 size;
#ifdef _WIN32
			LARGE_INTEGER _S;
#endif //_WIN32
			if(o_checksum != CALG_NOALG && left != 0)
				write_checksum(hash_buffer, left, output_file);
			
			// The file pointer should now be at the eof mark.
			if(out_fd->type == runtime_handle)
			{
				size = lseek(out_fd->u.file, 0, SEEK_CUR);
			}
			else if(out_fd->type == zlib_handle)
			{
				gzclose(out_fd->u.gz);
				out_fd->u.gz = gzopen(output_file, _T("rb"));
			}
				
			if(o_verify && hash_buffer != NULL && left > 0)
			{
				SETSOCKERRNO(0);
				holler(_T("Verifying output file..."));

				SETSOCKERRNO(0);
				holler(_T("The checksums %s match!"), 
					verify_output_file(out_fd, hash_buffer, left)? _T("do") : _T("do NOT"));
			}
			close_io_file(out_fd);
			
			if(output_file != NULL)
			{
				struct stat _St;

				if(lstat(output_file, &_St) == 0 &&
					(_St.st_mode & S_IFREG) == S_IFREG)
				{
#ifdef _WIN32
					_S.LowPart = GetCompressedFileSize(output_file, &_S.HighPart);
					if(o_supports_compression && 
						 _S.LowPart != INVALID_FILE_SIZE && 
						 size != 0I64)
						_ftprintf(stderr, _T("Output %s %I64d/%I64d bytes (compressed/uncompressed)\n"), output_file, _S.QuadPart, size);
					else
#endif //_WIN32
						_ftprintf(stderr, _T("Output %s (%I64d bytes)\n"), output_file, size);
				}
			}

		}
		_ASSERTE(left == hash_signature_size(o_checksum));
		display_system_time();
	}
	FINALLY
	{
		free_hast_ctx(hash_ctx);	
	}
	
	
	return (0);
} /* readwrite */


#ifdef _WIN32
void initialize_debug_memory()
{
	// Get the current state of the flag
	// and store it in a temporary variable
	int tmpFlag = _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );

	// Turn on client block identifiers and automatic leak detection
	tmpFlag |= (_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	// Set the new state for the flag
	_CrtSetDbgFlag( tmpFlag );
}
#endif //_WIN32

void scanargs(int iargs, TCHAR **pparg)
{
	int x;
	ADDRINFO* poop = NULL;
	char hostname[NI_MAXHOST];
	
	TCHAR short_options[] = _T("ab:c:de:g:G:h?i:I:k:KlLno:O:p:rSs:tuvw:x:z");

	static struct option const long_options[] = {
		{_T("comp"), required_argument, 0, _T('c')},
		{_T("decomp"), required_argument, 0, _T('x')},
		{_T("detach"), no_argument, &o_detach, 1},
		//{_T("dump"), required_argument, 0, _T('o')},
		{_T("help"), no_argument, &o_help, 1},
		{_T("verbose"), no_argument, &o_verbose, 1},
		{_T("verify"), no_argument, &o_verify, 1},
		{_T("csum"), required_argument, 0, _T('k')},
		{_T("hop"), required_argument, 0, _T('g')},
		{_T("route"), required_argument, 0, _T('G')},
		{_T("interval"), required_argument, 0, _T('i')},
		{_T("if"), required_argument, 0, _T('I')},
		{_T("lock"), no_argument, &o_lock, 1},
		{_T("listen"), no_argument, &o_listen, _T('l')},
//		{_T("LISTEN"), no_argument, 0, _T('L')},
		{_T("numeric"), no_argument, &o_nflag, 1},
		{_T("of"), required_argument, 0, _T('O')},
		{_T("port"), required_argument, 0, _T('p')},
		{_T("udp"), no_argument, &o_udpmode, 1},
		{_T("random"), no_argument, &o_random, 1},
		{_T("source"), required_argument, 0, _T('s')},
		{_T("sparse"), no_argument, &o_sparse, 1},
		{_T("telnet"), no_argument, &o_tn, 1},
		{_T("timeout"), required_argument, 0, _T('w')},
		{_T("zero"), no_argument, &o_zero, 1},
		{0, 0, 0, 0}
	};

	/* If your shitbox doesn't have getopt, step into the nineties already. */
	/* optarg, optind = next-argv-component [i.e. flag arg]; optopt = last-TCHAR */
	while ((x = getopt_long (iargs, pparg, short_options, long_options, NULL)) != EOF) 
	{
		/* Debug (("in go: x now %c, optarg %x optind %d", x, optarg, optind)) */
		switch (x) 
		{
		case 0:
			break;
		case _T('a'):
			bail (_T("all-A-records NIY\n"));
			o_alla++; 
			break;
		case _T('b'):
			if(!is_numeric(optarg))
				bail(_T("invalid block size\n"));
			o_block = _ttoi(optarg);
			break;
		case _T('c'):
			o_compress = parse_compression_algorithm(optarg);
			break;
		case 'd':				/* detach from console */
			o_detach++;
			break;
#ifdef GAPING_SECURITY_HOLE
		case 'e':				/* prog to exec */
			pr00gie = optarg;
			break;
#endif
		case 'G':				/* srcrt gateways pointer val */
			x = _ttoi (optarg);
			if ((x) && (x == (x & 0x1c)))	/* mask off bits of fukt values */
				gatesptr = x;
			else
				bail (_T("invalid hop pointer %d, must be multiple of 4 <= 28"), x);
			break;
		case _T('g'):				/* srcroute hop[s] */
			if (gatesidx > MAX_HOPS)
				bail (_T("too many -g hops\n"));
			
#ifdef _UNICODE
			wcstombs(hostname, optarg, NI_MAXHOST);
#else
			strncpy(hostname, optarg, NI_MAXHOST);
#endif //_UNICODE
			*next_gate = gethostpoop (hostname, NULL, o_nflag);
			if(*next_gate != NULL)
				next_gate = &(*next_gate)->ai_next;

			gatesidx++;
			break;
		case _T('?'):
		case _T('h'):
			o_help++;
			break;
		case _T('i'):				/* line-interval time */
			o_interval = _ttoi (optarg);
			if (! o_interval)
				bail (_T("invalid interval time %s"), optarg);
			break;
		case _T('I'):
			input_file = full_path(optarg);
			break;
		case _T('k'):
			if((o_checksum = string_to_algid(optarg)) == CALG_NOALG)
				bail(_T("unsupported hash algorithm"));
			break;
		case _T('K'):
			o_lock++;
			break;
		case _T('l'):				/* listen mode */
			o_listen++; 
			break;
//		case _T('L'):				/* listen then cycle back to start instead of exiting */
//			o_listen++; 
  //			cycle = 1;
//			break;
		case _T('n'):				/* numeric-only, no DNS lookups */
			o_nflag++; 
			break;
#if 0
		case _T('o'):				/* hexdump log */
			stage = (unsigned char *) full_path(optarg);
			o_wfile++; 
			break;
#endif //#if 0
		case _T('O'):
			output_file = full_path(optarg);
			break;
		case _T('p'):				/* local source port */
#ifdef _UNICODE
			wcstombs(local_service, optarg, NI_MAXSERV);
#else
			strncpy(local_service, optarg, NI_MAXSERV);
#endif //_UNICODE
			o_lport = getportpoop (local_service, 0);
			break;
		case 'r':				/* randomize various things */
			o_random++; 
			break;
		case 's':				/* local source address */
#ifdef _UNICODE
			wcstombs(local_host, optarg, NI_MAXHOST);
#else
			strncpy(local_host, optarg, NI_MAXHOST);
#endif //_UNICODE
			break;
		case 'S':
			o_sparse = TRUE;
			break;
#ifdef TELNET
		case _T('t'):				/* do telnet fakeout */
			o_tn++; 
			break;
#endif /* TELNET */

		case _T('u'):				/* use UDP */
			o_udpmode++; 
			break;
		case _T('v'):				/* verbose */
			o_verbose++; 
			break;
		case _T('w'):				/* wait time */
			o_wait = _ttoi (optarg);
			break;
		case _T('x'):
			o_decompress = parse_compression_algorithm(optarg);
			break;
		case _T('z'):				/* little or no data xfer */
			o_zero++;
			break;
		default:
			errno = 0;
			bail (_T("nc -h for help\n"));
		} /* switch x */
	} /* while getopt */

	if (optind < iargs)
	{
#ifdef _UNICODE
		wcstombs(remote_host, pparg[optind++], NI_MAXHOST);
#else
		strncpy(remote_host, pparg[optind++], NI_MAXHOST);
#endif //_UNICODE
	}
}

void validate_input()
{
	if(o_block <= 0)
		bail(_T("invalid block size\n"));
	if(o_decompress == NETCAT_COMPRESSION_ALGORITHM_UNSUPPORTED)
		bail(_T("Unsupported decompression algorithm\n"));
	if(o_compress == NETCAT_COMPRESSION_ALGORITHM_UNSUPPORTED)
		bail(_T("Unsupported compression algorithm\n"));
	if(o_verify)
	{
		struct stat _St;

		if(!o_listen)
			bail(_T("verification only supported when listening.\n"));
		else if(o_checksum == CALG_NOALG)
			bail(_T("verification requires a hash algorithm."));
		else if(output_file == NULL ||
			(lstat(output_file, &_St) == 0 &&
			(_St.st_mode & S_IFREG) != S_IFREG))
			bail(_T("Verification is supported only for disk files and the output file is not a disk file."));

	}
	if(o_compress != NETCAT_COMPRESSION_ALGORITHM_NONE)
	{
		if(o_listen && o_checksum != CALG_NOALG)
			bail(_T("compression is not compatible with checksums when listening.")); 
		else if(o_sparse)
			bail(_T("compression is not compatible with sparse files."));
		else if(o_zero)
			bail(_T("compression is not supported in conjunction with the -z --zero option."));
	}
	if(o_compress != NETCAT_COMPRESSION_ALGORITHM_NONE)
	{
		if(o_zero)
			bail(_T("decompression is not supported in conjunction with the -z --zero option."));
	}

	if(o_random)
	{
		SetLastError(ERROR_SUCCESS);

		if(!o_zero)
			bail(_T("The random option (-r --random) is only supported in conjunction with the zero data option (-z --zero option)."));
		
		if(local_host[0] == '\0')
			bail(_T("The random option (-r --random) requires that a local source address (-s --source) be specified."));
	}

	if(o_zero)
	{
		if(input_file != NULL)
			bail(_T("Input file not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_sparse)
			bail(_T("Sparse option (-S --sparse) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_listen)
			bail(_T("Listen (-l --listen) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_compress != NETCAT_COMPRESSION_ALGORITHM_NONE)
			bail(_T("File compression(-c --comp) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_decompress != NETCAT_COMPRESSION_ALGORITHM_NONE)
			bail(_T("File decompression(-x --decomp) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_verify)
			bail(_T("Checksum verification(--verify) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_lock)
			bail(_T("Input file locking(-K --lock) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_detach)
			bail(_T("Detached console (-d --detach) not supported in conjunction with the zero data option (-z --zero)!"));
		else if(o_tn)
			bail(_T("Telnet negotiation (-t --telnet) not supported in conjunction with the zero data option (-z --zero)!"));
	}
}

void get_arguments_from_stdin()
{
	int x;
	TCHAR* cp = NULL;
	char* acp = NULL;

	TCHAR **arrgv = (TCHAR **) xmalloc (MAX_ARGUMENTS * sizeof (TCHAR *));	/* XXX: MAX_ARGUMENTS? */
	memset(arrgv, 0, MAX_ARGUMENTS * sizeof(TCHAR*));

	arrgv[0] = program_name;			/* leave old prog name intact */
	cp = (TCHAR*)xmalloc(BIGSIZ * sizeof(TCHAR));			/* head of new arg block */
	arrgv[1] = cp;
#ifdef _UNICODE
	acp = xmalloc(BIGSIZ * sizeof(char));
#else
	acp = cp;
#endif //_UNICODE


	TRY
	{
		_ftprintf (stderr, _T("Cmd line: \n"));
		fflush (stderr);		/* I dont care if it's unbuffered or not! */
		insaved = read (fileno(stdin), acp, BIGSIZ * sizeof(char));	/* we're gonna fake fgets() here */

#ifdef _UNICODE
		mbstowcs(cp, acp, BIGSIZ);
#endif //_UNICODE
		if (insaved <= 0)
			bail (_T("wrong\n"));
		x = findline (cp, insaved);
		if (x)
			insaved -= x;		/* remaining chunk size to be sent */
		if (insaved)		/* which might be zero... */
		{
			_ASSERTE(bigbuf != NULL);
			memcpy (bigbuf, &acp[x], insaved);
		}
		cp = _tcschr (cp, _T('\n'));

		if (cp)
		{
			*cp = _T('\0');
			if(*--cp == _T('\r'))
				*cp = _T('\0');
		}

	/* find and stash pointers to remaining new "args" */
		cp = arrgv[1];
		cp++;				/* skip past first TCHAR */
		for (x = 2; *cp != _T('\0'); cp++) 
		{
			if (*cp == _T(' ')) 
			{
				*cp = _T('\0');			/* smash all spaces */
				continue;
			} 
			else 
			{
				if (*(cp-1) == _T('\0')) 
				{
					arrgv[x] = cp;
					x++;
				}
			} /* if space */
		} /* for cp */
		scanargs(x, arrgv);
	}
	FINALLY
	{
		if(arrgv != NULL)
		{
			if(arrgv[1] != NULL)
				free(arrgv[1]);
			free(arrgv);
		}
		if(acp != NULL)
			free(acp);
	}

} /* if no args given */

void initialize_signals()
{
	/* catch a signal or two for cleanup */
#ifdef NTFIXTHIS
	signal (SIGINT, catch);
	signal (SIGQUIT, catch);
	signal (SIGTERM, catch);
	signal (SIGURG, SIG_IGN);
#endif
}

void allocate_readwrite_buffer()
{
	if(bigbuf == NULL)
		bigbuf = xmalloc (o_block + NETBUFFIXUP);
}

void allocate_and_initialize_random()
{
	SRAND ((unsigned int)time (0));
	randports = xmalloc (65536);	/* big flag array for ports */
	memset(randports, 0, 65536);
}

#if 0
void allocate_and_initialize_hexdump_file()
{

	if (o_wfile) 
	{
		ofd = open (stage, O_WRONLY | O_CREAT | O_TRUNC | _O_SEQUENTIAL, 0664);
		if (ofd <= 0)			/* must be > extant 0/1/2 */
			bail (_T("can't open %s"), stage);
		
		// stage sometimes points to a dynamically allocated string
		// and sometimes to a static string.  Save a pointer to
		// dynamic memory in a separate variable so that we will know
		// to free it.

		if(sstage != NULL)
			free(sstage);
		sstage = (unsigned char *) xmalloc (100);
		stage = sstage;
	}
}
#endif // #if 0

void allocate_and_initialize_input_file()
{
	if(input_file == NULL)
	{
		size_t len = _tcslen(_T("CONIN$"));

		input_file = (TCHAR*) xmalloc((len + 1) * sizeof(TCHAR));
		_tcsncpy(input_file, _T("CONIN$"), len + 1);
	}

	if(p_input_fd == NULL)
	{
		p_input_fd = (PIO_FILE)xmalloc(sizeof(IO_FILE));
		memset(p_input_fd, 0, sizeof(IO_FILE));
	}
	else
		close_io_file(p_input_fd);

	p_input_fd->type = runtime_handle;
	p_input_fd->u.file = fileno(stdin);

	if(_tcsnicmp(input_file, _T("CONIN$"), 7) != 0)
	{
		int oflags = O_BINARY | O_SEQUENTIAL;

#ifdef _WIN32

		if(is_windows_xp() || 
			_tcsnicmp(input_file, _T("\\\\.\\PhysicalDrive"), 17) != 0)
			oflags |= O_RDONLY;
		else
			oflags |= O_RDWR;  //Windows 2000 needs write access to physical drives for IOCTL_SCSI_PASS_THROUGH_DIRECT
			                    //Note that requesting write access does not require that the application send a 
			                    //command that alters the drive.

		if(o_input_physical_memory = is_physical_memory_device(input_file)) 
		{
			o_block = adjust_block_size(o_block, input_file);

			p_input_fd->type = native_handle;
			p_input_fd->u.h = open_physical_memory();
			if(p_input_fd->u.h == (uintptr_t)-1)
				bail(_T("can't open physical memory\n"));
			display_physical_memory();
			return;
		}
#else
		oflags |= O_RDONLY;
#endif //_WIN32

		p_input_fd->u.file = _topen(input_file, oflags);

		if (p_input_fd->u.file < 0)			/* must be > extant 0/1/2 */
			bail (_T("can't open %s"), input_file);

		o_block = adjust_block_size(o_block, input_file);
		if(o_sparse)
			o_sparse = FALSE;
		if(is_disk_device(p_input_fd->u.file, INPUT_FILE))
			display_device_info(p_input_fd->u.file, input_file, INPUT_FILE);
		if(o_lock)
		{
			if(!lock_file(p_input_fd->u.file, (__int64) -1, INPUT_FILE))
			{
				if(o_physical_drive[INPUT_FILE])
				{
					bail(_T("Physical drive %s cannot be locked"), input_file);
				}
				if(o_disk_device[INPUT_FILE] && 
					cmdline_prompt_yes_or_no(_T("The volume or drive %s could not be locked. ")
						                        _T("Do you want to dismount it? [Y]es or [N]o?"), input_file) &&
												cmdline_prompt_yes_or_no(_T("WARNING: ALL OPEN FILE HANDLES WILL BECOME INVALID!\n")
												_T("Are you sure you want to dismount %s? [Y]es or [N]o?"), input_file))
				{
					if(!dismount_device(p_input_fd->u.file, INPUT_FILE)/* || 
						!lock_file(p_input_fd->u.file, (__int64) -1, INPUT_FILE)*/)
					{
						if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), input_file))
						{
							o_lock = 0;
						}
						else
						{
							bail(_T("Unable to copy device"));
						}
					}

					// In theory (and according to MS documetation) 
					// dismounting a volume also locks the volume 
					// because it "disappears" from the system.  On 
					// Windows XP it works this way. But lets test the
					// assumption elsewhere.
					_ASSERTE(!lock_file(p_input_fd->u.file, (__int64) -1, INPUT_FILE));
				}
				else if(!o_disk_device[INPUT_FILE]) 
				{
					if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), input_file))
					{
						o_lock = 0;
					}
					else						{
						bail(_T("Unable to copy file"));
					}
				}
				
			}
		}
		
	}
	else if (o_lport == 0)
	{
		// reading data from standard input
		// on win32 set stdin to binary mode to suppress character translation
		SET_BINARY_MODE(p_input_fd->u.file);
		if(o_sparse)
			o_sparse = FALSE;
	}

	if(!open_compressed_stream(p_input_fd, O_BINARY | O_RDONLY, o_decompress, NULL, 0))
		bail(_T("unable to open compressed stream"));
}

void allocate_and_initialize_output_file()
{
	if(output_file == NULL)
	{
		size_t len = _tcslen(_T("CONOUT$"));

		output_file = (TCHAR*) xmalloc((len + 1) * sizeof(TCHAR));
		_tcsncpy(output_file, _T("CONOUT$"), len + 1);
	}
	
	if(p_output_fd == NULL)
	{
		p_output_fd = (PIO_FILE)xmalloc(sizeof(IO_FILE));
		memset(p_output_fd, 0, sizeof(IO_FILE));
	}
	else
		close_io_file(p_output_fd);

	p_output_fd->type = runtime_handle;	
	p_output_fd->u.file = fileno(stdout);

	if(_tcsnicmp(output_file, _T("CONOUT$"), 8) != 0)
	{
		if(o_lport == 0)
			bail(_T("output file %s requires -p option"), output_file);

		p_output_fd->u.file = _topen(output_file, O_BINARY |  O_RDWR  | O_CREAT | O_TRUNC | O_SEQUENTIAL, S_IREAD);

		if (p_output_fd->u.file < 0)			/* must be > extant 0/1/2 */
		{
			bail (_T("can't open %s"), output_file);
		}
		
		if(o_lock &&
			is_disk_device(p_output_fd->u.file, OUTPUT_FILE))
		{
			if(!lock_file(p_output_fd->u.file, (__int64) -1, OUTPUT_FILE))
			{
				if(o_physical_drive[OUTPUT_FILE])
					bail(_T("Physical drive %s cannot be locked"), output_file);
				if(o_disk_device[OUTPUT_FILE] && 
					cmdline_prompt_yes_or_no(_T("The volume or drive %s could not be locked. ")
						                        _T("Do you want to dismount it? [Y]es or [N]o?"), output_file) &&
												cmdline_prompt_yes_or_no(_T("WARNING: ALL OPEN FILE HANDLES WILL BECOME INVALID!\n")
												_T("Are you sure you want to dismount %s? [Y]es or [N]o?"), output_file))
				{
					if(!dismount_device(p_output_fd->u.file, OUTPUT_FILE) /*|| 
						!lock_file(p_output_fd->u.file, (__int64) -1, OUTPUT_FILE)*/)
					{
						if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), output_file))
						{
							o_lock = 0;
						}
						else
						{
							bail(_T("Unable to copy to device"));
						}
					}
					// In theory (and according to MS documetation) 
					// dismounting a volume also locks the volume 
					// because it "disappears" from the system.  On 
					// Windows XP it works this way. But lets test the
					// assumption elsewhere.
					_ASSERTE(!lock_file(p_output_fd->u.file, (__int64) -1, OUTPUT_FILE));

				}
				else if(!o_disk_device[OUTPUT_FILE]) 
				{
					if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), output_file))
					{
						o_lock = 0;
					}
					else						{
						bail(_T("Unable to copy output file"));
					}
				}
				
			}
		}

		o_block = adjust_block_size(o_block, output_file);

		o_supports_compression = file_system_supports(output_file, FS_FILE_COMPRESSION);

		if(o_sparse)
		{
			o_sparse = file_system_supports(output_file, FILE_SUPPORTS_SPARSE_FILES | FS_FILE_COMPRESSION);
			_ASSERTE(o_sparse);
		}
		
		if(o_sparse)
		{
			o_sparse = set_sparse(p_output_fd->u.file);
			_ASSERTE(o_sparse);
		}
		if(o_sparse)
		{
			_ASSERTE(is_sparse(p_output_fd->u.file));
			init_sparse();		
		}
	}
	else if(o_lport != 0)
	{
		//writing output directly to stdout.
		// on win32 set stdout to binary mode to suppress character translation
		SET_BINARY_MODE(p_output_fd->u.file);
		if(o_sparse)
			o_sparse = FALSE;
	}

	if(!open_compressed_stream(p_output_fd, O_BINARY |  O_RDWR, o_compress, NULL, 0))
		bail(_T("unable to open compressed stream"));
}

void allocate_and_initialize_files()
{
	if(o_zero)
		return;
#ifdef GAPING_SECURITY_HOLE
	else if (pr00gie) 
	{
		close (fileno(stdin));				/* won't need stdin */
		o_wfile = 0;			/* -o with -e is meaningless! */
		ofd = 0;
	}
#endif /* G_S_H */

	//allocate_and_initialize_hexdump_file();
	else if(o_listen)
		allocate_and_initialize_output_file();
	else
		allocate_and_initialize_input_file();
}

TCHAR* full_path(const TCHAR* lpszPath)
{
	size_t count = _MAX_PATH;
	TCHAR* path = (TCHAR*)0;
#ifdef 	_WIN32
	size_t count2;
#endif // _WIN32

	if(lpszPath == NULL ||
		lpszPath[0] == _T('\0'))
		return (TCHAR*)0;

#ifdef 	_WIN32
	count = GetFullPathName(lpszPath, 0UL, 0, 0);

	// On Windows 2000 GetFullPathName() returns less than the
	// required buffer size if NULL is specified for the output buffer
	// and lpszPath points to a device or volume (e.g. "\\.\C:").  The 
	// required buffer size will always be at least as big as the length
	// of the lpszPath argument. Windows XP always returns the correct 
	// buffer size and the following line is not required if only Windows
	// XP is targeted.
	count = max(count, _tcslen(lpszPath));

	if(count == 0)
	{
		holler(_T("GetFullPathName failed for path %s: Error = %ld"), lpszPath, GetLastError());
		return (TCHAR*)0;
	}	
	
	path = (TCHAR*) xmalloc(++count * sizeof(TCHAR));
	
	count2 = GetFullPathName(lpszPath, (unsigned long)count, path, 0);
	_ASSERTE(count2 < count);
	_ASSERTE(_CrtCheckMemory());

	if(count2 == 0UL)
	{
		free(path);
		holler(_T("GetFullPathName failed for path %s: Error = %ld"), lpszPath, GetLastError());
		return (TCHAR*)0;
	}
#else
	path = xmalloc(count * sizeof(TCHAR));

	if(_tfullpath(path, lpszPath, MAX_PATH) == NULL)
	{
		free(path);
		return (TCHAR*)0;
	}
#endif //_WIN32
	return path;
}

#ifdef _WIN32
TCHAR* get_module_path()
{
	unsigned int i = 0;
	unsigned long dwSize;

	TCHAR * lpszFullPath = (TCHAR*) 0;

	// Unfortunately there is no way to size the module file name
	// other than trial and error.  Increase the path buffer in
	// _MAX_PATH increments.

	do
	{
		
		dwSize = (_MAX_PATH * sizeof(TCHAR) * ++i);

		if(lpszFullPath != NULL)
			free(lpszFullPath);

		lpszFullPath = (TCHAR*) xmalloc((dwSize + 2) * sizeof(TCHAR));
		//lpszFullPath[0] = _T('"');
		 
	} while(GetModuleFileName(NULL, lpszFullPath, dwSize) == 0UL);

//	dwSize = (unsigned long)_tcslen(lpszFullPath);
//	lpszFullPath[dwSize++] = _T('"');
//	lpszFullPath[dwSize] = _T('\0');

	return lpszFullPath;
}
#endif //_WIN32

TCHAR* full_exe_path(const TCHAR* lpszPath)
{
#ifdef _WIN32
	TCHAR* lpszFullPath = get_module_path();
#else
	TCHAR* lpszFullPath = NULL;
	size_t size;
	do
	{
		
		size = (_MAX_PATH * sizeof(TCHAR) * ++i);

		if(lpszFullPath != NULL)
			free(lpszFullPath);

		lpszFullPath = (TCHAR*) xmalloc(size * sizeof(TCHAR));
		
		 
	} while(makepath(lpszFullPath, lpszPath, size) == 0UL);
#endif //_WIN32
	return lpszFullPath;
}


/* main :
   now we pull it all together... */
int _tmain (int argc, TCHAR **argv)
{
	register int x;
	register char *cp;
	USHORT ourport = 0;
	USHORT loport = 0;		/* for scanning stuff */
	USHORT hiport = 0;
	USHORT curport = 0;
	program_name = full_exe_path(argv[0]);
	
	local_host[0] = '\0';
	local_service[0] = '\0';
	remote_host[0] = '\0';
	remote_service[0] = '\0';
	
#ifdef _WIN32
	initialize_debug_memory();
	SetConsoleCtrlHandler(control_handler, 1 );
	SetConsoleCtrlHandler(NULL, FALSE );  // added 8/15/2004
	SetErrorMode(SEM_FAILCRITICALERRORS);
//	_CrtSetBreakAlloc(56);
#endif // _WIN32
	atexit(cleanup);
#ifdef HAVE_BIND
/* can *you* say "cc -yaddayadda netcat.c -lresolv -l44bsd" on SunLOSs? */
  res_init();
#endif
	
	//_ASSERT(FALSE);

	initialize_signals();

  /* if no args given at all, get 'em from stdin and construct an argv. */
	if (argc == 1) 
		get_arguments_from_stdin();
	else
		scanargs(argc, argv);

  	if(o_detach)
		FreeConsole();

	if(o_verbose)
		banner();

	if(o_help)
	{
#ifdef HAVE_HELP
		errno = 0;
		helpme();			/* exits by itself */
#else
		bail ("no help available, dork -- RTFS");
#endif
	}

	TRY
	{

	validate_input();

	if(!o_zero)
		allocate_readwrite_buffer();

	/* other misc initialization */
	if (o_random) 
		allocate_and_initialize_random();

	allocate_and_initialize_files();

/* Debug (("optind up to %d at host-arg %s", optind, argv[optind])) */
/* gonna only use first addr of host-list, like our IQ was normal; if you wanna
get fancy with addresses, look up the list yourself and plug 'em in for now.
unless we finally implement -a, that is. */

	do
	{
		
		/* Handle listen mode here, and exit afterward.  Only does one connect;
		this is arguably the right thing to do.  A "persistent listen-and-fork"
		mode a la inetd has been thought about, but not implemented.  A tiny
		wrapper script can handle such things... */

		if (o_listen) 
		{
			char service[NI_MAXSERV];

			if (o_lport == 0)
				bail (_T("invalid local port %s"), local_service);

			
#ifdef _UNICODE
			wcstombs(service, (optind < argc)? argv[optind] :  L"", NI_MAXSERV);
#else
			strncpy(service, (optind < argc)? argv[optind] : "", NI_MAXSERV);
#endif //_UNICODE

			/* dolisten does its own connect reporting, so we don't holler anything here */
			if (dolisten (&p_input_fd, 
				              remote_host, 
							  (optind < argc)? getportpoop(service, 0) : 0, 
							  local_host, 
							  o_lport)) 
			{
#ifdef GAPING_SECURITY_HOLE
				if (pr00gie)			/* -e given? */
					doexec (p_input_fd->u.s);
#ifdef _WIN32
				if (!pr00gie)  // doexec does the read/write for win32
#endif //_WIN32

#endif /* GAPING_SECURITY_HOLE */
					x = readwrite (p_input_fd, p_output_fd);		/* it even works with UDP! */

					if (o_verbose > 1)		/* normally we don't care */
					{
						SETSOCKERRNO(0);
						holler (wrote_txt, wrote_net, wrote_out);
					}
			} 
			else
			{
				bail (_T("no connection\n"));
			}
	
		} /* o_listen */
		else
		{
			if(optind < argc)
#ifdef _UNICODE
				wcstombs(remote_service, argv[optind++], NI_MAXHOST);
#else
				strncpy(remote_service, argv[optind++], NI_MAXHOST);
#endif //_UNICODE

			if(local_host[0] != '\0' && 
				(ouraddr = gethostpoop(local_host, NULL, o_nflag)) == NULL)
			{
#ifdef _UNICODE
				__wchar_t wlocal_host[NI_MAXHOST];
				bail(L"local host %s not found", wlocal_host);
#else
				bail("local host %s not found", local_host);
#endif //_UNICODE
			}
			if(themaddr != NULL)
			{
				free_host_poop(themaddr);
				themaddr = NULL;
			}
			else if(remote_host[0] == '\0' || 
				(themaddr = gethostpoop(remote_host, NULL, o_nflag)) == NULL)
			/* fall thru to outbound connects.  Now we're more picky about args... */
				bail (_T("no destination\n"));
			else if (!o_zero && optind > argc)
				bail (_T("no port[s] to connect to\n"));
			else if (optind < argc && argv[optind])		/* look ahead: any more port args given? */
					Single = 0;				/* multi-mode, case A */
			else if (o_random)
					Single = 0;

			ourport = o_lport;			/* which can be 0 */

				/* everything from here down is treated as as ports and/or ranges thereof, so
				it's all enclosed in this big ol' argv-parsin' loop.  Any randomization is
				done within each given *range*, but in separate chunks per each succeeding
				argument, so we can control the pattern somewhat. */
		do 
		{
			hiport = loport = 0;

			if(optind > argc &&
				!o_random)
				break;
		
			if (remote_service[0] != '\0') 
			{
				loport = getportpoop (remote_service, 0);
				if (loport == 0)
					bail (_T("invalid port %s"), remote_service);
				
				cp = strchr (remote_service, '-');	/* nn-mm range? */

				if(cp)
				{
#ifdef _UNICODE
					__wchar_t port[NI_MAXSERV];
#endif //_UNICODE
					*cp = '\0';
					cp++;
					hiport = getportpoop (cp, 0);
					if (hiport == 0)
					{
#ifdef _UNICODE
						mbstowcs(port, cp, NI_MAXSERV);
						bail (_T("invalid port %s"), port);
#else
						bail (_T("invalid port %s"), cp);
#endif //_UNICODE
					}
				}
			} /* if found a dash */
			else
			{
				loport = 1;
				hiport = 65535;
			}

			
			if (hiport > loport) 
			{		/* was it genuinely a range? */
				Single = 0;			/* multi-mode, case B */
				curport = hiport;			/* start high by default */

				if (o_random) 
				{			/* maybe populate the random array */
					loadports (randports, loport, hiport);

					TRY
					{
						curport = nextport (randports);
					}
					CATCH_ALL(curport);
				}
			} 
			else			/* not a range, including args like "25-25" */
			{
				curport = loport;
			}
		Debug2 ("Single %d, curport %d\n", Single, curport);

		if(curport < 1 || curport > 65535)
			break;
	/* Now start connecting to these things.  curport is already preloaded. */
		while (loport <= curport) 
		{
			if ((! o_lport) && (o_random)) 
			{	/* -p overrides random local-port */
				ourport = (RAND() & 0xffff);	/* random local-bind -- well above */
				if (ourport < 8192)		/* resv and any likely listeners??? */
					ourport += 8192;		/* xxx: may still conflict; use -s? */
			}
			curport = getportpoop (NULL, curport);
			
			if (connect_socket(&p_output_fd, themaddr, curport, ouraddr, ourport) &&
				test_socket(p_output_fd->u.s, themaddr->ai_addr)) 
			{			/* Yow, are we OPEN YET?! */
				TCHAR canonname[NI_MAXHOST];
				x = 0;				/* pre-exit status */
				SETSOCKERRNO(0);
				
#ifdef _UNICODE
				mbstowcs(canonname, (themaddr->ai_canonname)? themaddr->ai_canonname : "", NI_MAXHOST);
#else
				strncpy(canonname, (themaddr->ai_canonname)? themaddr->ai_canonname : "", NI_MAXHOST);
#endif //_UNICODE
				SETSOCKERRNO(0);
				holler (_T("%s [%d] %s open"), canonname, curport, (o_udpmode)? _T("udp") : _T("tcp"));

#ifdef GAPING_SECURITY_HOLE
#pragma message("GAPING_SECURITY_HOLE defined")
				if (pr00gie)			/* exec is valid for outbound, too */
					doexec (p_output_fd->u.s);
#endif /* GAPING_SECURITY_HOLE */
				if (o_zero)
				{
					disconnect_socket(p_output_fd, NULL, 0);
				}
				else
				{
#ifdef _WIN32 
#ifdef GAPING_SECURITY_HOLE
					if (!pr00gie)  // doexec does the read/write for win32
#endif // GAPING_SECURITY_HOLE
#endif // _WIN32
					{
						TRY
						{
							x = readwrite (p_input_fd, p_output_fd);	/* go shovel shit */
						}
						CATCH_ALL(x)
					}
				}
			} 
			else 
			{ /* no netfd... */
				TCHAR canonname[NI_MAXHOST];

					x = 1;				/* preload exit status for later */
					/* if we're scanning at a "one -v" verbosity level, don't print refusals.
					Give it another -v if you want to see everything. */
				
#ifdef _WIN32
					if ((Single || (o_verbose > 1)) || (h_errno && h_errno != WSAECONNREFUSED))
#else
					if ((Single || (o_verbose > 1)) || (errno && errno != ECONNREFUSED))
#endif //_WIN32
					{
#ifdef _UNICODE
						mbstowcs(canonname, (themaddr->ai_canonname)? themaddr->ai_canonname : "", NI_MAXHOST);
#else	
						strncpy(canonname, (themaddr->ai_canonname)? themaddr->ai_canonname : "", NI_MAXHOST);
#endif //_UNICODE
						SETSOCKERRNO(0);
						holler (_T("%s [%d]:"),	canonname, curport);
					}
				} /* if netfd */

					if (o_interval)
						SLEEP (o_interval);		/* if -i, delay between ports too */
					if (o_random)
						curport = nextport (randports);
					else
						curport--;			/* just decrement... */
				} /* while curport within current range */

			} while (optind < argc && argv[optind]);

		}
		SETSOCKERRNO(0);
		if (o_verbose > 1)		/* normally we don't care */
		{
			SETSOCKERRNO(0);
			holler (_T("sent %I64d, rcvd %I64d"), wrote_net, wrote_out);
		}

	} while(cycle);

	}
	CATCH_ALL(x);

if (Single)
    exit (x);			/* give us status on one connection */
  exit (0);			/* otherwise, we're just done */
  return(0);
} /* main */

#ifdef HAVE_HELP		/* unless we wanna be *really* cryptic */
/* helpme :
   the obvious */
int helpme()
{
  o_verbose = 1;
  banner();
  SETSOCKERRNO(0);
  _tprintf (_T("connect to somewhere:	nc [-options] hostname port[s] [ports] ... \n\
listen for inbound:	nc -l -p port [options] [hostname] [port]\n\
options:\n"));
  _tprintf (_T("\
--comp     -c [algorithm] compress input or output using the\n\
\t\t\tspecified algorithm.  (Currently only \"md5\")\n\
--decomp   -x [algorithm] decompress input or output using the\n\
\t\t\tspecified algorithm.  (Currently only \"md5\")\n\
--detach   -d\t\tdetach from console, background mode\n\n"));

  SETSOCKERRNO(0);
#ifdef GAPING_SECURITY_HOLE	/* needs to be separate holler() */
  _tprintf (_T("\
	-e prog		inbound program to exec [dangerous!!]\n"));
#endif
  _tprintf (_T("\
--hop      -g [gateway]\tsource-routing hop point[s], up to 8\n\
--route    -G [num]\tsource-routing pointer: 4, 8, 12, ...\n\
--help     -h\t\tthis cruft\n\
--interval -i [millisecs]\tdelay interval for lines sent, ports scanned\n\
--if       -I [file]\tinput file (ignored if -l or -L also is specified\n\
--csum     -k [alg]\tcompute checksum using the specified algorithm\n\
--lock     -K\t\ttry to lock the input file while it is copied\n \
\t\t\t(currently only md5 supported) \n \
--listen  -l\t\tlisten mode, for inbound connects\n\
--LISTEN   -L\t\tlisten harder, re-listen on socket close\n\
--numeric  -n\t\tnumeric-only IP addresses, no DNS\n\
--of       -O [file]\toutput file (-l or -L must also be specified)\n\
--port     -p [port]\tlocal port number\n\
--random   -r\t\trandomize local and remote ports\n\
--source   -s [addr]\tlocal source address\n\
--sparse   -S\t\tuse sparse output file (ignored unless -O also\n\
\t\t\tspecified)\n"));

  SETSOCKERRNO(0);
#ifdef TELNET
  _tprintf (_T("\
--telnet   -t\t\tanswer TELNET negotiation\n"));
#endif
  _tprintf (_T("\
--udp      -u\t\tUDP mode\n\
--verbose  -v\t\tverbose [use twice to be more verbose]\n\
--timeout  -w [millisecs] timeout for connects and final net reads\n\
--zero     -z\t\tzero-I/O mode [used for scanning]\n"));
  bail (_T("port numbers can be individual or ranges: m-n [inclusive]\n"));
  return(0);
} /* helpme */
#endif /* HAVE_HELP */

/*--dump     -o [file]\thex dump of traffic\n\ */

#ifdef _WIN32
//
//  FUNCTION: control_handler ( unsigned long sig )
//
//  PURPOSE: Handled console control events
//
//  PARAMETERS:
//    dwCtrlType - type of control event
//
//  RETURN VALUE:
//    True - handled
//    False - unhandled
//
//  COMMENTS:
//
int __stdcall control_handler ( unsigned long sig )
{
	switch( sig)
    {
        case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
        case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
			printf("Stopping netcat...\n");
            handle_termination_request();
            break;
		default:
			;
    }
    return 0;
}

TCHAR* root_path(const TCHAR* _Path)
{
	size_t len;
	TCHAR* root;
	TCHAR* dir;
	TCHAR drive[_MAX_DRIVE];
	
	_ASSERTE(_Path != NULL);
	if(_Path == NULL || _Path[0] == '\0')
		return (TCHAR*)0;

	// The directory length will be less than or equal to the size
	// of the full path plus one for the trailing null character.
	// Also add one for a trailing backslash which may be added 
	// by splitpath.  Add _MAX_DRIVE so that we can do makepath in place.
	len = _tcslen(_Path) + 2 + _MAX_DRIVE;
	
	root = malloc(len * sizeof(TCHAR));
	dir = root + _MAX_DRIVE;
	
	// Separate the drive letter (if any) and directory
	_tsplitpath(_Path, drive, dir, NULL, NULL);
	_tmakepath(root, drive, dir, NULL, NULL);
	
	return root;
}

int volume_sector_size(const TCHAR* root)
{
	__int32 dwSectorSize;
	unsigned long dwSectorsPerCluster;
	unsigned long dwNumberOfFreeClusters;
	unsigned long dwTotalNumberOfClusters;

	if(!GetDiskFreeSpace(root,
				            &dwSectorsPerCluster,
							(unsigned long*)&dwSectorSize,
							&dwNumberOfFreeClusters,
							&dwTotalNumberOfClusters))				
	{
		return INVALID_SECTOR_SIZE;	
	}
	
	
	_RPT3(_CRT_WARN, "%s: BytesPerSector = %ld, SectorsPerCluster = %ld\n", root, dwSectorSize, dwSectorsPerCluster);		

	return dwSectorSize;
}

size_t allocation_granularity()
{
	SYSTEM_INFO si;
	GetSystemInfo(&si);
	return si.dwAllocationGranularity;
}

size_t adjust_block_size(size_t size, const TCHAR* _Path) 
{
	__int32 sector_size;

	// Get the root of the path
	TCHAR* root = NULL;
	
	if(o_input_physical_memory)
	{
		sector_size = (__int32)allocation_granularity();
		_ASSERTE(sector_size == 64 * 1024);

		if(sector_size == size)
			return size;
		else if(((size_t)sector_size) > size)
			size = sector_size/(sector_size/size);
		else 
			size = (size/sector_size) * sector_size;
		return size;
	}
	
	if((root = root_path(_Path)) == NULL)
		return size;
	
	__try
	{
		
		// Determine the sector size on the Volume or drive
		sector_size = (__int32)volume_sector_size(root);


		if(sector_size == INVALID_SECTOR_SIZE)
			__leave;

		_RPT1(_CRT_WARN, "Adjusting block size from %ld ", o_block);
		if(size == sector_size)
		{
			__leave;
		}
		else if(size < (size_t)sector_size)
		{
			// If the requested block size is smaller than the 
			// sector size, adjust the block size to at least the 
			// sector size.
			size = __max((__int32)size, sector_size);
		}
		else
		{
			// If the requested block size is larger than the 
			// sector size, round the block size down to align 
			// on sector size boundary.
			size = sector_size * (size/sector_size);
		}
		_RPT1(_CRT_WARN, " to %ld \n", size);
	}
	__finally
	{
		if(root != NULL)
			free(root);
	}
	return size;
}

LPWSAPROTOCOL_INFO get_supporting_protocol(LPWSAPROTOCOL_INFO pInfo, int* max_entries, int af, int type, int protocol, unsigned long flags)
{
	int i, j, iProtocols;
	unsigned long dwSize;
	LPWSAPROTOCOL_INFO buffer = NULL;
	LPWSAPROTOCOL_INFO pOut = NULL;

	if(max_entries == NULL)
	{
		SETSOCKERRNO(WSAEINVAL);
		_RPT1(_CRT_WARN, "Failed to enumerate socket protocols, sock error = %ld\n", h_errno);
		return NULL;
	}

	memset(pInfo, 0, sizeof(WSAPROTOCOL_INFO) * (*max_entries));

	if(WSAEnumProtocols(NULL, NULL, &dwSize) != SOCKET_ERROR ||
		h_errno != WSAENOBUFS || dwSize == 0UL)
	{
		_RPT1(_CRT_WARN, "Failed to enumerate socket protocols, sock error = %ld\n", h_errno);
		return NULL;
	}
	
	buffer = (LPWSAPROTOCOL_INFO) xmalloc(dwSize);

	TRY
	{

		if((iProtocols = WSAEnumProtocols(NULL, buffer, &dwSize)) == SOCKET_ERROR)
		{
			_RPT1(_CRT_WARN, "Failed to enumerate socket protocols, sock error = %ld\n", h_errno);
			__leave;
		}
		
		_RPT4(_CRT_WARN, "Searching for socket service providers supporting sockets of family %ld, type %ld, protocol %ld, flags 0x%08lx:\n", af, type, protocol, flags);
		
		for(i = 0, j=0; i < iProtocols; ++i)
		{
			LPWSAPROTOCOL_INFO next = buffer + i;
			LPWSAPROTOCOL_INFO next_out = pInfo + j;

			_RPT2(_CRT_WARN, "\t%s 0x%08lx\n", next->szProtocol, next->dwServiceFlags1);

			if((next->dwServiceFlags1 & flags) == flags &&
				next->iAddressFamily == af && 
				next->iProtocol == protocol &&
				next->iSocketType == type)
			{
				_RPT2(_CRT_WARN, "Found %s that supports 0x%08lx services:\n", next->szProtocol, next->dwServiceFlags1);						

				if(j++ < *max_entries)
					memcpy(next_out, next, sizeof(WSAPROTOCOL_INFO));

			}
		}
		if(j > 0)
			pOut = pInfo;

	}
	FINALLY
	{
		if(buffer != (LPWSAPROTOCOL_INFO)0)
			free(buffer);
	}
	
	return pOut;
}

BOOL is_physical_memory_device(const TCHAR* pinput_file)
{
   TCHAR drive[_MAX_DRIVE];
   TCHAR dir[_MAX_DIR];
   TCHAR fname[_MAX_FNAME];
   TCHAR ext[_MAX_EXT];

   if(pinput_file == 0)
	   return 0;

   _tsplitpath( pinput_file, drive, dir, fname, ext );

   if(drive[0] == _T('\0') &&
	   _tcsnicmp(dir, _T("\\\\.\\"), 4) == 0 &&
	   _tcsnicmp(fname, _T("PhysicalMemory"), 15) == 0 &&
	   ext[0] == _T('\0'))
	   return 1;
	return 0;
}

#endif //_WIN32

ALG_ID string_to_algid(const TCHAR* algorithm)
{
	if(algorithm == NULL || algorithm[0] == '\0' ||
		_tcsnicmp(algorithm, _T("MD5"), 4) != 0)
		return CALG_NOALG;
	return CALG_MD5;
}

FILE* open_checksum_output_file(const TCHAR* ofile)
{
	FILE* fd = NULL;
	size_t len = _tcslen(ofile) + 4;
	TCHAR* pMd5 = (TCHAR*) xmalloc((len + 1) * sizeof(TCHAR));

	TRY
	{
		_tcsncpy(pMd5, ofile, len);
		_tcsncat(pMd5, _T(".MD5"), 5);

		if((fd = _tfopen (pMd5, _T("wS"))) < 0)
		{
			holler(_T("Unable to open md5 output file %s"), pMd5);
			fd = stdout;
		}
		_tchmod(pMd5, _S_IREAD);
	}
	FINALLY
	{
		if(pMd5 != NULL)
			free(pMd5);
	}
	return fd;
}

void write_checksum(unsigned char* buffer, size_t len, const TCHAR* ofile)
{
	  FILE* md5_output_fd = (FILE*)0;
		
	  TRY
	  {
			if(ofile == NULL || 
				_tcsncmp(ofile, _T("standard output"), 16) == 0)
				md5_output_fd = stdout;
			else 
				md5_output_fd = open_checksum_output_file(ofile);
			md5_write_digest_entry(md5_output_fd, ofile, 1, buffer, MD5_SIGNATURE_SIZE);

		}
		FINALLY
		{

			if(md5_output_fd != (FILE*)0 && 
				md5_output_fd != stdout)
			{
				fclose(md5_output_fd);
				md5_output_fd = (FILE*)0;
			}
	  }
}


void free_hast_ctx(HCRYPTHASH ctx)
{
	md5_free_ctx(ctx);
}

HCRYPTHASH create_and_initialize_hash_context(ALG_ID algorithm)
{
	HCRYPTHASH ctx = (HCRYPTHASH)0;

	if(algorithm == CALG_MD5)
	{
		ctx = (HCRYPTHASH)md5_alloc_ctx();
		md5_init_ctx(ctx);
	}

	return ctx;
}

void hash_process_block(unsigned char* pBlock, size_t len, HCRYPTHASH ctx)
{
	md5_process_block(pBlock, len, ctx);
}

void hash_process_bytes(unsigned char* pData, size_t len, HCRYPTHASH ctx)
{
	md5_process_bytes(pData, len, ctx);
}

unsigned char* hash_finish_ctx (HCRYPTHASH ctx, unsigned char* buffer, size_t len)
{
	if(ctx != (HCRYPTHASH)0 && buffer != NULL && len != 0)
	{
		switch(o_checksum)
		{
		case CALG_MD5:
			return md5_finish_ctx (ctx, buffer, len);
		default:
			;
		}
	}
	return NULL;
}

size_t hash_signature_size(ALG_ID id)
{
	size_t size = 0;

	switch(id)
	{
	case CALG_MD5:
		size = MD5_SIGNATURE_SIZE;
		break;
	default:
		;
	}
	return size;
}

SOCKET create_socket(int af, int type, int protocol, unsigned long flags) 
{
	SOCKET s = INVALID_SOCKET;
#ifdef _WIN32
	WSAPROTOCOL_INFO _Info[MAX_PROTOCOLS];
	int size = MAX_PROTOCOLS;

	 if(flags != 0UL)
	 {
		LPWSAPROTOCOL_INFO next;

		 if((next = get_supporting_protocol((LPWSAPROTOCOL_INFO)&_Info, &size, af, type, protocol, flags)) != NULL)
		{
			int i;
			for(i = 0; i < size; ++i)
			{
				next = next + i;
				if((s = WSASocket(af, type, protocol, next, 0, WSA_FLAG_OVERLAPPED)) != INVALID_SOCKET)
				{
					o_capabilities = next-> dwServiceFlags1;
					break;
				}
				else
				{
					holler(_T("failed to get socket from provider %s"), next->szProtocol);
				}
			}
		}

	 }

	 // Fall back on traditional socket() if all else fails;
//	 if(s == INVALID_SOCKET)
//		 s = socket(af, type, protocol);
#else
	s = socket(af, type, protocol);
#endif //_WIN32
	return s;
}

static int parse_compression_algorithm(const TCHAR* algorithm)
{
	if(algorithm == NULL ||
		algorithm[0] == _T('\0'))
		return NETCAT_COMPRESSION_ALGORITHM_DEFAULT;
	else if(_tcsnicmp(algorithm, _T("zlib"), 5) == 0)
		return NETCAT_COMPRESSION_ALGORITHM_ZLIB;
	return NETCAT_COMPRESSION_ALGORITHM_UNSUPPORTED;
}

void close_io_file(PIO_FILE pio)
{
	if(pio == NULL)
		return;

	if(pio->type == runtime_handle)
	{
		if(pio->u.file != -1 &&
			pio->u.file != fileno(stdin) &&
			pio->u.file != fileno(stdout))
		{
			if(o_lock)
				unlock_file(pio->u.file, (__int64) -1, INPUT_FILE);

			CLOSE(pio->u.file);
		}
	}
	else if(pio->type == socket_handle)
	{
		if(pio->u.s != INVALID_SOCKET)
		{
			CLOSESOCKET(pio->u.s);
		}
	}
	else if(pio->type == zlib_handle)
	{
		if(pio->u.gz != (gzFile)0)
		{
			gzclose(pio->u.gz);
			pio->u.gz = (gzFile)0;
		}
	}
#ifdef _WIN32
	else if(pio->type == native_handle)
	{
		if( pio->u.h != (uintptr_t)-1)
		{
			pio->u.h = (uintptr_t) -1;
			CloseHandle((HANDLE) pio->u.h);
		}
			
		if(pio->ov.hEvent != NULL && 
			pio->ov.hEvent != INVALID_HANDLE_VALUE)
		{
			CloseHandle((HANDLE) pio->u.h);
			pio->u.h = (uintptr_t)-1;
		}
	}
#endif //_WIN32
	else
	{
		_ASSERT(FALSE);
	}
}

int open_compressed_stream(PIO_FILE pio, int mode, int algorithm, char* buf, size_t len)
{
	gzFile gz = (gzFile)0;
	TCHAR szMode[3]; 

	if(algorithm == NETCAT_COMPRESSION_ALGORITHM_NONE)
		return TRUE;
	else if(pio == NULL || 
		(pio->type == runtime_handle && pio->u.file < 0) || 
		(pio->type == socket_handle && pio->u.file == INVALID_SOCKET) 
#ifdef _WIN32
		|| (pio->type == native_handle && pio->u.file == (uintptr_t)-1)
#endif //_WIN32
		)
		return FALSE;
	
	if((mode & O_RDWR) == O_RDWR)
		szMode[0] = _T('w');
	else if((mode & O_RDONLY) == O_RDONLY)
		szMode[0] = _T('r');

	if((mode & O_BINARY) == O_BINARY)
		szMode[1] = _T('b');
	else
		szMode[1] = _T('\0');
	szMode[2] = _T('\0');

	
	if(pio->type == runtime_handle)
	{
		if((gz = gzdopen(pio->u.file, szMode)) == (gzFile) 0)
			return FALSE;
	}
	else if(pio->type == socket_handle)
	{
#ifdef _WIN32
		if(buf != NULL && len > 0)
		{
			if((gz = gzsopen_ex(pio->u.s, szMode, buf, len)) == (gzFile) 0)
				return FALSE;
		}
		else
#endif //_WIN32
		{
			if((gz = gzsopen(pio->u.s, szMode, (struct sockaddr*) 0, 0)) == (gzFile) 0)
				return FALSE;
		}
	}
#ifdef _WIN32
	else if(pio->type == native_handle)
	{
		if((gz = gzosfopen(pio->u.h, szMode)) == (gzFile) 0)
			return FALSE;
	}
#endif //_WIN32
	else 
	{
		return FALSE;
	}
	pio->type = zlib_handle;
	pio->u.gz = gz;
	return TRUE;
}

static int verify_output_file(PIO_FILE out_fd, unsigned char* hash_buffer, size_t len)
{
	if(out_fd == NULL || 
		(out_fd->type == runtime_handle && out_fd->u.file < 0) ||
		(out_fd->type == zlib_handle && out_fd->u.file == (gzFile)0)
	  )
	{
		_ASSERTE(out_fd != NULL);
		holler(_T("invalid file handle"));
		return 0;
	}

	if(hash_buffer == NULL || len == 0)
	{
		_ASSERTE(hash_buffer != NULL && len > 0);
		return 0;
	}

	if(o_checksum == CALG_NOALG)
	{
		_ASSERTE(o_checksum != CALG_NOALG);
		return 0;			
	}

	if(o_checksum == CALG_MD5)
	{
		unsigned char hash_buffer2[MD5_SIGNATURE_SIZE];

		if(len < MD5_SIGNATURE_SIZE)
		{
			holler(_T("hash buffer too small"));
			return 0;
		}
		else if(lseek(out_fd->u.file, 0, SEEK_SET) < 0)
		{
			holler(_T("non-seeking device"));
			return 0;
		}

		if(out_fd->type == runtime_handle && 
			_md5_stream(out_fd->u.file, hash_buffer2, MD5_SIGNATURE_SIZE) == 0)
            return is_equal_md5(hash_buffer, MD5_SIGNATURE_SIZE, hash_buffer2, MD5_SIGNATURE_SIZE);
		else if(out_fd->type == runtime_handle && 
			md5_gzstream(out_fd->u.gz, hash_buffer2, MD5_SIGNATURE_SIZE) == 0)
			return is_equal_md5(hash_buffer, MD5_SIGNATURE_SIZE, hash_buffer2, MD5_SIGNATURE_SIZE);
		holler(_T("verification failed"));
		return 0;
	}
	holler(_T("unsupported checksum algorithm"));
	return 0;
}

/* None genuine without this seal!  _H*/
