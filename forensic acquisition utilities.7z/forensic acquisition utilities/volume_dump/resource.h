//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by volume_dump.rc
//
#define IDS_E_OS_VERSION                2
#define IDS_DRIVE_NO_ROOT_DIR           3
#define IDS_DRIVE_REMOVABLE             4
#define IDS_DRIVE_FIXED                 5
#define IDS_DRIVE_REMOTE                6
#define IDS_DRIVE_CDROM                 7
#define IDS_DRIVE_RAMDISK               8
#define IDS_DRIVE_UNKNOWN               9
#define IDS_HELP                        10
#define IDS_MOUNTPOINTSNOTAVAILABLE     11
#define IDS_MICROSOFTWINDOWS            12
#define IDS_PERSONAL                    13
#define IDS_PROFESSIONAL                14
#define IDS_DATACENTER                  15
#define IDS_ADVANCEDSERVER              16
#define IDS_SERVER                      17
#define IDS_VERSION                     18

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
