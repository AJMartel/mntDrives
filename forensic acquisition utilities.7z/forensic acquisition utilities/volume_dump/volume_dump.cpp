// volume_dump.cpp : Defines the entry point for the console application.
//
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#include "stdafx.h"
#include "resource.h"
#include <security.h>

using namespace std;

#define OS_VERSION_MAJOR_REQUIRED 5
#define OS_VERSION_MINOR_REQUIRED 0
#define BIG_BUFFER_SIZE 1024
#define DRIVE_TYPE_LENGTH 32

// New for Windows XP
#ifndef FILE_READ_ONLY_VOLUME
#define FILE_READ_ONLY_VOLUME           0x00080000  
#endif //FILE_READ_ONLY_VOLUME

#ifndef IOCTL_VOLUME_IS_CLUSTERED
#define IOCTL_VOLUME_IS_CLUSTERED               CTL_CODE(IOCTL_VOLUME_BASE, 12, METHOD_BUFFERED, FILE_ANY_ACCESS)
#endif //IOCTL_VOLUME_IS_CLUSTERED

wchar_t* lpszProgram = (wchar_t*)0;

int __stdcall control_handler ( unsigned long);

const wchar_t* __stdcall load_string(unsigned int nIDString, wchar_t* lpszBuf, int iSize)
{
	if(LoadString(GetModuleHandle(NULL), nIDString, lpszBuf, iSize) <= 0)
	{
		_RPT1(_CRT_WARN, "Error: Failed to load string ID %ld!\n", nIDString);
		return L"";
	}
	return lpszBuf;
}

wchar_t* full_path(const wchar_t* lpszPath)
{
	_ASSERTE(lpszPath != NULL);

	unsigned long dwSize;

	if((dwSize = GetLongPathName(lpszPath, NULL, 0UL)) == 0UL)
		return (wchar_t*)0;

	dwSize = max(dwSize, wcslen(lpszPath));

	wchar_t* lpszFullPath = new wchar_t[dwSize + 5];

	unsigned long dwReturned = GetLongPathName(lpszPath, lpszFullPath, dwSize);
	_ASSERTE(dwReturned == --dwSize);

	return lpszFullPath;
}

wchar_t* get_module_path()
{
	unsigned int i = 0;
	size_t size;

	wchar_t * lpszFullPath = (wchar_t*) 0;
	
	// Unfortunately there is no way to size the module file name
	// other than trial and error.  Increase the path buffer in
	// _MAX_PATH increments.

	do
	{
		
		size = (_MAX_PATH * sizeof(wchar_t) * ++i);

		if(lpszFullPath != NULL)
			delete [] lpszFullPath;

		lpszFullPath = new wchar_t[size];
		
		 
	} while(GetModuleFileName(NULL, lpszFullPath, (unsigned long)size) == 0UL);

	return lpszFullPath;
}

wchar_t* full_exe_path(const wchar_t* lpszPath)
{
	wchar_t* lpszFullPath = full_path(lpszPath);

	if(lpszFullPath == NULL)
		lpszFullPath = get_module_path();
	return lpszFullPath;
}

void display_system_time()
{
	SYSTEMTIME now;
	GetSystemTime(&now);

	TIME_ZONE_INFORMATION ti;

	fwprintf(stderr, L"\n%02d/%02d/%d  %02d:%02d:%02d (UTC)\n",
		    now.wDay, now.wMonth, now.wYear,
			now.wHour, now.wMinute, now.wSecond);

	unsigned long dwResult = GetTimeZoneInformation(&ti);
	
	if(dwResult == TIME_ZONE_ID_INVALID ||
		dwResult == TIME_ZONE_ID_UNKNOWN)
		return;
	
	SYSTEMTIME local;
	if(!SystemTimeToTzSpecificLocalTime(&ti, &now, &local))
		return;

	fwprintf(stderr, L"%02d/%02d/%d  %02d:%02d:%02d (local time)\n\n",
		    local.wDay, local.wMonth, local.wYear,
			local.wHour, local.wMinute, local.wSecond);

}

bool display_os_version()
{
	OSVERSIONINFOEX osvi;
	wchar_t szBuf[32];


	// Try calling GetVersionEx using the OSVERSIONINFOEX structure.
	//
	// If that fails, try using the OSVERSIONINFO structure.

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if(!GetVersionEx ((OSVERSIONINFO *) &osvi))
		return false;

	switch (osvi.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		wcout << load_string(IDS_MICROSOFTWINDOWS, szBuf, 32) << load_string(IDS_VERSION, szBuf, 32)
			  << L" " << dec << osvi.dwMajorVersion << L"." << osvi.dwMinorVersion << L" (Build "
				<< (osvi.dwBuildNumber & 0xFFFF) << L".";
		
		if ( osvi.wProductType == VER_NT_WORKSTATION )
		{
			if( osvi.wSuiteMask & VER_SUITE_PERSONAL )
				wcout << load_string(IDS_PERSONAL, szBuf, 32);
			else
				wcout << load_string(IDS_PROFESSIONAL, szBuf, 32);
		}

		else if ( osvi.wProductType == VER_NT_SERVER )
		{
		   if( osvi.wSuiteMask & VER_SUITE_DATACENTER )
			  wcout << load_string(IDS_DATACENTER, szBuf, 32);
		   else if( osvi.wSuiteMask & VER_SUITE_ENTERPRISE )
			  wcout << load_string(IDS_ADVANCEDSERVER, szBuf, 32);
		   else
			  wcout << load_string(IDS_SERVER, szBuf, 32);
		}
		if(osvi.szCSDVersion[0] != L'\0')
			wcout << L" " << osvi.szCSDVersion;

		wcout << L")" << endl;
        break;
	default:
		;

   }

   return true; 
}

// Remove the trailing '\' from the target path if it exists.
static TCHAR* terminate_trailing_slash(TCHAR* pszString)
{
	size_t nLen;
	if(pszString != NULL && (nLen = _tcslen(pszString)) > 1 &&
		pszString[--nLen] == _T('\\'))
		pszString[nLen] = _T('\0');
	return pszString;
}

void __stdcall initialize_debug_memory()
{
	// Get the current state of the flag
	// and store it in a temporary variable
	int tmpFlag = _CrtSetDbgFlag( _CRTDBG_REPORT_FLAG );

	// Turn on client block identifiers and automatic leak detection
	tmpFlag |= (_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);

	// Set the new state for the flag
	_CrtSetDbgFlag( tmpFlag );
}

bool display_message(unsigned int nIDFormat, ...)
{
	wchar_t szFormat[_MAX_PATH];
	wchar_t szBuffer[_MAX_PATH];

	if(LoadString(GetModuleHandle(NULL), nIDFormat, szFormat, _MAX_PATH) <= 0)
	{
		_RPT1(_CRT_WARN, "Error: Format string ID %ld not found!\n", nIDFormat);
		return false;
	}

	va_list marker;
	va_start(marker, nIDFormat);
	if(_vsnwprintf(szBuffer, _MAX_PATH, szFormat, marker) < 0)
		return false;

	wcout << szBuffer << endl;
	return true;
}


LPCSTR system_error(long lerror, LPSTR lpBuf, unsigned long dwSize)
{
	if((FormatMessageA( 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		lerror,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		lpBuf,
		dwSize,
		NULL 
	)) == 0UL)
		return "";

	return lpBuf;
}

LPCWSTR system_error(long lerror, LPWSTR lpBuf, unsigned long dwSize)
{
	if((FormatMessageW( 
		FORMAT_MESSAGE_FROM_SYSTEM | 
		FORMAT_MESSAGE_IGNORE_INSERTS,
		NULL,
		lerror,
		MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
		lpBuf,
		dwSize,
		NULL 
	)) == 0UL)
		return L"";

	return lpBuf;
}

bool __stdcall check_os_version(unsigned long dwMajorVersion, unsigned long dwMinorVersion)
{

	OSVERSIONINFOEX osvi;
	DWORDLONG dwlConditionMask = 0;

	// Initialize the OSVERSIONINFOEX structure.

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	osvi.dwMajorVersion = dwMajorVersion;
	osvi.dwMinorVersion = dwMinorVersion;

	// Initialize the condition mask.
	VER_SET_CONDITION( dwlConditionMask, VER_MAJORVERSION, VER_GREATER_EQUAL);
	VER_SET_CONDITION( dwlConditionMask, VER_MINORVERSION, VER_GREATER_EQUAL );

	// Perform the test.
	return VerifyVersionInfo(&osvi, 
		                       VER_MAJORVERSION | VER_MINORVERSION,
							   dwlConditionMask) != 0;

}

bool display_current_user(EXTENDED_NAME_FORMAT NameFormat)
{
	using namespace std;

	long lError;
	unsigned long dwSize = 0UL;
	__wchar_t* pszName;

	if(GetUserNameEx(NameFormat, 
		              NULL,
					  &dwSize) ||
		(lError = GetLastError()) != ERROR_MORE_DATA)
	{
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return false;
	}

	pszName = (__wchar_t*)_alloca(dwSize * sizeof(__wchar_t));

	if(!GetUserNameEx(NameFormat, 
		              pszName,
					  &dwSize))
	{
		lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return false;
	}

	wcout << L"Current User: " << pszName <<endl << endl;

	return true;
}

bool __stdcall banner(wchar_t* ProgramName)
{
#ifdef _DEBUG
	char ErrorBufA[BIG_BUFFER_SIZE];
#endif //_DEBUG

	unsigned long dwHandle;
	unsigned long dwSize = GetFileVersionInfoSize(ProgramName, &dwHandle);
	wchar_t* lpszFileDescription;
	wchar_t* lpszProductVersion;
	wchar_t* lpszLegalCopyright;
	wchar_t* lpszProductName;
	wchar_t* lpszFileVersion;

	unsigned int nSize;

	if(dwSize == 0UL)
	{
		_RPT2(_CRT_ERROR, "GetFileVersionInfo size failed! Size = %ld, Last Error = %s\n", dwSize, system_error(GetLastError(), ErrorBufA, BIG_BUFFER_SIZE));
		return false;
	}

	unsigned char* pbData = (unsigned char*)_alloca(dwSize * sizeof(unsigned char));
	if(!GetFileVersionInfo(ProgramName, dwHandle, dwSize, pbData))
	{
		_ASSERT(false);
		return false;
	}

	if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileDescription", 
					  reinterpret_cast<void**>(&lpszFileDescription), 
					  &nSize))
	{
		_ASSERT(false);
		return false;
	}

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductVersion", 
					  reinterpret_cast<void**>(&lpszProductVersion), 
					  &nSize))
	 {
		_ASSERT(false);
		 return false;
	 }

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductName", 
					  reinterpret_cast<void**>(&lpszProductName), 
					  &nSize))
	 {
		_ASSERT(false);
		 return false;
	 }


     if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileVersion", 
					  reinterpret_cast<void**>(&lpszFileVersion), 
					  &nSize))
	 {
		_ASSERT(false);
		 return false;
	 }

	 if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\LegalCopyright", 
					  reinterpret_cast<void**>(&lpszLegalCopyright), 
					  &nSize))
	  {
		 _ASSERT(false);
		  return false;
	  }

	wcout << lpszProductName << L", " << lpszProductVersion << endl;
	wcout << lpszFileDescription << L", " << lpszFileVersion << endl;
	wcout << lpszLegalCopyright << endl << endl << flush;
	wcout << L"Command Line: " << GetCommandLineW() << endl;

	display_os_version();
	display_system_time();
	if(!display_current_user(NameCanonical))
		display_current_user(NameSamCompatible);


	if(!check_os_version(5, 1))
	{
		wchar_t szBuf[_MAX_PATH];
		wcout << load_string(IDS_MOUNTPOINTSNOTAVAILABLE, szBuf, _MAX_PATH);		
	}

	return true;
}

void __stdcall display_volume_flags(unsigned long dwFlags)
{
	wcout << L"Volume Characteristics:" << endl;

	if(dwFlags & FS_CASE_IS_PRESERVED)
		wcout << L"\t\t\tFile system preserves case" << endl;
	if(dwFlags & FS_CASE_SENSITIVE)
		wcout << L"\t\t\tFile system supports case sensitive file names" << endl;
	if(dwFlags & FS_UNICODE_STORED_ON_DISK)
		wcout << L"\t\t\tFile system supports Unicode file names" << endl;
	if(dwFlags & FS_PERSISTENT_ACLS)
		wcout << L"\t\t\tFile system preserves and supports persistent ACL's" << endl;
	if(dwFlags & FS_FILE_COMPRESSION)
		wcout << L"\t\t\tFile system supports file level compression" << endl;
	if(dwFlags & FS_VOL_IS_COMPRESSED)
		wcout << L"\t\t\tVolume is compressed" << endl;
	if(dwFlags & FILE_NAMED_STREAMS)
		wcout << L"\t\t\tFile system supports named streams" << endl;
	if(dwFlags & FS_VOL_IS_COMPRESSED)
		wcout << L"\t\t\tVolume is compressed" << endl;
	if(dwFlags & FILE_READ_ONLY_VOLUME)
		wcout << L"\t\t\tVolume is read only" << endl;
	if(dwFlags & FILE_SUPPORTS_ENCRYPTION)
		wcout << L"\t\t\tFile system supports encryption" << endl;
	if(dwFlags & FILE_SUPPORTS_OBJECT_IDS)
		wcout << L"\t\t\tFile system supports object identifiers" << endl;
	if(dwFlags & FILE_SUPPORTS_REPARSE_POINTS)
		wcout << L"\t\t\tFile system supports reparse points" << endl;
	if(dwFlags & FILE_SUPPORTS_SPARSE_FILES)
		wcout << L"\t\t\tFile system supports sparse files" << endl;
	if(dwFlags & FILE_VOLUME_QUOTAS)
		wcout << L"\t\t\tFile system supports quotas" << endl;
}

void __stdcall display_mount_points(const wchar_t* lprgszMountPoints)
{
	if(!check_os_version(5, 1))
		return;
	
	wcout << L"Mount Points:\t" << endl;	
	if(lprgszMountPoints == NULL ||
		(lprgszMountPoints[0] == L'\0' && lprgszMountPoints[1] == L'\0'))
		return;
	
	do {
		wcout << L"\t\t\t" << lprgszMountPoints << endl;
		lprgszMountPoints += wcslen(lprgszMountPoints);
		_ASSERTE(*lprgszMountPoints == L'\0');
		++lprgszMountPoints;
	} while(*lprgszMountPoints != L'\0');
}

void __stdcall display_disk_extent(PDISK_EXTENT pExtent)
{
	wcout << L"\tDisk Number:\t " << dec << setfill(L' ') << pExtent->DiskNumber << endl;

	wcout << L"\tStarting Offset: 0x" << hex << setw(8) << setfill(L'0') << pExtent->StartingOffset.HighPart << setw(8) << pExtent->StartingOffset.LowPart << endl;
	wcout << L"\tExtent Length:   0x" << hex << setw(8) << pExtent->ExtentLength.HighPart << setw(8) << pExtent->ExtentLength.LowPart << endl;
}

void __stdcall display_volume_disk_extents(PVOLUME_DISK_EXTENTS lpVolumeExtents)
{
	if(lpVolumeExtents == (PVOLUME_DISK_EXTENTS)0)
		return;
		
	wcout << L"Volume Extents:" << endl;

	for(unsigned long i = 0UL; i < lpVolumeExtents->NumberOfDiskExtents; ++i)
		display_disk_extent(lpVolumeExtents->Extents + i);
	wcout << dec << setfill(L' ');
}

void __stdcall display_volume_information(wchar_t* lpszRoot, const wchar_t* lpszVolume, const wchar_t* lprgszMountPoints, const wchar_t* lpszDriveType, unsigned long dwSerialNumber, unsigned long dwMaxComponentLength, unsigned long dwFlags, const wchar_t* lpszFileSystem, PVOLUME_DISK_EXTENTS lpVolumeExtents, const bool& bClustered)
{
	size_t nLen = wcslen(lpszRoot);
	_ASSERTE(nLen);
	
//	lpszRoot[--nLen] = L'\0';
	wcout << L"Volume Name:\t\t" << terminate_trailing_slash(lpszRoot) << endl;
	wcout << L"Volume Label:\t\t" << lpszVolume << endl;
	display_mount_points(lprgszMountPoints);
	wcout << L"Drive Type:\t\t" << lpszDriveType << endl;

	wcout << L"Volume Serial Number:\t\t" << hex << uppercase << (short)(dwSerialNumber >> 16) << L"-" << (short) dwSerialNumber << endl;
	wcout << L"Maximum Component Length:\t" << dec << dwMaxComponentLength << endl;
	display_volume_flags(dwFlags);
	wcout << L"File System:\t\t" << lpszFileSystem << endl;
	
	if(bClustered)
		wcout << L"Clustered:\t\t\t" << L"Yes" << endl;

	display_volume_disk_extents(lpVolumeExtents);	
}

wchar_t* mount_points(const wchar_t* lpszRoot)
{
	typedef BOOL (WINAPI *GETVOLUMEPATHNAMESFORVOLUMENAMEW)(LPCWSTR lpszVolumeName,
														       LPWSTR lpszVolumePathNames,
														       DWORD cchBufferLength,
														       PDWORD lpcchReturnLength);

	GETVOLUMEPATHNAMESFORVOLUMENAMEW pfnGetVolumePathNamesForVolumeNameW = 
		                (GETVOLUMEPATHNAMESFORVOLUMENAMEW) GetProcAddress(GetModuleHandle(L"kernel32.dll"), "GetVolumePathNamesForVolumeNameW");

	unsigned long dwSize;
	if(pfnGetVolumePathNamesForVolumeNameW == NULL ||
		(*pfnGetVolumePathNamesForVolumeNameW)(lpszRoot,
		                               NULL,
									   0UL,
									   &dwSize) ||
		GetLastError() != ERROR_MORE_DATA || dwSize < 2UL)
		return NULL;

	wchar_t* lpszBuf = new wchar_t[dwSize];

	if(!(*pfnGetVolumePathNamesForVolumeNameW)(lpszRoot,
		                               lpszBuf,
									   dwSize,
									   &dwSize))
		return NULL;

	return lpszBuf;
}

const wchar_t* drive_type(const wchar_t* lpszRoot, wchar_t* lpszBuf, unsigned int nLen)
{
	switch(GetDriveType(lpszRoot))
	{
	case DRIVE_NO_ROOT_DIR:
		return load_string(IDS_DRIVE_NO_ROOT_DIR, lpszBuf, nLen);
		break;
	case DRIVE_REMOVABLE:
		return load_string(IDS_DRIVE_REMOVABLE, lpszBuf, nLen);
		break;
	case DRIVE_FIXED:
		return load_string(IDS_DRIVE_FIXED, lpszBuf, nLen);
		break;
	case DRIVE_REMOTE:
		return load_string(IDS_DRIVE_REMOTE, lpszBuf, nLen);
		break;
	case DRIVE_CDROM:
		return load_string(IDS_DRIVE_CDROM, lpszBuf, nLen);
		break;
	case DRIVE_RAMDISK:
		return load_string(IDS_DRIVE_RAMDISK, lpszBuf, nLen);
		break;
	default:
		return load_string(IDS_DRIVE_UNKNOWN, lpszBuf, nLen);
	}
}

PVOLUME_DISK_EXTENTS __stdcall volume_disk_extents(wchar_t* lpszRoot, bool& bClustered)
{
#ifdef _DEBUG
	char ErrorBufA[BIG_BUFFER_SIZE];
#endif //_DEBUG

	bClustered = false;

	if(lpszRoot == NULL || lpszRoot[0] == L'\0')
		return (PVOLUME_DISK_EXTENTS)0;

	size_t nLen = wcslen(lpszRoot);
	_ASSERTE(nLen);
	
	if(nLen >= BIG_BUFFER_SIZE)
		return (PVOLUME_DISK_EXTENTS)0;

	wchar_t szRoot[BIG_BUFFER_SIZE];
	wcsncpy(szRoot, lpszRoot, BIG_BUFFER_SIZE);
	//szRoot[--nLen] = L'\0';

	HANDLE hRoot = CreateFile(terminate_trailing_slash(szRoot), // Volume Name
		                      0UL,      // Query device access (does not read or write to device)
							  FILE_SHARE_READ | FILE_SHARE_WRITE, // Share mode
							  NULL,    // No inheritance
							  OPEN_EXISTING, 
							  FILE_FLAG_NO_BUFFERING,     
							  NULL);   // No template file

	if(hRoot == INVALID_HANDLE_VALUE)
	{
		OutputDebugString(lpszRoot);		
		_RPT1(_CRT_WARN, ":Failed to open volume handle! Last Error = %s\n", system_error(GetLastError(), ErrorBufA, BIG_BUFFER_SIZE));
		return (PVOLUME_DISK_EXTENTS)0;
	}

	unsigned char* pbData = (unsigned char*)0;

	__try
	{

		long lError;
		unsigned long dwSize;
		VOLUME_DISK_EXTENTS de;
		if(DeviceIoControl(hRoot,                              
						   IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,
						   NULL,
						   0UL,
						   &de,
						   sizeof(VOLUME_DISK_EXTENTS),
						   &dwSize,
						   NULL))
		{
			pbData = new unsigned char[dwSize];
			memcpy(pbData, reinterpret_cast<unsigned char*>(&de), dwSize);
			__leave;
		}

		if((lError = GetLastError()) != ERROR_SUCCESS && lError != ERROR_MORE_DATA)
		{
			_RPT1(_CRT_WARN, "IOCTL_GET_VOLUME_DISK_EXTENTS failed!  Last Error = %s\n", system_error(lError, ErrorBufA, BIG_BUFFER_SIZE));
			__leave;
		}

		pbData = new unsigned char[dwSize];
		unsigned long dwReturned;

		if(!DeviceIoControl(hRoot,                              
						   IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,
						   NULL,
						   0UL,
						   pbData,
						   dwSize,
						   &dwReturned,
						   NULL) || dwReturned != dwSize)
		{
			_RPT1(_CRT_WARN, "IOCTL_GET_VOLUME_DISK_EXTENTS failed!  Last Error = %s\n", system_error(GetLastError(), ErrorBufA, BIG_BUFFER_SIZE));
			delete [] pbData;
			pbData = (unsigned char*)0;
			__leave;
		}
		bClustered = (DeviceIoControl(hRoot,                              
						   IOCTL_VOLUME_IS_CLUSTERED,
						   NULL,
						   0UL,
						   NULL,
						   0UL,
						   &dwSize,
						   NULL) == NO_ERROR);
	}
	__finally
	{
		if(hRoot != INVALID_HANDLE_VALUE)
			CloseHandle(hRoot);
	}

	return reinterpret_cast<PVOLUME_DISK_EXTENTS>(pbData);
}

bool __stdcall enum_volume_info(wchar_t* lpszRoot)
{
#ifdef _DEBUG
	char ErrorBufA[BIG_BUFFER_SIZE];
#endif //_DEBUG
	
	unsigned long dwSerialNumber = 0UL;
	unsigned long dwMaxComponentLength = 0UL;
	unsigned long dwFlags = 0UL;
	wchar_t szFileSystem[BIG_BUFFER_SIZE];
	wchar_t szVolume[_MAX_PATH];
	wchar_t szDriveType[DRIVE_TYPE_LENGTH];

	szFileSystem[0] = L'\0';
	szVolume[0] = L'\0'; 

	//Note: This function will fail if not all of the requested information is
	//available (e.g. if the volume is a removable drive and no media is in the 
	//drive).  This is an expected error condition.
	if(!GetVolumeInformation(lpszRoot,
							 szVolume,
							 _MAX_PATH,
							 &dwSerialNumber,
							 &dwMaxComponentLength,
							 &dwFlags,
							 szFileSystem,
							 BIG_BUFFER_SIZE))
	{
		_RPT0(_CRT_WARN, "Failed to get Volume Information for ");
#ifdef _DEBUG
		OutputDebugString(lpszRoot);
#endif //#ifdef _DEBUG
		_RPT1(_CRT_WARN, ": Last Error = %s\n", system_error(GetLastError(), ErrorBufA, BIG_BUFFER_SIZE));
		SetLastError(0L);
	}

	wchar_t* lpszMountPoint = mount_points(lpszRoot);
	bool bClustered;
	PVOLUME_DISK_EXTENTS lpVolumeExtents = volume_disk_extents(lpszRoot, bClustered);

	__try
	{
		display_volume_information(lpszRoot, 
								   szVolume, 
								   lpszMountPoint, 
								   drive_type(lpszRoot, szDriveType, DRIVE_TYPE_LENGTH),
								   dwSerialNumber, 
								   dwMaxComponentLength, 
								   dwFlags, 
								   szFileSystem,
								   lpVolumeExtents,
								   bClustered);
	}
	__finally
	{
		if(lpszMountPoint != NULL)
			delete [] lpszMountPoint;
		if(lpVolumeExtents != NULL)
			delete [] reinterpret_cast<unsigned char*>(lpVolumeExtents);
	}

	return true;
}

bool __stdcall enum_volume_info()
{
	HANDLE hEnum;
	wchar_t szRoot[BIG_BUFFER_SIZE];

	if((hEnum = FindFirstVolume(szRoot, BIG_BUFFER_SIZE)) == INVALID_HANDLE_VALUE)
		return false;

	__try
	{
		do {
			
			enum_volume_info(szRoot);

		} while(FindNextVolume(hEnum, szRoot, BIG_BUFFER_SIZE));
	}
	__finally
	{
		FindVolumeClose(hEnum);
	}

	return (GetLastError() == ERROR_NO_MORE_FILES);
}

int wmain(int argc, wchar_t* argv[])
{
	int result = -1;

	wchar_t ErrorBufW[BIG_BUFFER_SIZE];

	SetConsoleCtrlHandler(control_handler, 1 );
	initialize_debug_memory();
	SetErrorMode(SEM_FAILCRITICALERRORS);

	lpszProgram = full_exe_path(argv[0]);
	wcout << lpszProgram << endl;

	__try
	{
		
		if(!check_os_version(OS_VERSION_MAJOR_REQUIRED, OS_VERSION_MINOR_REQUIRED))
		{
			display_message(IDS_E_OS_VERSION, OS_VERSION_MAJOR_REQUIRED, OS_VERSION_MINOR_REQUIRED, -1);
			__leave;
		}

		banner(lpszProgram);	

		if(argc == 1)
		{
			if(!enum_volume_info())
			{
				wcout << system_error(GetLastError(), ErrorBufW, BIG_BUFFER_SIZE) << endl;
				__leave;
			}
		}
		else if(argc > 2 || 
			wcsnicmp(argv[1], L"-?", 3) == 0 ||
			wcsnicmp(argv[1], L"/?", 3) == 0 ||
			wcsnicmp(argv[1], L"-help", 6) == 0 ||
			wcsnicmp(argv[1], L"/help", 6) == 0)
		{
			wcout << load_string(IDS_HELP, ErrorBufW, BIG_BUFFER_SIZE) << endl;
			__leave;
		}
		else
		{
			if(!enum_volume_info(argv[1]))
			{
				wcout << system_error(GetLastError(), ErrorBufW, BIG_BUFFER_SIZE) << endl;
				__leave;
			}
		}
		result = 0;
	}
	__finally
	{
		if(lpszProgram != (wchar_t*)0)
			delete [] lpszProgram;
	}

	display_system_time();

	return result;
}

//
//  FUNCTION: control_handler ( unsigned long sig )
//
//  PURPOSE: Handled console control events
//
//  PARAMETERS:
//    dwCtrlType - type of control event
//
//  RETURN VALUE:
//    True - handled
//    False - unhandled
//
//  COMMENTS:
//
int __stdcall control_handler ( unsigned long sig )
{
	switch( sig)
    {
        case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
        case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
			wcout << L"Stopping " << lpszProgram << L"..." << endl;
            return 1;
            break;
		default:
			;
    }
    return 0;
}

