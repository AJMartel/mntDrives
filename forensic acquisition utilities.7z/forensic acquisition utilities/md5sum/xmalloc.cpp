//xmalloc.cpp
// Written by George M. Garner Jr. <gmgarner@erols.com> 01/07.02

#if HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef HAVE_NEW_HANDLER
#include <new.h>
#endif // HAVE_NEW_HANDLER


extern "C" {
#include "xmalloc.c"
#ifdef HAVE_NEW_HANDLER
typedef void (__cdecl * new_handler) ();
new_handler __cdecl xset_new_handler(new_handler);
int __cdecl xmalloc_set_new_mode(int);	

int handle_program_memory_depletion( size_t size )
{
	error (xmalloc_exit_failure, 0, _T("Memory exhausted"));

	// Tell new to stop allocation attempts.
   return 0;
}

void xmalloc_initalize_memory_allocation()
{
	_set_new_handler(handle_program_memory_depletion);
	_set_new_mode(1);
}
#else
void xmalloc_initalize_memory_allocation()
{
}
#endif //	HAVE_NEW_HANDLER	

} // extern "C"