/* Compute MD5 checksum of files or strings according to the definition
   of MD5 in RFC 1321 from April 1992.
   Copyright (C) 1995-1999 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

/* Written by Ulrich Drepper <drepper@gnu.ai.mit.edu>.  */
/* Modified by George M. Garner Jr. <gmgarner@erols.com> 01/07/02 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include "getopt.h"
#ifdef NEEDS_STDLIB_H
#include <stdlib.h>
#endif //NEEDS_STDLIB_H
#include <sys/types.h>
#include <sys/stat.h>

#include <stdio.h>
#include <sys/types.h>
#ifdef _WIN32
#include <windows.h>
#include <security.h>
#endif // _WIN32

#include "md5.h"
#include "getline.h"
#include "system.h"
#include "error.h"

/* The official name of this program (e.g., no `g' prefix).  */
#define PROGRAM_NAME _T("md5sum")

#define AUTHORS _T("Ulrich Drepper")

/* Most systems do not distinguish between external and internal
   text representations.  */
/* FIXME: This begs for an autoconf test.  */
#if O_BINARY
# define OPENOPTS(BINARY) ((BINARY) != 0 ? TEXT1TO1 : TEXTCNVT)
# define TEXT1TO1 _T("rb")
# define TEXTCNVT _T("r")
#else
# if defined VMS
#  define OPENOPTS(BINARY) ((BINARY) != 0 ? TEXT1TO1 : TEXTCNVT)
#  define TEXT1TO1 "rb", "ctx=stm"
#  define TEXTCNVT "r", "ctx=stm"
# else
#  if UNIX || __UNIX__ || unix || __unix__ || _POSIX_VERSION
#   define OPENOPTS(BINARY) "r"
#  else
    /* The following line is intended to evoke an error.
       Using #error is not portable enough.  */
    "Cannot determine system type."
#  endif
# endif
#endif

#ifdef _WIN32
  /* Binary is default on MSDOS, so the actual file contents
     are used in computation.  */
	static int binary = 1;
#else
  /* Text is default of the Plumb/Lankester format.  */
	static int binary = 0;
#endif //_WIN32
	void cleanup(void);

	static int do_check = 0;
	static int file_type_specified = 0;
	static size_t n_strings = 0;
	static const TCHAR ** string = NULL;

/* The minimum length of a valid digest line in a file produced
   by `md5sum FILE' and read by `md5sum --check'.  This length does
   not include any newline character at the end of a line.  */
#define MIN_DIGEST_LINE_LENGTH (32 /* message digest length */ \
				+ 2 /* blank and binary indicator */ \
				+ 1 /* minimum filename length */ )

/* Nonzero if any of the files read were the standard input. */
static int have_read_stdin;

static int o_verbose;

/* With --check, don't generate any output.
   The exit code indicates success or failure.  */
static int status_only = 0;

/* With --check, print a message to standard error warning about each
   improperly formatted MD5 checksum line.  */
static int warn = 0;
static int o_decompress = MD5_DECOMPRESSION_ALGORITHM_NONE;
static int o_lock = 0;

/* The name this program was run with.  */
TCHAR *program_name = NULL;

TCHAR *output_file = _T("standard output");

FILE *output_fd = 0;

static void banner(void);
#ifdef _WIN32
TCHAR* get_module_path()
{
	unsigned int i = 0;
	unsigned long dwSize;

	TCHAR * lpszFullPath = (TCHAR*) 0;

	// Unfortunately there is no way to size the module file name
	// other than trial and error.  Increase the path buffer in
	// _MAX_PATH increments.

	do
	{
		
		dwSize = (_MAX_PATH * sizeof(TCHAR) * ++i);

		if(lpszFullPath != NULL)
			free(lpszFullPath);

		lpszFullPath = (TCHAR*) xmalloc((dwSize + 2) * sizeof(TCHAR));
		//lpszFullPath[0] = _T('"');
		 
	} while(GetModuleFileName(NULL, lpszFullPath, dwSize) == 0UL);

//	dwSize = (unsigned long)_tcslen(lpszFullPath);
//	lpszFullPath[dwSize++] = _T('"');
//	lpszFullPath[dwSize] = _T('\0');

	return lpszFullPath;
}
#endif //_WIN32

static TCHAR* full_exe_path(const TCHAR* lpszPath)
{
#ifdef _WIN32
	TCHAR* lpszFullPath = get_module_path();
#else
	TCHAR* lpszFullPath = NULL;
	size_t size;
	do
	{
		
		size = (_MAX_PATH * sizeof(TCHAR) * ++i);

		if(lpszFullPath != NULL)
			free(lpszFullPath);

		lpszFullPath = (TCHAR*) xmalloc(size * sizeof(TCHAR));
		
		 
	} while(makepath(lpszFullPath, lpszPath, size) == 0UL);
#endif //_WIN32
	return lpszFullPath;
}

void usage (int status)
{
  if (status != 0)
    _ftprintf (stderr, _T("Try `%s --help' for more information.\n"),
	     program_name);
  else
    {
      printf (_("\
Usage: %s [OPTION] [FILE]...\n\
  or:  %s [OPTION] --check [FILE]\n\
  or:  %s [OPTION] --check [FILE] --out [OUTPUT FILE] \n\
Print or check MD5 checksums.\n\
With no FILE, or when FILE is -, read standard input.\n\
\n\
  -b, --binary            read files in binary mode (default on DOS/Windows)\n\
  -c, --check             check MD5 sums against given list\n\
  -d, --decompress [library] generate MD5 sums from decompressed input\n\
  -l, --lock			  lock the input file while computing checksum\n\
  -o, --output            send output to [OUTPUT FILE] \n \
  -t, --text              read files in text mode (default)\n\
\n\
The following two options are useful only when verifying checksums:\n\
      --status            don't output anything, status code shows success\n\
  -w, --warn              warn about improperly formated MD5 checksum lines\n\
\n\
      --help              display this help and exit\n\
 -v   --version           output version information\n\
\n\
The sums are computed as described in RFC 1321.  When checking, the input\n\
should be a former output of this program.  The default mode is to print\n\
a line with checksum, a character indicating type (`*' for binary, ` ' for\n\
text), and name for each FILE.\n"),
	      program_name, program_name);
      _putts (_T("\nReport bugs to <gmgarner@erols.com>."));
    }

  exit (status == 0 ? EXIT_SUCCESS : EXIT_FAILURE);
}

TCHAR* full_path(const TCHAR* lpszPath)
{
	size_t count = _MAX_PATH;
	TCHAR* path = (TCHAR*)0;
#ifdef 	_WIN32
	size_t count2;
#endif // _WIN32

	if(lpszPath == NULL ||
		lpszPath[0] == _T('\0'))
		return (TCHAR*)0;

#ifdef 	_WIN32
	count = GetFullPathName(lpszPath, 0UL, 0, 0);

	// On Windows 2000 GetFullPathName() returns less than the
	// required buffer size if NULL is specified for the output buffer
	// and lpszPath points to a device or volume (e.g. "\\.\C:").  The 
	// required buffer size will always be at least as big as the length
	// of the lpszPath argument. Windows XP always returns the correct 
	// buffer size and the following line is not required if only Windows
	// XP is targeted.
	count = max(count, _tcslen(lpszPath));

	if(count == 0)
	{
		error(0, 0, _T("GetFullPathName failed for path %s: Error = %ld"), lpszPath, GetLastError());
		return (TCHAR*)0;
	}	
	
	path = malloc(++count * sizeof(TCHAR));
	
	count2 = GetFullPathName(lpszPath, (unsigned long)count, path, 0);
	_ASSERTE(count2 < count);
	_ASSERTE(_CrtCheckMemory());

	if(count2 == 0UL)
	{
		free(path);
		error(0, 0, _T("GetFullPathName failed for path %s: Error = %ld"), lpszPath, GetLastError());
		return (TCHAR*)0;
	}
#else
	path = malloc(count * sizeof(TCHAR));

	if(_tfullpath(path, lpszPath, MAX_PATH) == NULL)
	{
		free(path);
		return (TCHAR*)0;
	}
#endif //_WIN32
	return path;
}

static int split_3 (char *s, size_t s_len, unsigned char **u, int *binary, char **w)
{
  size_t i;
  int escaped_filename = 0;

#ifdef _WIN32
#define ISWHITE(c) isspace(c)
#else
#define ISWHITE(c) ((c) == ' ' || (c) == '\t')
#endif //_WIN32

  i = 0;
  while (ISWHITE (s[i]))
    ++i;

  /* The line must have at least 35 (36 if the first is a backslash)
     more characters to contain correct message digest information.
     Ignore this line if it is too short.  */
  if (!(s_len - i >= MIN_DIGEST_LINE_LENGTH
	|| (s[i] == '\\' && s_len - i >= 1 + MIN_DIGEST_LINE_LENGTH)))
    return 1;

  if (s[i] == '\\')
    {
      ++i;
      escaped_filename = 1;
    }
  *u = (unsigned char *) &s[i];

  /* The first field has to be the 32-character hexadecimal
     representation of the message digest.  If it is not followed
     immediately by a white space it's an error.  */
  i += 32;
  if (!ISWHITE (s[i]))
    return 1;

  s[i++] = '\0';

  if(s[i] == '[')
  {
	  char* psz;
	  if((psz = strchr(s + i, ']')) == NULL)
		  return 1;

	  i = (psz - s) + 2;
  }

  if (s[i] != ' ' && s[i] != '*')
    return 1;

  *binary = (s[i++] == '*');

  /* All characters between the type indicator and end of line are
     significant -- that includes leading and trailing white space.  */
  *w = s + i;

  if (escaped_filename)
    {
      /* Translate each `\n' string in the file name to a NEWLINE,
	 and each `\\' string to a backslash.  */

      char *dst = &s[i];

      while (i < s_len)
	{
	  switch (s[i])
	    {
	    case '\\':
	      if (i == s_len - 1)
		{
		  /* A valid line does not end with a backslash.  */
		  return 1;
		}
	      ++i;
	      switch (s[i++])
		{
		case 'n':
		  *dst++ = '\n';
		  break;
		case '\\':
		  *dst++ = '\\';
		  break;
		default:
		  /* Only `\' or `n' may follow a backslash.  */
		  return 1;
		}
	      break;

	    case '\0':
	      /* The file name may not contain a NUL.  */
	      return 1;
	      break;

	    default:
	      *dst++ = s[i++];
	      break;
	    }
	}
      *dst = '\0';
    }
  return 0;
}

static int
hex_digits (unsigned char const *s)
{
  while (*s)
    {
      if (!ISXDIGIT (*s))
        return 0;
      ++s;
    }
  return 1;
}

/* An interface to md5_stream.  Operate on FILENAME (it may be "-") and
   put the result in *MD5_RESULT.  Return non-zero upon failure, zero
   to indicate success.  */

#ifdef _UNICODE
static  md5_file_mbcs (const char *filename, int binary, unsigned char *md5_result, size_t result_len, int lock)
{
	int result = 0;
	wchar_t* wfilename;
	size_t count = mbstowcs((wchar_t*)0, filename, 0);

	if(count <= 0)
		return result;

	wfilename = malloc((count+1) * sizeof(wchar_t));

	__try
	{
		
		if(mbstowcs(wfilename, filename, count + 1) < 0) 	
			__leave;
		result = md5_file(wfilename, binary, md5_result, result_len, lock);
	}
	__finally
	{
		if(wfilename)
			free(wfilename);
	}

	return result;
}

static  md5_gzfile_mbcs (const char *filename, int binary, unsigned char *md5_result, size_t result_len)
{
	int result = 0;
	wchar_t* wfilename;
	size_t count = mbstowcs((wchar_t*)0, filename, 0);

	if(count <= 0)
		return result;

	wfilename = malloc((count+1) * sizeof(wchar_t));

	__try
	{
		
		if(mbstowcs(wfilename, filename, count + 1) < 0) 	
			__leave;
		result = md5_gzfile(wfilename, binary, md5_result, result_len, o_lock);
	}
	__finally
	{
		if(wfilename)
			free(wfilename);
	}

	return result;
}
#endif //_UNICODE

static int md5_check (const TCHAR *checkfile_name)
{
  FILE *checkfile_stream = (FILE*)0;
  int n_properly_formated_lines = 0;
  int n_mismatched_checksums = 0;
  int n_open_or_read_failures = 0;
  unsigned char md5buffer[MD5_SIGNATURE_SIZE];
  size_t line_number = 0;
  char *line = (char*)0;
  size_t line_chars_allocated;

  if (STREQ (checkfile_name, _T("-")))
    {
      have_read_stdin = 1;
      checkfile_name = _T("standard input");

      checkfile_stream = stdin;
    }
  else
    {
		checkfile_stream = _tfopen (checkfile_name, _T("r"));
		if (checkfile_stream == NULL)
		{
			error (0, errno, _T("%s"), checkfile_name);
			return 1;
		}
    }


  // gmgarner: The do loop leaked like a sieve.  Should free line on each iteration
  do
    {
      char *filename;
      int binary;
      unsigned char *md5num;
      int err;
      int line_length;

      ++line_number;

	  if(line)
		  free(line);

	  line = NULL;
	  line_number = 0;
	  line_chars_allocated = 0;

      line_length = getline (&line, &line_chars_allocated, checkfile_stream);
      if (line_length <= 0)
		break;

      /* Ignore comment lines, which begin with a '#' character.  */
	  /*gmgarner:  There was a big memory leak here*/
      if (line[0] == '#')
	  {
		 free(line);
		 line = NULL;
		  continue;
	  }

      /* Remove any trailing newline.  */
      if (line[line_length - 1] == '\n')
		line[--line_length] = '\0';

      err = split_3 (line, line_length, &md5num, &binary, &filename);

		if (err || !hex_digits (md5num))
		{
			if (warn)
			{
				error (0, 0,
					_T("%s: %lu: improperly formatted MD5 checksum line"),
					checkfile_name, (unsigned long) line_number);
			}
		}
		else
		{
			int fail;
	
			++n_properly_formated_lines;


			if(o_decompress == MD5_DECOMPRESSION_ALGORITHM_NONE)
			{
#ifdef _UNICODE
				 fail = md5_file_mbcs (filename, binary, md5buffer, MD5_SIGNATURE_SIZE, o_lock);
#else	  
				fail = md5_file (filename, binary, md5buffer, MD5_SIGNATURE_SIZE, o_lock);
#endif //_UNICODE
			}
			else if(o_decompress == MD5_DECOMPRESSION_ALGORITHM_ZLIB)
			{
#ifdef _UNICODE
				fail = md5_gzfile_mbcs (filename, binary, md5buffer, MD5_SIGNATURE_SIZE);
#else	  
				fail = md5_gzfile (filename, binary, md5buffer, MD5_SIGNATURE_SIZE, o_lock);
#endif //_UNICODE
			}

			if (fail)
			{
				++n_open_or_read_failures;
				if(fail == ERROR_LOCK_FAILED)
					error(0, 0, _T("Unable to lock file."));

				if (!status_only)
				{
					_tprintf (_T("%s: FAILED open or read\n"), filename);
					fflush (stdout);
				}
			}
			else
			{
				unsigned char hash[MD5_SIGNATURE_SIZE + 2];

				int cnt = string_to_md5A(md5num, MD5_STRING_SIZE, hash, MD5_SIGNATURE_SIZE);

				if(cnt != MD5_SIGNATURE_SIZE ||
					!is_equal_md5(hash, MD5_SIGNATURE_SIZE, md5buffer, MD5_SIGNATURE_SIZE))
				{
					printf("The count is %ld\n", cnt);
					cnt = 0;
					++n_mismatched_checksums;
				}

				if (!status_only)
				{
					printf ("%s: %s:\n", filename,
						(cnt != MD5_SIGNATURE_SIZE)? "FAILED" : "OK");
					fflush (stdout);
				}
			}
		}
    }  while (!feof (checkfile_stream) && !ferror (checkfile_stream));

	if (line)
		free (line);

	if (ferror (checkfile_stream))
    {
		error (0, 0, _T("%s: read error"), checkfile_name);
		return 1;
    }

	if (checkfile_stream != stdin && fclose (checkfile_stream) == EOF)
    {
      error (0, errno, _T("%s"), checkfile_name);
      return 1;
    }

	if (n_properly_formated_lines == 0)
    {
      /* Warn if no tests are found.  */
      error (0, 0, _T("%s: no properly formatted MD5 checksum lines found"),
	     checkfile_name);
    }
  else
    {
      if (!status_only)
	{
		 int n_computed_checkums = (n_properly_formated_lines
				     - n_open_or_read_failures);

	  if (n_open_or_read_failures > 0)
	    {
	      error (0, 0,
		   _T("WARNING: %d of %d listed %s could not be read\n"),
		     n_open_or_read_failures, n_properly_formated_lines,
		     (n_properly_formated_lines == 1
		      ? _T("file") : _T("files")));
	    }

	  if (n_mismatched_checksums > 0)
	    {
	      error (0, 0,
		   _T("WARNING: %d of %d computed %s did NOT match"),
		     n_mismatched_checksums, n_computed_checkums,
		     (n_computed_checkums == 1
		      ? _T("checksum") : _T("checksums")));
	    }
	}
    }

  return ((n_properly_formated_lines > 0 && n_mismatched_checksums == 0
	   && n_open_or_read_failures == 0) ? 0 : 1);
}
void scanargs(int argc, TCHAR* const* argv)
{
	int opt;
	TCHAR short_options[] = _T("bcd:lo:tvw");
	static const struct option long_options[] =
		{
		{ _T("binary"), no_argument, 0, _T('b') },
		{ _T("check"), no_argument, 0, _T('c') },
		{ _T("decompress"), required_argument, 0, _T('d') },
		{ _T("lock"), no_argument, 0, _T('l') },
		{ _T("status"), no_argument, 0, 2 },
		{ _T("string"), required_argument, 0, 1 },
		{ _T("text"), no_argument, 0, _T('t') },
		{ _T("version"), no_argument, &o_verbose, 1 },
		{ _T("warn"), no_argument, 0, _T('w') },
		{ _T("out"), required_argument, 0, _T('o')},
		{ GETOPT_HELP_OPTION_DECL },
		{ GETOPT_VERSION_OPTION_DECL },
		{ NULL, 0, NULL, 0 }
		};

	while ((opt = getopt_long (argc, argv, short_options, (const POPTION) long_options, NULL)) != -1)
	{
		switch (opt)
		{
		case 0:			/* long option */
		break;
		case 1: /* --string */
		{
			if (string == NULL)
				string = (TCHAR **) xmalloc ((argc - 1) * sizeof (TCHAR *));

			if (optarg == NULL)
				optarg = _T("\0");
			string[n_strings++] = (const TCHAR*)optarg;
		}
		break;
		case _T('b'):
			file_type_specified = 1;
			binary = 1;
			break;
		case _T('c'):
			do_check = 1;
			break;
		case _T('d'):
			if((o_decompress = md5_parse_decompression_algorithm(optarg)) == MD5_DECOMPRESSION_ALGORITHM_UNSUPPORTED)
			error(1, 0, _T("Unsupported decompression algorithm\n"));
			break;
		case 2:
			status_only = 1;
			warn = 0;
			break;
		case _T('l'):
			o_lock = 1;
			break;
		case _T('o'):
			if(optarg == NULL || 
				optarg[0] == _T('\0'))
				error(1, 0, _T("no output file specified"));
			output_file = optarg;
			break;
		case _T('t'):
			file_type_specified = 1;
			binary = 0;
			break;
		case _T('v'):
			o_verbose++;
			break;
		case _T('w'):
			status_only = 0;
			warn = 1;
		break;
			case_GETOPT_HELP_CHAR;
			case_GETOPT_VERSION_CHAR (PROGRAM_NAME, AUTHORS);
		default:
			usage (EXIT_FAILURE);
		}
	}
}

void validate_input()
{
	if (file_type_specified && do_check)
	{
		error (0, 0, _T("the --binary and --text options are meaningless when " 
						_T("verifying checksums")));
		usage (EXIT_FAILURE);
	}

	if (n_strings > 0 && do_check)
	{
		error (0, 0,
		_T("the --string and --check options are mutually exclusive"));
		usage (EXIT_FAILURE);
	}

	if (status_only && !do_check)
	{
		error (0, 0,
		_T("the --status option is meaningful only when verifying checksums"));
		usage (EXIT_FAILURE);
	}

	if (warn && !do_check)
	{
		error (0, 0,
		_T("the --warn option is meaningful only when verifying checksums"));
		usage (EXIT_FAILURE);
	}
}

int compute_hashes_for_string()
{
	size_t i;

	for (i = 0; i < n_strings; ++i)
	{
		unsigned char md5buffer[MD5_SIGNATURE_SIZE];
		TCHAR szSig[MD5_STRING_SIZE + 1];

		if(md5_buffer (string[i], _tcslen (string[i]), md5buffer, MD5_SIGNATURE_SIZE) != 0)
		{
			error(0, errno, _T("Unable to computer md5 hash"));
			continue;
		}
		
		md5_to_string(md5buffer, MD5_SIGNATURE_SIZE, szSig, MD5_SIGNATURE_SIZE + 1);
		_tprintf (_T("%s  \"%s\"\n"), szSig, string[i]);
	}

	return 0;
}

int compute_hash_for_file(const TCHAR* path)
{
	int fail;
	unsigned char md5buffer[MD5_SIGNATURE_SIZE];
	TCHAR *file = full_path(path);

	if(file == (TCHAR*)0)
		return 1;

	if( o_decompress == MD5_DECOMPRESSION_ALGORITHM_NONE)
		fail = md5_file (file, binary, md5buffer, MD5_SIGNATURE_SIZE, o_lock);
	else if(o_decompress == MD5_DECOMPRESSION_ALGORITHM_ZLIB)
		fail = md5_gzfile(file, binary, md5buffer, MD5_SIGNATURE_SIZE, o_lock);

	if(fail)
	{
		if(fail == ERROR_LOCK_FAILED)
			error(0, 0, _T("Unable to lock file."));

		free(file);
		return 1;
	}

	if(_tcsncmp(output_file, _T("standard output"), 16) == 0)
		output_fd = stdout;
	else if((output_fd = _tfopen (output_file, _T("w"))) == 0)
	{
		free(file);
		error(1, errno, _T("Unable to open output file %s"), output_file);
	}


	if(md5_write_digest_entry(output_fd, file, binary, md5buffer, MD5_SIGNATURE_SIZE) != 0)
	{
		free(file);
		error(1, errno, _T("Unable to write digest entry for file %s"), output_file);
	}

	free(file);

	return 0;
}
int _tmain (int argc, TCHAR **argv)
{
  size_t err = 0;  

  /* Setting values of global variables.  */
	program_name = full_exe_path(argv[0]);
	atexit(cleanup);
	setlocale (LC_ALL, "");
	bindtextdomain (PACKAGE, "/usr/local/share/locale");
	textdomain (PACKAGE);

	scanargs(argc, argv);
	validate_input();

	if(o_verbose)
		banner();

	if (n_strings > 0)
    {
		if (optind < argc)
		{
			error (0, 0, _T("no files may be specified when using --string"));
			usage (EXIT_FAILURE);
		}
		err = compute_hashes_for_string();
    }
	else if (do_check)
	{
		if (optind + 1 < argc)
		{
			error (0, 0,
				_T("only one argument may be specified when using --check"));
			usage (EXIT_FAILURE);
		}
		else if (argv[optind] == NULL)
		{
			error(0, 0,
				_T("-c or --check was specified without a valid md5 catalog file"));
			usage (EXIT_FAILURE);
		}

		err = md5_check ((optind == argc) ? _T("-") : argv[optind]);
    }
  else
    {
		if (optind == argc)
			argv[argc++] = _T("-");

		for (; optind < argc; ++optind)
            if((err = compute_hash_for_file(argv[optind])) != 0)
				break;
    }

  if (output_fd != (FILE*) 0 && fclose (output_fd) == EOF)
    error (EXIT_FAILURE, errno, _T("write error"));

  if (have_read_stdin && fclose (stdin) == EOF)
    error (EXIT_FAILURE, errno, _T("standard input"));

  exit (err == 0 ? EXIT_SUCCESS : EXIT_FAILURE);
}

void cleanup(void)
{
	if(program_name != NULL)
	{
		free(program_name);
		program_name = NULL;
	}
}

#ifdef _WIN32

#define BIG_BUFFER_SIZE 1024

static void display_system_time()
{
	unsigned long dwResult;
	SYSTEMTIME now;
	TIME_ZONE_INFORMATION ti;
	SYSTEMTIME local;

	GetSystemTime(&now);

	_ftprintf(stderr, L"\n%02d/%02d/%d  %02d:%02d:%02d (UTC)\n",
		    now.wDay, now.wMonth, now.wYear,
			now.wHour, now.wMinute, now.wSecond);

	dwResult = GetTimeZoneInformation(&ti);
	
	if(dwResult == TIME_ZONE_ID_INVALID ||
		dwResult == TIME_ZONE_ID_UNKNOWN)
		return;
	
	if(!SystemTimeToTzSpecificLocalTime(&ti, &now, &local))
		return;

	_ftprintf(stderr, L"%02d/%02d/%d  %02d:%02d:%02d (local time)\n\n",
		    local.wDay, local.wMonth, local.wYear,
			local.wHour, local.wMinute, local.wSecond);

}

static int display_os_version()
{
	OSVERSIONINFOEX osvi;

	// Try calling GetVersionEx using the OSVERSIONINFOEX structure.
	//
	// If that fails, try using the OSVERSIONINFO structure.

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if(!GetVersionEx ((OSVERSIONINFO *) &osvi))
		return FALSE;

	switch (osvi.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		_ftprintf(stderr, _T("Microsoft Windows: Version %ld.%ld (Build %ld."), 
				osvi.dwMajorVersion, osvi.dwMinorVersion, (osvi.dwBuildNumber & 0xFFFF));
		
		if ( osvi.wProductType == VER_NT_WORKSTATION )
		{
			if( osvi.wSuiteMask & VER_SUITE_PERSONAL )
				_ftprintf(stderr, _T("Personal"));
			else
				_ftprintf(stderr, _T("Professional"));
		}

		else if ( osvi.wProductType == VER_NT_SERVER )
		{
		   if( osvi.wSuiteMask & VER_SUITE_DATACENTER )
			  _ftprintf(stderr, _T("DataCenter"));
		   else if( osvi.wSuiteMask & VER_SUITE_ENTERPRISE )
			  _ftprintf(stderr, _T("Advanced Server"));
		   else
			  _ftprintf(stderr, _T("Server"));
		}
		if(osvi.szCSDVersion[0] != L'\0')
			_ftprintf(stderr, _T(" %s"), osvi.szCSDVersion);

		_ftprintf(stderr, _T(")\n"));
        break;
	default:
		;

   }

   return TRUE; 
}

static BOOL display_current_user(EXTENDED_NAME_FORMAT NameFormat)
{
	long lError;
	unsigned long dwSize = 0UL;
	TCHAR* pszName;

	if(GetUserNameEx(NameFormat, 
		              NULL,
					  &dwSize) ||
		(lError = GetLastError()) != ERROR_MORE_DATA)
	{
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return FALSE;
	}

	pszName = (TCHAR*)_alloca(dwSize * sizeof(TCHAR));

	if(!GetUserNameEx(NameFormat, 
		              pszName,
					  &dwSize))
	{
		lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return FALSE;
	}

	_ftprintf(stderr, _T("Current User: %s\n\n"), pszName);
	return TRUE;
}

static void banner()
{
	unsigned long dwHandle;
	unsigned char* pbData;
	unsigned long dwSize = GetFileVersionInfoSize(program_name, &dwHandle);
	wchar_t* lpszFileDescription;
	wchar_t* lpszProductVersion;
	wchar_t* lpszLegalCopyright;
	wchar_t* lpszProductName;
	wchar_t* lpszFileVersion;
	TCHAR* lpszComment;

	unsigned int nSize;

	if(dwSize == 0UL)
		return;

	pbData = (unsigned char*)_alloca(dwSize * sizeof(unsigned char));
	if(!GetFileVersionInfo(program_name, dwHandle, dwSize, pbData))
	{
		_ASSERT(FALSE);
		return;
	}

	if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileDescription", 
					  (void**)&lpszFileDescription, 
					  &nSize))
	{
		_ASSERT(FALSE);
		return;
	}

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductVersion", 
					  (void**)&lpszProductVersion, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductName", 
					  (void**)&lpszProductName, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }


     if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileVersion", 
					  (void**)&lpszFileVersion, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }

	 if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\LegalCopyright", 
					  (void**)&lpszLegalCopyright, 
					  &nSize))
	  {
		 _ASSERT(FALSE);
		  return;
	  }

	 if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\Comments"), 
					  (void**)&lpszComment, 
					  &nSize))
	  {
		 _ASSERT(FALSE);
		  return;
	  }
	_ftprintf(stderr, _T("%s, %s\n"), lpszProductName, lpszProductVersion);
	_ftprintf(stderr, _T("%s, %s\n"), lpszFileDescription, lpszFileVersion);
	_ftprintf(stderr, _T("%s\n\n"), lpszLegalCopyright);
	_ftprintf(stderr, _T("Command Line: %s\n"), GetCommandLine());
	_ftprintf(stderr, lpszComment);
	_ftprintf(stderr, _T("\n"));

	display_os_version();
	display_system_time();
	if(!display_current_user(NameCanonical))
		display_current_user(NameSamCompatible);

}

#else
static void banner()
{
	  _tprintf (_T("dd (%s) %s\n"), GNU_PACKAGE, VERSION);
}
#endif //_WIN32
