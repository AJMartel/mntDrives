/* md5.h - Declaration of functions and data types used for MD5 sum
   computing library functions.
   Copyright (C) 1995, 1996 Free Software Foundation, Inc.
   NOTE: The canonical source of this file is maintained with the GNU C
   Library.  Bugs can be reported to bug-glibc@prep.ai.mit.edu.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */
/* Modified by George M. Garner Jr. <gmgarner@erols.com> 01/07/02 */

#ifndef _MD5_H
#define _MD5_H 1

#include <stddef.h>
#include <stdio.h>
#if defined HAVE_LIMITS_H || _LIBC
# include <limits.h>
#endif

/* The following contortions are an attempt to use the C preprocessor
   to determine an unsigned integral type that is 32 bits wide.  An
   alternative approach is to use autoconf's AC_CHECK_SIZEOF macro, but
   doing that would require that the configure script compile and *run*
   the resulting executable.  Locally running cross-compiled executables
   is usually not possible.  */

#ifdef _LIBC
# include <sys/types.h>
typedef u_int32_t md5_uint32;
#else
# if defined __STDC__ && __STDC__
#  define UINT_MAX_32_BITS 4294967295U
# else
#  define UINT_MAX_32_BITS 0xFFFFFFFF
# endif

/* If UINT_MAX isn't defined, assume it's a 32-bit type.
   This should be valid for all systems GNU cares about because
   that doesn't include 16-bit systems, and only modern systems
   (that certainly have <limits.h>) have 64+-bit integral types.  */

# ifndef UINT_MAX
#  define UINT_MAX UINT_MAX_32_BITS
# endif

# if UINT_MAX == UINT_MAX_32_BITS
   typedef unsigned int md5_uint32;
# else
#  if USHRT_MAX == UINT_MAX_32_BITS
    typedef unsigned short md5_uint32;
#  else
#   if ULONG_MAX == UINT_MAX_32_BITS
     typedef unsigned long md5_uint32;
#   else
     /* The following line is intended to evoke an error.
        Using #error is not portable enough.  */
     "Cannot determine unsigned 32-bit data type."
#   endif
#  endif
# endif
#endif

#undef __P
#if defined (__STDC__) && __STDC__
#define	__P(x) x
#else
#define	__P(x) ()
#endif

#if defined(MD5LIB_EXPORTS)
#define MD5LIB_API __declspec(dllexport)
#elif defined(MD5LIB_IMPORTS)
#define MD5LIB_API __declspec(dllimport)
#else //MD5LIB_EXPORTS
#define MD5LIB_API extern
#endif //MD5LIB_EXPORTS


#ifndef MD5API 
#ifdef _WIN32
#define MD5API __stdcall
#else
#define MD5API 
#endif //_WIN32
#endif //MD5API 

#define MD5_SIGNATURE_SIZE 16
#define MD5_STRING_SIZE    32

#ifndef ERROR_LOCK_FAILED
#define ERROR_LOCK_FAILED                167L
#endif //ERROR_LOCK_FAILED

#ifdef __cplusplus
extern "C" {
#endif //__cplusplus

#ifdef MD5LIB_EXPORTS
/* Structure to save state of computation between the single steps.  */

typedef struct md5_ctx
{
  md5_uint32 A;
  md5_uint32 B;
  md5_uint32 C;
  md5_uint32 D;

  md5_uint32 total[2];
  md5_uint32 buflen;
  char buffer[128];
} MD5CTX, *PMD5CTX;

#else
typedef uintptr_t PMD5CTX;
#endif //MD5LIB_EXPORTS

typedef uintptr_t gzFile;

enum { MD5_DECOMPRESSION_ALGORITHM_UNSUPPORTED = -1,
	MD5_DECOMPRESSION_ALGORITHM_NONE = 0,
	MD5_DECOMPRESSION_ALGORITHM_ZLIB = 1,
	MD5_DECOMPRESSION_ALGORITHM_DEFAULT = MD5_DECOMPRESSION_ALGORITHM_ZLIB,
};

/*
 * The following three functions are build up the low level used in
 * the functions `md5_stream' and `md5_buffer'.
 */

MD5LIB_API PMD5CTX MD5API md5_alloc_ctx __P ((void));

MD5LIB_API void MD5API md5_free_ctx __P ((PMD5CTX ctx));

/* Initialize structure containing state of computation.
   (RFC 1321, 3.3: Step 3)  */
MD5LIB_API void MD5API md5_init_ctx __P ((PMD5CTX ctx));

/* Starting with the result of former calls of this function (or the
   initialization function update the context for the next LEN bytes
   starting at BUFFER.
   It is necessary that LEN is a multiple of 64!!! */
MD5LIB_API void MD5API md5_process_block __P ((const void *buffer, size_t len,
				    PMD5CTX ctx));

/* Starting with the result of former calls of this function (or the
   initialization function update the context for the next LEN bytes
   starting at BUFFER.
   It is NOT required that LEN is a multiple of 64.  */
MD5LIB_API void MD5API md5_process_bytes __P ((const void *buffer, size_t len,
				    PMD5CTX ctx));

/* Process the remaining bytes in the buffer and put result from CTX
   in first 16 bytes following RESBUF.  The result is always in little
   endian byte order, so that a byte-wise output yields to the wanted
   ASCII representation of the message digest.

   IMPORTANT: On some systems it is required that RESBUF is correctly
   aligned for a 32 bits value.  */
MD5LIB_API void * MD5API md5_finish_ctx __P ((PMD5CTX ctx, void *resbuf, size_t len));


/* Put result from CTX in first 16 bytes following RESBUF.  The result is
   always in little endian byte order, so that a byte-wise output yields
   to the wanted ASCII representation of the message digest.

   IMPORTANT: On some systems it is required that RESBUF is correctly
   aligned for a 32 bits value.  */
MD5LIB_API void * MD5API md5_read_ctx __P ((const PMD5CTX ctx, void *resbuf, size_t len));


/* Compute MD5 message digest for bytes read from STREAM.  The
   resulting message digest number will be written into the 16 bytes
   beginning at RESBLOCK.  Returns 0 for success and non- zero for failure*/
MD5LIB_API int MD5API md5_stream __P ((FILE *stream, void *resblock, size_t len));

MD5LIB_API int MD5API _md5_stream __P ((int stream, void *resblock, size_t len));

MD5LIB_API int MD5API md5_gzstream __P((gzFile stream, void* resblock, size_t len));
/* Compute MD5 message digest for LEN bytes beginning at BUFFER.  The
   result is always in little endian byte order, so that a byte-wise
   output yields to the wanted ASCII representation of the message
   digest.  */
MD5LIB_API void *MD5API md5_buffer __P ((const char *buffer, size_t len, void *resblock, size_t block_len));

/* Utility function compares two MD5 hashes.  Returns zero if the two hashes are 
   not equal, otherwise returns non-zero.*/
MD5LIB_API int MD5API is_equal_md5 __P ((unsigned char* resblock1, size_t len1, unsigned char* resblock2, size_t len2));

/* Utility function converts MD5 hash to a string.
	If the function succeeds, the return value is the number of characters stored in hash, not including the 
	terminating null character.  If the function fails, the return value is a negative number.
	hash_len is measured in bytes.  buffer_len is measured in characters and 
	must be at least MD5_STRING_SIZE + 1 characters in size.*/
MD5LIB_API int MD5API md5_to_stringA __P ((unsigned char* hash, size_t hash_len, char* buffer, size_t buffer_len));

/* Utility function converts a string to an MD5 hash value.
	Returns a negative number if the function fails and the number of significant bytes in buffer 
	if the function successfully converts the string to a MD5 hash.  string_len is measured in characters. 
	buffer_len is measured in bytes and must be at least MD5_SIGNATURE_SIZE bytes in size.  The return
	value on success should always be MD5_SIGNATURE_SIZE*/
MD5LIB_API int MD5API string_to_md5A __P ((const char* string, size_t string_len, unsigned char* buffer, size_t buffer_len));

/* Utility function converts MD5 hash to a string.
	If the function succeeds, the return value is the number of characters stored in hash, not including the 
	terminating null character.  If the function fails, the return value is a negative number.
	hash_len is measured in bytes.  buffer_len is measured in characters and 
	must be at least MD5_STRING_SIZE + 1 characters in size.*/
MD5LIB_API int MD5API md5_to_stringU __P ((unsigned char* hash, size_t hash_len, __wchar_t* buffer, size_t buffer_len));

/* Utility function converts a string to an MD5 hash value.
	Returns a negative number if the function fails and the number of significant bytes in buffer 
	if the function successfully converts the string to a MD5 hash.  string_len is measured in characters. 
	buffer_len is measured in bytes and must be at least MD5_SIGNATURE_SIZE bytes in size.  The return
	value on success should always be MD5_SIGNATURE_SIZE*/
MD5LIB_API int MD5API string_to_md5U __P ((const __wchar_t* string, size_t string_len, unsigned char* buffer, size_t buffer_len));

#ifdef _UNICODE 
#define md5_to_string md5_to_stringU
#define string_to_md5 string_to_md5U
#else
#define md5_to_string md5_to_stringA
#define string_to_md5 string_to_md5A
#endif //_UNICODE

/*
Compute a MD5 hash of a file based on the path, file type (binary or text) and 
place the result into the buffer specified at md5_result that is at least result_len
bytes in length.  binary specified whether or not the the file specfied by filename
is a binary or text file (TRUE or FALSE).  The lock parameter specifies whether or 
not the entire range of the input file should be locked during hash computation.  Returns
0 to indicate success and not 0 to indicate failure.
*/
MD5LIB_API int MD5API md5_file __P ((const TCHAR *filename, int binary, unsigned char *md5_result, size_t result_len, int lock));

/*
Compute a MD5 hash of a zlib compressed file based on the path, file type (binary or text) and 
place the result into the buffer specified at md5_result that is at least result_len
bytes in length.  binary specified whether or not the the file specfied by filename
is a binary or text file (TRUE or FALSE).  For compressed files this parameter should 
always be TRUE and md5_gzfile will fail otherwise.  The lock parameter specifies whether or 
not the entire range of the input file should be locked during hash computation.  Returns
0 to indicate success  and not 0 to indicate failure.
*/
MD5LIB_API int MD5API md5_gzfile __P ((const TCHAR *filename, int binary, unsigned char *md5_result, size_t result_len, int lock));

/*
Parse the input string specified by algorithm and return an integer value representing the 
compression algorithm.  Returns MD5_DECOMPRESSION_ALGORITHM_DEFAULT if the algorithm is 
a NULL pointer or points to a null string.  Returns MD5_DECOMPRESSION_ALGORITHM_ZLIB if
the string is "zlib" (case insensitive) and returns MD5_DECOMPRESSION_ALGORITHM_UNSUPPORTED
if the string is anything else.  
*/
MD5LIB_API int MD5API md5_parse_decompression_algorithm __P ((const TCHAR* algorithm));

/*
Writes a MD5 digest entry in md5sum digest format.  Returns 0 for success and not 0
if an error occurs.
*/
MD5LIB_API int MD5API md5_write_digest_entry __P ((FILE* fp, const TCHAR* file, int binary, unsigned char* buffer, size_t buffer_len));

#ifdef __cplusplus
} //extern "C" 
#endif //__cplusplus

#endif //_MD5_H
