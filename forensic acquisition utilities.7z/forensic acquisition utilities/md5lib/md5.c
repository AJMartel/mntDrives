/* md5.c - Functions to compute MD5 message digest of files or memory blocks
   according to the definition of MD5 in RFC 1321 from April 1992.
   Copyright (C) 1995, 1996 Free Software Foundation, Inc.
   NOTE: The canonical source of this file is maintained with the GNU C
   Library.  Bugs can be reported to bug-glibc@prep.ai.mit.edu.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

/* Written by Ulrich Drepper <drepper@gnu.ai.mit.edu>, 1995.  */
/* Modified by George M. Garner Jr. <gmgarner@erols.com> 01/07/02 */

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <sys/types.h>
#include <sys/locking.h>
#include "md5.h"
#include <io.h>
#include <fcntl.h>
#if STDC_HEADERS || defined _LIBC
# include <stdlib.h>
# include <string.h>
#else
# if !defined(HAVE_MEMCPY)
#  pragma message("Warning: HAVE_MEMCPY is not defined!")
#  define memcpy(d, s, n) bcopy ((s), (d), (n))
# endif
#endif
#include <sys/types.h>
#include <sys/stat.h>

#include "zlib.h"


#ifdef _LIBC
# include <endian.h>
# if __BYTE_ORDER == __BIG_ENDIAN
#  define WORDS_BIGENDIAN 1
# endif
#endif //_LIBC

#if defined(WORDS_BIGENDIAN)
# define SWAP(n) \ 
	(((n) << 24) | (((n) & 0xff00) << 8) | (((n) >> 8) & 0xff00) | ((n) >> 24))
#else
# define SWAP(n) (n)
#endif

/* Most systems do not distinguish between external and internal
   text representations.  */
/* FIXME: This begs for an autoconf test.  */
#if O_BINARY
# define OPENOPTS(BINARY) ((BINARY) != 0 ? TEXT1TO1 : TEXTCNVT)
# define TEXT1TO1 _T("rb")
# define TEXTCNVT _T("r")
#else
# if defined VMS
#  define OPENOPTS(BINARY) ((BINARY) != 0 ? TEXT1TO1 : TEXTCNVT)
#  define TEXT1TO1 "rb", "ctx=stm"
#  define TEXTCNVT "r", "ctx=stm"
# else
#  if UNIX || __UNIX__ || unix || __unix__ || _POSIX_VERSION
#   define OPENOPTS(BINARY) "r"
#  else
    /* The following line is intended to evoke an error.
       Using #error is not portable enough.  */
#pragma message("Cannot determine system type.")
#  endif
# endif
#endif

/* This array contains the bytes used to pad the buffer to the next
   64-byte boundary.  (RFC 1321, 3.1: Step 1)  */
static const unsigned char fillbuf[64] = { 0x80, 0 /* , 0, 0, ...  */ };


MD5LIB_API PMD5CTX MD5API md5_alloc_ctx (void)
{
	PMD5CTX p = (PMD5CTX) malloc(sizeof(MD5CTX));
	memset(p, 0, sizeof(MD5CTX));
	return p;
}

MD5LIB_API void MD5API md5_free_ctx (PMD5CTX ctx)
{
	if(ctx != (PMD5CTX)0)
		free(ctx);
}

/* Initialize structure containing state of computation.
   (RFC 1321, 3.3: Step 3)  */
void MD5API md5_init_ctx (struct md5_ctx *ctx)
{
  ctx->A = 0x67452301;
  ctx->B = 0xefcdab89;
  ctx->C = 0x98badcfe;
  ctx->D = 0x10325476;

  ctx->total[0] = ctx->total[1] = 0;
  ctx->buflen = 0;
}

/* Put result from CTX in first 16 bytes following RESBUF.  The result
   must be in little endian byte order.

   IMPORTANT: On some systems it is required that RESBUF is correctly
   aligned for a 32 bits value.  */
void * MD5API md5_read_ctx (const struct md5_ctx *ctx, void *resbuf, size_t len)
{
  if(len < MD5_SIGNATURE_SIZE)
	  return NULL;

  ((md5_uint32 *) resbuf)[0] = SWAP (ctx->A);
  ((md5_uint32 *) resbuf)[1] = SWAP (ctx->B);
  ((md5_uint32 *) resbuf)[2] = SWAP (ctx->C);
  ((md5_uint32 *) resbuf)[3] = SWAP (ctx->D);

  return resbuf;
}

/* Process the remaining bytes in the internal buffer and the usual
   prolog according to the standard and write the result to RESBUF.

   IMPORTANT: On some systems it is required that RESBUF is correctly
   aligned for a 32 bits value.  */
void *MD5API md5_finish_ctx (struct md5_ctx *ctx, void *resbuf, size_t len)
{
	/* Take yet unprocessed bytes into account.  */
  md5_uint32 bytes = ctx->buflen;
  size_t pad;

  /* Now count remaining bytes.  */
  ctx->total[0] += bytes;
  if (ctx->total[0] < bytes)
    ++ctx->total[1];

  pad = bytes >= 56 ? 64 + 56 - bytes : 56 - bytes;
  memcpy (&ctx->buffer[bytes], fillbuf, pad);

  /* Put the 64-bit file length in *bits* at the end of the buffer.  */
  *(md5_uint32 *) &ctx->buffer[bytes + pad] = SWAP (ctx->total[0] << 3);
  *(md5_uint32 *) &ctx->buffer[bytes + pad + 4] = SWAP ((ctx->total[1] << 3) |
							(ctx->total[0] >> 29));

  /* Process last bytes.  */
  md5_process_block (ctx->buffer, bytes + pad + 8, ctx);

  return md5_read_ctx (ctx, resbuf, len);
}

/* Compute MD5 message digest for bytes read from STREAM.  The
   resulting message digest number will be written into the 16 bytes
   beginning at RESBLOCK.  */
int MD5API md5_stream (FILE *stream, void *resblock, size_t len)
{
  /* Important: BLOCKSIZE must be a multiple of 64.  */
#define BLOCKSIZE 4096
  struct md5_ctx ctx;
  char buffer[BLOCKSIZE + 72];
  size_t sum;

  memset(&buffer, 0, BLOCKSIZE + 72);

  /* Initialize the computation context.  */
  md5_init_ctx (&ctx);

  /* Iterate over full file contents.  */
  while (1)
    {
      /* We read the file in blocks of BLOCKSIZE bytes.  One call of the
	 computation function processes the whole buffer so that with the
	 next round of the loop another block can be read.  */
      size_t n;
      sum = 0;

      /* Read block.  Take care for partial reads.  */
      do
	{
	  Sleep(0); // added 8/17/2004
		n = fread (buffer + sum, 1, BLOCKSIZE - sum, stream);

	  sum += n;
	}
      while (sum < BLOCKSIZE && n != 0);
      if (n == 0 && ferror (stream))
        return 1;

      /* If end of file is reached, end the loop.  */
      if (n == 0)
		break;

      /* Process buffer with BLOCKSIZE bytes.  Note that
			BLOCKSIZE % 64 == 0
       */
      md5_process_block (buffer, BLOCKSIZE, &ctx);
    }

  /* Add the last bytes if necessary.  */
  if (sum > 0)
    md5_process_bytes (buffer, sum, &ctx);

  /* Construct result in desired memory.  */
  if(md5_finish_ctx (&ctx, resblock, len) != NULL)
	  return 0;
  return 1;
}

/* Compute MD5 message digest for bytes read from STREAM.  The
   resulting message digest number will be written into the 16 bytes
   beginning at RESBLOCK.  */
int MD5API md5_gzstream (gzFile stream, void *resblock, size_t len)
{
  /* Important: BLOCKSIZE must be a multiple of 64.  */
#define BLOCKSIZE 4096
	int err;
  struct md5_ctx ctx;
  char buffer[BLOCKSIZE + 72];
  size_t sum;

  memset(&buffer, 0, BLOCKSIZE + 72);

  /* Initialize the computation context.  */
  md5_init_ctx (&ctx);

  /* Iterate over full file contents.  */
  while (1)
    {
      /* We read the file in blocks of BLOCKSIZE bytes.  One call of the
	 computation function processes the whole buffer so that with the
	 next round of the loop another block can be read.  */
      int n;
      sum = 0;

      /* Read block.  Take care for partial reads.  */
	do {
		Sleep(0); //added 8/17/2004

		if((n = gzread (stream, buffer + sum, (unsigned int)BLOCKSIZE - sum)) < 0)
			break;

		sum += n;

	} while (sum < BLOCKSIZE && n > 0 && !gzeof(stream));

      if(gzeof(stream))
		  break;
	  else if (n < 0)
	  {
		  _ftprintf(stderr, gzerror (stream, &err));
		  return 1;
	  }

      /* Process buffer with BLOCKSIZE bytes.  Note that
			BLOCKSIZE % 64 == 0
       */
      md5_process_block (buffer, BLOCKSIZE, &ctx);
    }

  /* Add the last bytes if necessary.  */
	if (sum > 0)
		md5_process_bytes (buffer, sum, &ctx);

   /* Construct result in desired memory.  */
	if(md5_finish_ctx (&ctx, resblock, len) != NULL)
		return 0;
  
	return 1;
}

/* Compute MD5 message digest for bytes read from STREAM.  The
   resulting message digest number will be written into the 16 bytes
   beginning at RESBLOCK.  */
int MD5API _md5_stream (int stream, void *resblock, size_t len)
{
  /* Important: BLOCKSIZE must be a multiple of 64.  */
#define BLOCKSIZE 4096
  struct md5_ctx ctx;
  char buffer[BLOCKSIZE + 72];
  size_t sum;
  unsigned int count = 0;

  

  /* Initialize the computation context.  */
  md5_init_ctx (&ctx);

  /* Iterate over full file contents.  */
  while (1)
    {
      /* We read the file in blocks of BLOCKSIZE bytes.  One call of the
	 computation function processes the whole buffer so that with the
	 next round of the loop another block can be read.  */
      size_t n;
      sum = 0;
	 
	  memset(&buffer, 0, BLOCKSIZE);
      /* Read block.  Take care for partial reads.  */
      do
	{
	  Sleep(0); // added 8/17/2004
		n = read (stream, buffer + sum, (unsigned int)BLOCKSIZE - sum);
	  if (n < 0)
		  break;

	  sum += n;
	}
      while (sum < BLOCKSIZE && n != 0);

      if (n < 0)
        return 1;

      /* If end of file is reached, end the loop.  */
      if (n == 0)
	break;

      /* Process buffer with BLOCKSIZE bytes.  Note that
			BLOCKSIZE % 64 == 0
       */
	  count++;
	  _RPT2(_CRT_WARN, "%ld. Calling md5_process_block for %ld bytes\n", count, BLOCKSIZE);
      md5_process_block (buffer, BLOCKSIZE, &ctx);
    }

  /* Add the last bytes if necessary.  */
  if (sum > 0)
  {
	  count++;
	  _RPT2(_CRT_WARN, "%ld. Calling md5_process_bytes for %ld bytes\n", count, sum);
    
	  md5_process_bytes (buffer, sum, &ctx);
  }
  
  /* Construct result in desired memory.  */
  if(md5_finish_ctx (&ctx, resblock, len) != NULL)
	return 0;
  
  return 1;
}

/* Compute MD5 message digest for LEN bytes beginning at BUFFER.  The
   result is always in little endian byte order, so that a byte-wise
   output yields to the wanted ASCII representation of the message
   digest.  */
void *MD5API md5_buffer (const char *buffer, size_t len, void *resblock, size_t block_len)
{
	struct md5_ctx ctx;

	if(block_len < MD5_SIGNATURE_SIZE)
		return NULL;
	/* Initialize the computation context.  */
	md5_init_ctx (&ctx);

	/* Process whole buffer but last len % 64 bytes.  */
	md5_process_bytes (buffer, len, &ctx);

	/* Put result in desired memory area.  */
	return md5_finish_ctx (&ctx, resblock, block_len);
}


void MD5API md5_process_bytes (const void *buffer, size_t len, struct md5_ctx *ctx)
{
  /* When we already have some bits in our internal buffer concatenate
     both inputs first.  */
  if (ctx->buflen != 0)
    {
      size_t left_over = ctx->buflen;
      size_t add = 128 - left_over > len ? len : 128 - left_over;

      memcpy (&ctx->buffer[left_over], buffer, add);
      ctx->buflen += (md5_uint32) add;

      if (left_over + add > 64)
	{
	  md5_process_block (ctx->buffer, (left_over + add) & ~63, ctx);
	  /* The regions in the following copy operation cannot overlap.  */
	  memcpy (ctx->buffer, &ctx->buffer[(left_over + add) & ~63],
		  (left_over + add) & 63);
	  ctx->buflen = (md5_uint32) (left_over + add) & 63;
	}

      buffer = (const char *) buffer + add;
      len -= add;
    }

  /* Process available complete blocks.  */
  if (len > 64)
    {
      md5_process_block (buffer, len & ~63, ctx);
      buffer = (const char *) buffer + (len & ~63);
      len &= 63;
    }

  /* Move remaining bytes in internal buffer.  */
  if (len > 0)
    {
      memcpy (ctx->buffer, buffer, len);
      ctx->buflen = (md5_uint32) len;
    }
}


/* These are the four functions used in the four steps of the MD5 algorithm
   and defined in the RFC 1321.  The first function is a little bit optimized
   (as found in Colin Plumbs public domain implementation).  */
/* #define FF(b, c, d) ((b & c) | (~b & d)) */
#define FF(b, c, d) (d ^ (b & (c ^ d)))
#define FG(b, c, d) FF (d, b, c)
#define FH(b, c, d) (b ^ c ^ d)
#define FI(b, c, d) (c ^ (b | ~d))

/* Process LEN bytes of BUFFER, accumulating context into CTX.
   It is assumed that LEN % 64 == 0.  */

void MD5API md5_process_block (const void *buffer, size_t len, struct md5_ctx *ctx)
{
  md5_uint32 correct_words[16];
  const md5_uint32 *words = buffer;
  size_t nwords = len / sizeof (md5_uint32);
  const md5_uint32 *endp = words + nwords;
  md5_uint32 A = ctx->A;
  md5_uint32 B = ctx->B;
  md5_uint32 C = ctx->C;
  md5_uint32 D = ctx->D;

  /* First increment the byte count.  RFC 1321 specifies the possible
     length of the file up to 2^64 bits.  Here we only compute the
     number of bytes.  Do a double word increment.  */
  ctx->total[0] += (md5_uint32) len;
  if (ctx->total[0] < len)
    ++ctx->total[1];

  /* Process all bytes in the buffer with 64 bytes in each round of
     the loop.  */
  while (words < endp)
    {
      md5_uint32 *cwp = correct_words;
      md5_uint32 A_save = A;
      md5_uint32 B_save = B;
      md5_uint32 C_save = C;
      md5_uint32 D_save = D;

      /* First round: using the given function, the context and a constant
	 the next context is computed.  Because the algorithms processing
	 unit is a 32-bit word and it is determined to work on words in
	 little endian byte order we perhaps have to change the byte order
	 before the computation.  To reduce the work for the next steps
	 we store the swapped words in the array CORRECT_WORDS.  */

#define OP(a, b, c, d, s, T)						\
      do								\
        {								\
	  a += FF (b, c, d) + (*cwp++ = SWAP (*words)) + T;		\
	  ++words;							\
	  CYCLIC (a, s);						\
	  a += b;							\
        }								\
      while (0)

      /* It is unfortunate that C does not provide an operator for
	 cyclic rotation.  Hope the C compiler is smart enough.  */
#define CYCLIC(w, s) (w = (w << s) | (w >> (32 - s)))

      /* Before we start, one word to the strange constants.
	 They are defined in RFC 1321 as

	 T[i] = (int) (4294967296.0 * fabs (sin (i))), i=1..64
       */

      /* Round 1.  */
      OP (A, B, C, D,  7, 0xd76aa478);
      OP (D, A, B, C, 12, 0xe8c7b756);
      OP (C, D, A, B, 17, 0x242070db);
      OP (B, C, D, A, 22, 0xc1bdceee);
      OP (A, B, C, D,  7, 0xf57c0faf);
      OP (D, A, B, C, 12, 0x4787c62a);
      OP (C, D, A, B, 17, 0xa8304613);
      OP (B, C, D, A, 22, 0xfd469501);
      OP (A, B, C, D,  7, 0x698098d8);
      OP (D, A, B, C, 12, 0x8b44f7af);
      OP (C, D, A, B, 17, 0xffff5bb1);
      OP (B, C, D, A, 22, 0x895cd7be);
      OP (A, B, C, D,  7, 0x6b901122);
      OP (D, A, B, C, 12, 0xfd987193);
      OP (C, D, A, B, 17, 0xa679438e);
      OP (B, C, D, A, 22, 0x49b40821);

      /* For the second to fourth round we have the possibly swapped words
	 in CORRECT_WORDS.  Redefine the macro to take an additional first
	 argument specifying the function to use.  */
#undef OP
#define OP(f, a, b, c, d, k, s, T)					\
      do 								\
	{								\
	  a += f (b, c, d) + correct_words[k] + T;			\
	  CYCLIC (a, s);						\
	  a += b;							\
	}								\
      while (0)

      /* Round 2.  */
      OP (FG, A, B, C, D,  1,  5, 0xf61e2562);
      OP (FG, D, A, B, C,  6,  9, 0xc040b340);
      OP (FG, C, D, A, B, 11, 14, 0x265e5a51);
      OP (FG, B, C, D, A,  0, 20, 0xe9b6c7aa);
      OP (FG, A, B, C, D,  5,  5, 0xd62f105d);
      OP (FG, D, A, B, C, 10,  9, 0x02441453);
      OP (FG, C, D, A, B, 15, 14, 0xd8a1e681);
      OP (FG, B, C, D, A,  4, 20, 0xe7d3fbc8);
      OP (FG, A, B, C, D,  9,  5, 0x21e1cde6);
      OP (FG, D, A, B, C, 14,  9, 0xc33707d6);
      OP (FG, C, D, A, B,  3, 14, 0xf4d50d87);
      OP (FG, B, C, D, A,  8, 20, 0x455a14ed);
      OP (FG, A, B, C, D, 13,  5, 0xa9e3e905);
      OP (FG, D, A, B, C,  2,  9, 0xfcefa3f8);
      OP (FG, C, D, A, B,  7, 14, 0x676f02d9);
      OP (FG, B, C, D, A, 12, 20, 0x8d2a4c8a);

      /* Round 3.  */
      OP (FH, A, B, C, D,  5,  4, 0xfffa3942);
      OP (FH, D, A, B, C,  8, 11, 0x8771f681);
      OP (FH, C, D, A, B, 11, 16, 0x6d9d6122);
      OP (FH, B, C, D, A, 14, 23, 0xfde5380c);
      OP (FH, A, B, C, D,  1,  4, 0xa4beea44);
      OP (FH, D, A, B, C,  4, 11, 0x4bdecfa9);
      OP (FH, C, D, A, B,  7, 16, 0xf6bb4b60);
      OP (FH, B, C, D, A, 10, 23, 0xbebfbc70);
      OP (FH, A, B, C, D, 13,  4, 0x289b7ec6);
      OP (FH, D, A, B, C,  0, 11, 0xeaa127fa);
      OP (FH, C, D, A, B,  3, 16, 0xd4ef3085);
      OP (FH, B, C, D, A,  6, 23, 0x04881d05);
      OP (FH, A, B, C, D,  9,  4, 0xd9d4d039);
      OP (FH, D, A, B, C, 12, 11, 0xe6db99e5);
      OP (FH, C, D, A, B, 15, 16, 0x1fa27cf8);
      OP (FH, B, C, D, A,  2, 23, 0xc4ac5665);

      /* Round 4.  */
      OP (FI, A, B, C, D,  0,  6, 0xf4292244);
      OP (FI, D, A, B, C,  7, 10, 0x432aff97);
      OP (FI, C, D, A, B, 14, 15, 0xab9423a7);
      OP (FI, B, C, D, A,  5, 21, 0xfc93a039);
      OP (FI, A, B, C, D, 12,  6, 0x655b59c3);
      OP (FI, D, A, B, C,  3, 10, 0x8f0ccc92);
      OP (FI, C, D, A, B, 10, 15, 0xffeff47d);
      OP (FI, B, C, D, A,  1, 21, 0x85845dd1);
      OP (FI, A, B, C, D,  8,  6, 0x6fa87e4f);
      OP (FI, D, A, B, C, 15, 10, 0xfe2ce6e0);
      OP (FI, C, D, A, B,  6, 15, 0xa3014314);
      OP (FI, B, C, D, A, 13, 21, 0x4e0811a1);
      OP (FI, A, B, C, D,  4,  6, 0xf7537e82);
      OP (FI, D, A, B, C, 11, 10, 0xbd3af235);
      OP (FI, C, D, A, B,  2, 15, 0x2ad7d2bb);
      OP (FI, B, C, D, A,  9, 21, 0xeb86d391);

      /* Add the starting values of the context.  */
      A += A_save;
      B += B_save;
      C += C_save;
      D += D_save;
    }

  /* Put checksum in context given as argument.  */
  ctx->A = A;
  ctx->B = B;
  ctx->C = C;
  ctx->D = D;
}

int MD5API is_equal_md5(unsigned char* resblock1, size_t len1, unsigned char* resblock2, size_t len2)
{
	if(len1 != MD5_SIGNATURE_SIZE ||
		len2 != MD5_SIGNATURE_SIZE ||
		memcmp(resblock1, resblock2, MD5_SIGNATURE_SIZE) != 0)
		return 0;
	return 1;
}

int MD5API md5_to_stringA(unsigned char* hash, size_t hash_len, char* buffer, size_t buffer_len)
{
	if(hash == NULL || 
		hash_len < MD5_SIGNATURE_SIZE ||
		buffer == NULL ||
		buffer_len < (MD5_STRING_SIZE + 1))
		return -1;

	return _snprintf(buffer, buffer_len, 
		   "%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x", 
		   hash[0], 
		   hash[1], 
		   hash[2], 
		   hash[3], 
		   hash[4], 
		   hash[5], 
		   hash[6], 
		   hash[7],
		   hash[8],
		   hash[9],
		   hash[10],
		   hash[11],
		   hash[12],
		   hash[13],
		   hash[14],
		   hash[15]);

}

int MD5API md5_to_stringU(unsigned char* hash, size_t hash_len, __wchar_t* buffer, size_t buffer_len)
{
	if(hash == NULL || 
		hash_len < MD5_SIGNATURE_SIZE ||
		buffer == NULL ||
		buffer_len < (MD5_STRING_SIZE + 1))
		return -1;

	return _snwprintf(buffer, buffer_len, 
		   L"%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x%02x", 
		   hash[0], 
		   hash[1], 
		   hash[2], 
		   hash[3], 
		   hash[4], 
		   hash[5], 
		   hash[6], 
		   hash[7],
		   hash[8],
		   hash[9],
		   hash[10],
		   hash[11],
		   hash[12],
		   hash[13],
		   hash[14],
		   hash[15]);

}

int MD5API string_to_md5A(const char* string, size_t string_len, unsigned char* buffer, size_t buffer_len)
{
	size_t i;

	if(string == NULL || 
		string_len < MD5_STRING_SIZE ||
		buffer == NULL ||
		buffer_len < MD5_SIGNATURE_SIZE)
		return -1;

	for(i = 0; i < MD5_SIGNATURE_SIZE; ++i)
	{
		unsigned int x;
		if(_snscanf(string + 2*i, 2, "%02x", &x) <= 0)
			break;
		buffer[i] = (unsigned char)x;
	}

	return (int)i;
}

int MD5API string_to_md5U(const __wchar_t* string, size_t string_len, unsigned char* buffer, size_t buffer_len)
{
	size_t i;

	if(string == NULL || 
		string_len < MD5_STRING_SIZE ||
		buffer == NULL ||
		buffer_len < MD5_SIGNATURE_SIZE)
		return -1;

	for(i = 0; i < MD5_SIGNATURE_SIZE; ++i)
	{
		unsigned int x;
		if(_snwscanf(string + 2*i, 2, L"%02x", &x) <= 0)
			break;
		buffer[i] = (unsigned char)x;
	}

	return (int)i;
}

static int MD5API lock_disk_device(int fd)
{
#ifdef _WIN32
	unsigned long dwBytesReturned;

	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),            // handle to a volume
						FSCTL_LOCK_VOLUME,  // dwIoControlCode
						NULL,               // lpInBuffer
						0,                  // nInBufferSize
						NULL,               // lpOutBuffer
						0,                  // nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						0))                // OVERLAPPED structure
	{
		_RPT1(_CRT_WARN, "Failed to lock volume: Last Error = %ld\n", GetLastError());
		return 0;
	}
	return 1;
#else
	return 0;
#endif //_WIN32
}

static MD5API unlock_disk_device(int fd)
{
#ifdef _WIN32
	unsigned long dwBytesReturned;
	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),            // handle to a volume
						FSCTL_UNLOCK_VOLUME,  // dwIoControlCode
						NULL,               // lpInBuffer
						0,                  // nInBufferSize
						NULL,               // lpOutBuffer
						0,                  // nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						0))                // OVERLAPPED structure
	{
		_RPT1(_CRT_WARN, "Failed to unlock volume: Last Error = %ld\n", GetLastError());
		return 0;
	}
	return 1;
#else
	return 0;
#endif //_WIN32
}

static int MD5API lock_disk_file(int fd, __int64 _S, int* o_disk_device)
{
#ifdef _WIN32
	ULARGE_INTEGER _R;
	OVERLAPPED ov;
	
	_ASSERTE(o_disk_device != NULL);

	*o_disk_device = 0;

	memset(&ov, 0, sizeof(OVERLAPPED));
	_R.QuadPart = _S;

	if(!LockFileEx((HANDLE)_get_osfhandle(fd),
		           LOCKFILE_EXCLUSIVE_LOCK,
				   0UL,
				   _R.LowPart,
				   _R.HighPart,
				   &ov))
	{
		if(GetLastError() == ERROR_INVALID_FUNCTION) // dderror
			*o_disk_device = 1;

		_RPT1(_CRT_WARN, "Unable to lock file, Last Error = %ld\n", GetLastError());
		return 0;
	}

	return 1;
#else

	// The ANSI locking function does not support
	// large files.  You will get a compiler warning
	// to indicate this.  If your platform has large file
	// support, redefine _locking in generic.h
	return locking(fd, _LK_LOCK, _S);
#endif //
}

int MD5API unlock_disk_file(int fd, unsigned __int64 _S)
{
#ifdef _WIN32
	LARGE_INTEGER _R;
	OVERLAPPED ov;
	
	memset(&ov, 0, sizeof(OVERLAPPED));
	_R.QuadPart = _S;
	
	return UnlockFileEx((HANDLE)_get_osfhandle(fd),
				   0UL,
				   _R.LowPart,
				   _R.HighPart,
				   &ov);
#else
	// The ANSI _locking function does not support
	// large files.  You will get a compiler warning
	// to indicate this.  If your platform has large file
	// support, redefine _locking in generic.h
	return locking(fd, _LK_UNLCK, _S);
#endif //
}

static int MD5API lock_file(int fd, int* o_disk_device)
{
	struct stat _st;

	if(o_disk_device == 0)
		return 0;

	if(fstat(fd, &_st) < 0)
	{
#ifdef _WIN32
		if(GetFileType((HANDLE) _get_osfhandle(fd)) == FILE_TYPE_DISK &&
			GetLastError() == ERROR_INVALID_FUNCTION) // dderror

		{
			*o_disk_device = 1;
			return lock_disk_device(fd);
		}
		else
#endif //_WIN32
			return 0;
	}

	// if the file is not a regular file or device it can't be locked.
	if((_st.st_mode & S_IFREG) != S_IFREG)
		return 1;
	
#ifdef _WIN32
	if(!lock_disk_file(fd, _st.st_size, o_disk_device))
	{
		return 0;
	}
#else
	if(!lock_disk_file(fd, _st.st_size))
	{
		if(!*o_disk_device ||
			!lock_disk_device(fd))
			return 0;
	}
#endif //_WIN32
	
	return 1;
}

static int MD5API unlock_file(int fd, int o_disk_device)
{
	struct stat _st;

	if(fd < 0)
		return 0;

	if(o_disk_device)
	{
		if(!unlock_disk_device(fd))
			return 0;

		return 1;
	}


	if(fstat(fd, &_st) < 0)
		return 0;

	// if the file is not a regular file or device it can't be locked.
	if((_st.st_mode & S_IFREG) != S_IFREG)
		return 1;


	if(!unlock_disk_file(fd, _st.st_size))
		return 0;

	return 1;
}

int MD5API md5_file (const TCHAR *filename, int binary, unsigned char *md5_result, size_t result_len, int lock)
{
	FILE *fp;
	int o_disk_device = 0;

	int err, mode, bLocked = 0;

	if(_tcsnicmp(filename, _T("-"), 2) == 0)
    {
		fp = stdin;
#ifdef _WIN32
      /* If we need binary reads from a pipe or redirected stdin, we need
	 to switch it to BINARY mode here, since stdin is already open.  */
      if (binary)
		  mode = setmode(fileno (stdin), O_BINARY);
#endif
    }
  else
    {
		/* OPENOPTS is a macro.  It varies with the system.
		Some systems distinguish between internal and
		external text representations.  */

		fp = _tfopen (filename, OPENOPTS (binary));

	    if (fp == NULL)
		{
			_ftprintf (stderr, _T("%s: "), filename);
			fprintf (stderr, "%s\n", strerror(errno));
			return 1;
		}

		if(lock)
		{
			if(!lock_file(fileno(fp), &o_disk_device))
				return ERROR_LOCK_FAILED;

			bLocked = 1;
		}
    }

	err = md5_stream (fp, md5_result, result_len);

#ifdef _WIN32
	if (fp == stdin && binary)
		setmode(fileno(fp), mode);
#endif //_WIN32

	// The file gets unlocked when it is closed anyway, 
	// but this is still good style.
	if(bLocked)
		unlock_file(fileno(fp), o_disk_device);

	if (err)
	{
		_ftprintf (stderr, _T("%s: "), filename);
		fprintf (stderr, "%s\n", strerror(errno));
	   
		if(fp != stdin)
			fclose (fp);

		return 1;
    }
	
	fclose (fp);
	return 0;
}

int MD5API md5_gzfile (const TCHAR *filename, int binary, unsigned char *md5_result, size_t result_len, int lock)
{
	gzFile fp;
	int o_disk_device = 0;
	int err, bLocked = 0;

	if(binary != 1)
		return 1;

	if (_tcsnicmp(filename, _T("-"), 2) == 0)
	{
		int fd = dup(fileno(stdin));

#ifdef _WIN32
		
		/* If we need binary reads from a pipe or redirected stdin, we need
		to switch it to BINARY mode here, since stdin is already open.  */
		if (binary)
			setmode(fd, O_BINARY);
#endif
		fp = gzdopen(fd, OPENOPTS (binary));
	}
	else
	{
		/* OPENOPTS is a macro.  It varies with the system.
		Some systems distinguish between internal and
		external text representations.  */
		fp = gzopen (filename, OPENOPTS (binary));
		if (fp == (gzFile)0)
		{
			_ftprintf(stderr, _T("%s: %s\n"), filename, gzerror(fp, &err));
			return 1;
		}

		if(lock)
		{
			if(!gzlock(fp, LK_LOCK, -1) < 0)
				return ERROR_LOCK_FAILED;

			bLocked = 1;
		}

	}

	err = md5_gzstream (fp, md5_result, result_len);
	
	if (err)
	{
		_ftprintf(stderr, _T("%s: %s\n"), filename, gzerror(fp, &err));
		gzclose (fp);
		return 1;
	}
	
	// the lock gets released when the stream is closed.
	gzclose (fp);

	return 0;
}

int MD5API md5_parse_decompression_algorithm(const TCHAR* algorithm)
{
	if(algorithm == NULL ||
		algorithm[0] == _T('\0'))
		return MD5_DECOMPRESSION_ALGORITHM_DEFAULT;
	else if(_tcsnicmp(algorithm, _T("zlib"), 5) == 0)
		return MD5_DECOMPRESSION_ALGORITHM_ZLIB;
	return MD5_DECOMPRESSION_ALGORITHM_UNSUPPORTED;
}

int MD5API md5_write_digest_entry(FILE* fp, const TCHAR* file, int binary, unsigned char* buffer, size_t buffer_len)
{
	int ret;
	size_t i, len;
	char cch[2];
	char szSig[MD5_STRING_SIZE + 3];
	char* p = szSig;

	/* Output a leading backslash if the file name contains
		 a newline or backslash.  */
	if (_tcschr (file, _T('\n')) || _tcschr (file, _T('\\')))
		*p++ = '\\';

	ret = md5_to_stringA(buffer, buffer_len, p, MD5_STRING_SIZE + 1);
	_ASSERTE(ret == MD5_STRING_SIZE);

	p += MD5_STRING_SIZE;

	*p++ = ' ';
	if (binary)
		*p++ = '*';
	else
		*p++ = ' ';

	fwrite(szSig, sizeof(char), MD5_STRING_SIZE + 3, fp);

	len = _tcslen (file);

	/* Translate each NEWLINE byte to the string, "\\n",
	 and each backslash to "\\\\".  */
	for (i = 0; i < len; ++i)
	{
		switch (file[i])
		{
		case _T('\n'):
			fputs ("\\n", fp);
			break;

		case _T('\\'):
			fputs ("\\\\", fp);
			break;

		default:
#ifdef _UNICODE
			wctomb(cch, file[i]);
#else
			cch[0] = file[i];
#endif //_UNICODE
			putc (cch[0], fp);
		}
	}
    putc ('\n', fp);
	fflush (fp);

	return 0;
}
