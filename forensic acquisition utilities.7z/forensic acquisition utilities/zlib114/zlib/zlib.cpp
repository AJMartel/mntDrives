#include <windows.h>
#include <crtdbg.h>

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
#ifdef _UNICODE
			_RPT0(_CRT_WARN, "Initializing zlibU.dll\n");
#else
			_RPT0(_CRT_WARN, "Initializing zlib.dll\n");
#endif //_UNICODE
			DisableThreadLibraryCalls((HMODULE)hModule);
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
	
    return TRUE;
}
