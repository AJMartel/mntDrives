// xmalloc.h

#ifndef __XMALLOC_H_
#define __XMALLOC_H_

#ifdef __cplusplus
extern "C"
#endif //__cplusplus

# include <stdlib.h>
#include <stddef.h>

VOID *fixup_null_alloc (size_t n);
VOID *xmalloc (size_t n);
VOID *xcalloc (size_t n, size_t s);
VOID *xrealloc (VOID *p, size_t n);
void xmalloc_initalize_memory_allocation();

#ifdef __cplusplus
}
#endif //__cplusplus

#endif // __XMALLOC_H_