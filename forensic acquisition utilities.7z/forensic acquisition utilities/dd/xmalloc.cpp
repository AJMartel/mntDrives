//xmalloc.cpp
/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

/* Written by George M. Garner Jr. 01/07/02*/

#if HAVE_CONFIG_H
# include <config.h>
#endif

#ifdef HAVE_NEW_HANDLER
#include <new.h>
#endif // HAVE_NEW_HANDLER


extern "C" {
#include "xmalloc.c"
#ifdef HAVE_NEW_HANDLER
typedef void (__cdecl * new_handler) ();
new_handler __cdecl xset_new_handler(new_handler);
int __cdecl xmalloc_set_new_mode(int);	

int handle_program_memory_depletion( size_t size )
{
	error (xmalloc_exit_failure, 0, _T("Memory exhausted"));

	// Tell new to stop allocation attempts.
   return 0;
}

void xmalloc_initalize_memory_allocation()
{
	_set_new_handler(handle_program_memory_depletion);
	_set_new_mode(1);
}
#else
void xmalloc_initalize_memory_allocation()
{
}
#endif //	HAVE_NEW_HANDLER	

} // extern "C"