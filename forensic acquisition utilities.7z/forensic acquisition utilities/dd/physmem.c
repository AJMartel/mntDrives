/*physmem.c*/

/* Adapted from the source originally published at http://www.sysinternals.com/files/physmem.zip
/* by George M. Garner Jr. 01/07/02*/

//8/17/2004 Fixed format of error message in handle_bad_memory_region.

#include <wtypes.h>
#include <tchar.h>
#include <stdlib.h>
#include <stddef.h>
#include <sys/types.h>
#include <stdio.h>
#include <io.h>
#include <errno.h>
#include <crtdbg.h>
#include <native.h>
#include "error.h"
#include "md5.h"
#include "zlib.h"

#define C_NOERROR     0x0400
#define C_COMPRESS    0x10000

extern size_t max_records;
extern _off_t seek_record;
extern TCHAR *input_file;
extern int output_fd;
extern TCHAR *output_file;
extern size_t output_blocksize;
extern TCHAR* md5_output_file;
extern int generate_md5sum;
extern size_t input_blocksize;
extern _off_t skip_records;
extern size_t r_full;
extern int conversions_mask;
extern gzFile gzfh;
extern size_t w_full;
extern int verify_md5;
extern int in_sparse;
extern long bCancelled;

char *xmalloc (size_t n);
void skip (int fdesc, TCHAR *file, _off_t records, size_t blocksize, unsigned char *buf);
int full_write (int desc, char *ptr, size_t len);
void system_error(long lerror);
int complete_sparse(int fd, size_t len);
void write_md5sum(unsigned char* buffer, size_t len, TCHAR* ifile, TCHAR* ofile, TCHAR* md5out);
void* interlocked_exchange_ptr(void* volatile* target, void* value);

int open_physical_memory();
void close_physical_memory();
void copy_memory (void);
static void display_physical_memory();
static unsigned __int64 physical_memory();
static void handle_bad_memory_region(LPVOID Start, LPVOID End);

static int initialized = 0;
static HANDLE hInputFile = INVALID_HANDLE_VALUE;

//
// Functions in NTDLL that we dynamically locate
//

NTUNMAPVIEWOFSECTION NtUnmapViewOfSection;
NTOPENSECTION NtOpenSection;
NTMAPVIEWOFSECTION NtMapViewOfSection;
RTLINITUNICODESTRING RtlInitUnicodeString;
RTLNTSTATUSTODOSERROR RtlNtStatusToDosError;

//--------------------------------------------------------
//
// LocateNtdllEntryPoints
//
// Finds the entry points for all the functions we 
// need within NTDLL.DLL.
//
//--------------------------------------------------------
int initialize_physmem()
{
	if( !(RtlInitUnicodeString = (RTLINITUNICODESTRING) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"), "RtlInitUnicodeString" )) ) 
		return 0;
	if( !(NtUnmapViewOfSection = (NTUNMAPVIEWOFSECTION) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"),	"NtUnmapViewOfSection" )) ) 
		return 0;
	if( !(NtOpenSection = (NTOPENSECTION) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"),	"NtOpenSection" )) ) 
		return 0;
	if( !(NtMapViewOfSection = (NTMAPVIEWOFSECTION) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"), "NtMapViewOfSection" )) ) 
		return 0;
	if( !(RtlNtStatusToDosError = (RTLNTSTATUSTODOSERROR) 
			GetProcAddress( GetModuleHandleW(L"ntdll.dll"),"RtlNtStatusToDosError" )) ) 
		return 0;
	return 1;
}

//--------------------------------------------------------
//
// OpensPhysicalMemory
//
// This function opens the physical memory device. It
// uses the native API since 
//
//--------------------------------------------------------
int open_physical_memory()
{
	NTSTATUS		status;
	HANDLE			hDevice = INVALID_HANDLE_VALUE;
	UNICODE_STRING	deviceString;
	OBJECT_ATTRIBUTES attributes;

	if(!initialized && !(initialized = initialize_physmem()))
		return 0;

	RtlInitUnicodeString( &deviceString, L"\\Device\\PhysicalMemory");	

	InitializeObjectAttributes( &attributes, &deviceString,
								OBJ_CASE_INSENSITIVE, NULL, NULL );			
	status = NtOpenSection( &hDevice, SECTION_MAP_READ, &attributes );

	if( !NT_SUCCESS( status )) 
	{
		//SetLastError(RtlNtStatusToDosError(status));
			if(status == STATUS_OBJECT_NAME_NOT_FOUND)
				errno = ENOENT;
			else if (status == STATUS_ACCESS_DENIED)
				errno = EACCES;
			else if (status == STATUS_INVALID_HANDLE)
				errno = EBADF;
			else if(status == STATUS_OBJECT_NAME_INVALID)
				errno = EINVAL;
			else if(status == STATUS_OBJECT_TYPE_MISMATCH)
				errno = EINVAL;

			return 0;
	}

	hInputFile = hDevice;

	return 1;
}


//--------------------------------------------------------
//
// MapPhysicalMemory
//
// Maps a view of a section.
//
//--------------------------------------------------------
LPVOID map_physical_memory(HANDLE hMem, LPVOID pMem, size_t offset, size_t nSize)
{
	if(hMem == INVALID_HANDLE_VALUE)
		return (LPVOID)0;

	if(pMem != (LPVOID) 0)
		UnmapViewOfFile(pMem);

	return MapViewOfFile(hMem,          // section handle
		                 FILE_MAP_READ, // desired access
						 0UL,
						 (unsigned long)offset,
						 nSize);
}

// Returns total physical memory in kilobytes
static unsigned __int64 physical_memory()
{
	MEMORYSTATUSEX ms;
	ms.dwLength = sizeof(MEMORYSTATUSEX);

	if(!GlobalMemoryStatusEx(&ms))
		return (unsigned __int64)0;

	return ms.ullTotalPhys/(unsigned __int64)1024;
}

static void display_physical_memory()
{
	DWORDLONG mem = physical_memory();

	_ftprintf(stderr, _T("Total physical memory reported: %I64d KB\n"), mem);
}

static void handle_bad_memory_region(LPVOID Start, LPVOID End)
{
	_ftprintf(stderr, _T("Physical memory in the range 0x%08lx-0x%08lx could not be read.\n"), Start, End);
}

void copy_memory (void)
{
	LPCVOID ibuf = (LPCVOID) 0;
	LPCVOID bufstart = (LPCVOID)0; /* Input buffer. */
	LPVOID BadStart = NULL;
	LPVOID BadLast = NULL;
	BOOL bInBadRegion = FALSE;
	int exit_status = 0;
	int nwritten = 0;
	unsigned int count = 0;
	long lError = ERROR_SUCCESS;
	unsigned char md5buffer[MD5_SIGNATURE_SIZE];
	unsigned char* obuf = (unsigned char*) 0;
	PMD5CTX md5_ctx = (PMD5CTX)0;

	if (max_records == 0)
		exit (exit_status);

	if (seek_record > 0)
		skip (output_fd, output_file, seek_record, output_blocksize, obuf);

  
	if(generate_md5sum)
	{
		md5_ctx = md5_alloc_ctx();
		md5_init_ctx(md5_ctx);
	}

	obuf = (unsigned char*) xmalloc(input_blocksize * sizeof(unsigned char));
	memset(obuf, 0, input_blocksize * sizeof(unsigned char));

	__try
	{
		display_physical_memory();

		_ftprintf(stderr, _T("Copying physical memory...\n"));

		SetLastError(lError);

		__try
		{
			while ((ibuf = map_physical_memory(hInputFile, ibuf, 
						(skip_records + r_full) * input_blocksize, input_blocksize)) != NULL || 
				((conversions_mask & C_NOERROR) && 
						(lError = GetLastError()) != ERROR_INVALID_PARAMETER))
			{
				
				// Control handler may not get scheduled without this.
				Sleep(0L); // added 8/17/2004
				
				if(bCancelled)
					__leave;

				if(ibuf != NULL)
				{
					if(bInBadRegion)
					{
						handle_bad_memory_region(BadStart, BadLast);
						bInBadRegion = FALSE;
					}

					memcpy(obuf, ibuf, input_blocksize * sizeof(unsigned char));
				}
				else if(lError == ERROR_INVALID_ADDRESS)
				{
					_ASSERTE(conversions_mask & C_NOERROR);
					// Unable to map this region.  
					// Record the start and end of the region and move on.
					
					BadLast = (LPVOID)((skip_records + r_full) * input_blocksize);
					if(!bInBadRegion)
					{
						BadStart = BadLast;
						bInBadRegion = TRUE;
					}
				}
				else
				{
					// Shouldn't reach here.
					_ASSERT(FALSE);
					break;
				}

				r_full++;

				if(bCancelled)
					__leave;

				if(generate_md5sum)
				{
					count++;
					_RPT2(_CRT_WARN, "\n%ld. Calling md5_process_bytes for %ld bytes\n", count, input_blocksize);
					md5_process_block(obuf, input_blocksize, md5_ctx);
				}

				if((conversions_mask & C_COMPRESS) == C_COMPRESS)
					nwritten = (unsigned int)gzwrite(gzfh, obuf, input_blocksize);
				else
					nwritten = full_write (output_fd, obuf, input_blocksize);

				if (nwritten < 0)
				{
					error (0, errno, _T("%s"), output_file);
					break;
				}
				else
				{
					w_full++;
				}

				if (max_records >= 0 && r_full >= max_records)
					break;

				memset(obuf, 0, input_blocksize * sizeof(unsigned char));		
				SetLastError(ERROR_SUCCESS);
			}
			
			if(bInBadRegion)
			{
				handle_bad_memory_region(BadStart, BadLast);
				bInBadRegion = FALSE;
			}
			
			error(0,0, _T("Stopped reading physical memory: \n\t"));
			system_error(GetLastError());
		}
		__except(1)
		{
			error(0, 0, _T("Reading from memory at 0xlx generated exception %0xlx\n"), ibuf, GetExceptionCode());
		}

		if(bCancelled)
			__leave;

		if(generate_md5sum)
		{
			unsigned char md5buffer2[MD5_SIGNATURE_SIZE + 1];

			if(md5_finish_ctx (md5_ctx, md5buffer, MD5_SIGNATURE_SIZE) != NULL)
			{
				write_md5sum(md5buffer, MD5_SIGNATURE_SIZE, input_file, output_file, md5_output_file);
				write_md5sum(md5buffer, MD5_SIGNATURE_SIZE, input_file, output_file, _T("standard output"));
			}

			if(verify_md5)
			{
				if(bCancelled)
					__leave;

				if(in_sparse)
					complete_sparse(output_fd, 0);
				
				_ftprintf(stderr, _T("\nVerifying output file...\n"));

				if((conversions_mask & C_COMPRESS) == C_COMPRESS)
				{
					_ASSERTE(output_fd == -1);					

					gzclose(gzfh);
					gzfh = (gzFile)0;

				}
				else
					_commit(output_fd);


				if(output_fd != -1 && 
					_lseeki64(output_fd, 0, SEEK_SET) < 0)
				{
					//non-seeking device
					_ftprintf(stderr, _T("Verification not supported on non-seeking device.\n"));
					error(0, errno, _T("Verification not supported on non-seeking device.\n"));
				}
				else 
				{
					if((conversions_mask & C_COMPRESS) == C_COMPRESS)
					{
						if(md5_gzfile(output_file, TRUE, md5buffer2, MD5_SIGNATURE_SIZE, 0) != 0)
						{
							error(1, 0, _T("verification of compressed output file failed"));
						}

					}
					else
					{
						_md5_stream(output_fd, md5buffer2, MD5_SIGNATURE_SIZE);
					}
					write_md5sum(md5buffer2, MD5_SIGNATURE_SIZE, output_file, output_file, _T("standard output"));
				}
				_ftprintf(stderr, _T("The checksums %s match.\n"), 
					is_equal_md5(md5buffer, MD5_SIGNATURE_SIZE, md5buffer2, MD5_SIGNATURE_SIZE)? _T("do") : _T("do NOT"));

			}
		}

		if(bCancelled)
			__leave;

		system_error(GetLastError()); 

		if(in_sparse)
			complete_sparse(output_fd, 0);
		
	}
	__finally
	{
		if(obuf != (unsigned char*)0)
			free(obuf);
		if(md5_ctx != (PMD5CTX)0)
			md5_free_ctx(md5_ctx);

	}
}

void close_physical_memory()
{
	LPVOID to_free = interlocked_exchange_ptr(&hInputFile, INVALID_HANDLE_VALUE);
	if(to_free != INVALID_HANDLE_VALUE)
		CloseHandle(to_free);
}