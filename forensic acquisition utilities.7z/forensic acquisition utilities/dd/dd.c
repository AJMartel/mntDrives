/* dd -- convert a file while copying it.
   Copyright (C) 85, 90, 91, 95, 1996 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

/* Originally written by Paul Rubin, David MacKenzie, and Stuart Kemp. */

/* Modified from the original by George M. Garner Jr. 01/07/02*/

/* Options:

   Numbers can be followed by a multiplier:
   b=512, c=1, k=1024, w=2, xm=number m

   if=FILE			Read from FILE instead of stdin.
   of=FILE			Write to FILE instead of stdout; don't
				truncate FILE.
   ibs=BYTES			Read BYTES bytes at a time.
   obs=BYTES			Write BYTES bytes at a time.
   bs=BYTES			Override ibs and obs.
   cbs=BYTES			Convert BYTES bytes at a time.
   skip=BLOCKS			Skip BLOCKS ibs-sized blocks at
				start of input.
   seek=BLOCKS			Skip BLOCKS obs-sized blocks at
				start of output.
   count=BLOCKS			Copy only BLOCKS input blocks.
   conv=CONVERSION[,CONVERSION...]

   Conversions:
   ascii			Convert EBCDIC to ASCII.
   ebcdic			Convert ASCII to EBCDIC.
   ibm				Convert ASCII to alternate EBCDIC.
   block			Pad newline-terminated records to size of
				    cbs, replacing newline with trailing spaces.
   unblock			Replace trailing spaces in cbs-sized block
				    with newline.
   lcase			Change upper case characters to lower case.
   ucase			Change lower case characters to upper case.
   swab				Swap every pair of input bytes.
				    Unlike the Unix dd, this works when an odd
				    number of bytes are read.
   noerror			Continue after read errors.
   sync				Pad every input block to size of ibs with
				    trailing NULs. 
   comp             Compress output
   decomp           Decompress input*/

/*01/08/02 - Set STDOUT to binary mode when piping to suppress character
             translation that corrupted data stream*/

#include <config.h>

#include <stdio.h>
#ifdef NEEDS_IO_H
#include <io.h>
#endif 

// The input buffer needs to be sector aligned when reading from some physical 
// devices.  Not all devices enforce this restriction but some do (e.g. firewire drives). 
// The SWAB_ALIGN_OFFSET is used for conversions that are no longer supported and
// will throw the input buffer out of alignment.
#define SWAB_ALIGN_OFFSET 0

#include <sys/types.h>
#include <sys/locking.h>
#include <signal.h>
#include <getopt.h>

#include "system.h"

#include "error.h"
#include "md5.h"
#include "zlib.h"
#include <WinCred.h> // added 8/17/2004

#define equal(p, q, c) (_tcsncmp ((p),(q),(c)) == 0)

#ifndef max
#define max(a, b) ((a) > (b) ? (a) : (b))
#endif 

/* Default input and output blocksize. */
#define DEFAULT_BLOCKSIZE 4096

/* Conversions bit masks. */
#ifdef SUPPORT_CONVERSIONS
#define C_ASCII       0x01
#define C_EBCDIC      0x02
#define C_IBM         0x04
#define C_BLOCK       0x010
#define C_UNBLOCK     0x020
#define C_LCASE       0x040
#define C_UCASE       0x0100
#define C_SWAB        0x0200
#define C_NOTRUNC     0x01000
#define C_SYNC        0x02000
#endif //SUPPORT_CONVERSIONS
#define C_NOERROR     0x0400
/* Use separate input and output buffers, and combine partial input blocks. */
#define C_TWOBUFS     0x04000
#define C_COMPRESS    0x10000
#define C_DECOMPRESS  0x20000 

char *xmalloc (size_t n);
int safe_read (int desc, char* ptr, size_t len);
int full_write (int desc, char *ptr, size_t len);

#ifdef HAVE_NEW_HANDLER
int handle_program_memory_depletion( size_t size );
#endif //HAVE_NEW_HANDLER

void* interlocked_exchange_ptr(void* volatile* target, void* value);
int interlocked_exchange(int volatile* target, int value);

static RETSIGTYPE interrupt_handler __P ((int));
static int bit_count __P ((register unsigned int i));
static int parse_integer __P ((char *str));
static void apply_translations __P ((void));
static void copy_file __P ((void));
static void copy_simple __P ((unsigned char *buf, size_t nread, unsigned char* obuf));
static void copy_with_block __P ((unsigned char *buf, size_t nread, unsigned char* obuf));
static void copy_with_unblock __P ((unsigned char *buf, size_t nread, unsigned char* obuf));
static void parse_conversion __P ((TCHAR *str));
static void print_stats __P ((void));
static void translate_charset __P ((const unsigned char *new_trans));
static void scanargs __P ((int argc, char **argv));
static void validate_input __P ((void));
void skip __P ((int fdesc, TCHAR *file, _off_t records,
		       size_t blocksize, unsigned char *buf));
static void usage __P ((int status));
static void write_output __P ((char* _obuf));
static void banner __P ((void));
static void cleanup (void);

#ifdef HAVE_NEW_HANDLER
void xmalloc_initalize_memory_allocation(void);
#endif //HAVE_NEW_HANDLER
extern int o_disk_device[];
extern int o_disk_file[];
extern int o_physical_drive[];
extern __int64 _DriveSize; 
int o_supports_compression = FALSE;

int is_disk_device(int fd, const TCHAR* file, unsigned int which);
int is_disk_writable(int fd); // 8/17/2004
int display_device_info(int fd, const TCHAR* file, unsigned int which);

#define INPUT_FILE 0
#define OUTPUT_FILE 1

int o_lock[2] = {0, 0};
int lock_file(int fd, __int64 size, unsigned int which);
int unlock_file(int fd, __int64 size, unsigned int which);
int dismount_device(int fd, unsigned int which);

#ifdef _WIN32
#include <windows.h>
#include <security.h>
int __stdcall control_handler ( unsigned long);
int open_physical_memory();
void close_physical_memory();
//LPVOID map_physical_memory(intptr_t hMem, LPCVOID pMem, size_T offset, size_t nSize);
void copy_memory(void);
void system_error(long lerror);
#if _WIN32_WINNT >= 0x0500
int create_process_as_user(int nArgs, wchar_t* thisApp);
#endif //_WIN32_WINNT >= 0x0500
#endif //_WIN32

/* The name this program was run with. */
TCHAR *program_name = (TCHAR*)0;

/* The name of the input file, or NULL for the standard input. */
TCHAR *input_file = NULL;

long bCancelled = 0;

/* The input file descriptor. */
int input_fd = -1;
gzFile gzfh = (gzFile)0;

/* The name of the output file, or NULL for the standard output. */
TCHAR *output_file = NULL;

TCHAR* md5_output_file = NULL;

TCHAR* log_file = NULL;

/* The output file descriptor. */
int output_fd = -1;

static int log_fd = -1;

static int old_stderr = -1;

static FILE* md5_output_fd = 0;

/* The number of bytes in which atomic reads are done. */
size_t input_blocksize = (size_t)-1;

/* The number of bytes in which atomic writes are done. */
size_t output_blocksize = (size_t) -1;

/* Conversion buffer size, in bytes.  0 prevents conversions. */
static size_t conversion_blocksize = 0;

/* Skip this many records of `input_blocksize' bytes before input. */
_off_t skip_records = 0;

/* Skip this many records of `output_blocksize' bytes before output. */
_off_t seek_record = 0;

/* Copy only this many records.  <0 means no limit. */
size_t max_records = (size_t)-1;

/* Bit vector of conversions to apply. */
int conversions_mask = 0;

/* If nonzero, filter characters through the translation table.  */
static int translation_needed = 0;

/* Current index into `obuf'. */
static size_t oc = 0;

/* Number of partial blocks written. */
static size_t w_partial = 0;

/* Number of full blocks written. */
size_t w_full = 0;

/* Number of partial blocks read. */
static size_t r_partial = 0;

/* Number of full blocks read. */
size_t r_full = 0;

/* Records truncated by conv=block. */
static size_t r_truncate = 0;

/* Generate a md5 checksum for copied data*/
int generate_md5sum = 0;
int verify_md5 = 0;

static const TCHAR myVersion[] = ZLIB_VERSION;

#ifdef _WIN32

static int input_physical_memory = 0;
//intptr_t hEvent = -1;

void init_sparse();
BOOL file_system_supports(const TCHAR* _Path, unsigned long dwMask);
BOOL set_sparse(int fd);
BOOL is_sparse(int fd);
int complete_sparse(int fd, size_t len);
int o_sparse = FALSE;
extern BOOL in_sparse;
#define INVALID_SECTOR_SIZE -1
#endif //_WIN32

/* Output representation of newline and space characters.
   They change if we're converting to EBCDIC.  */
static char newline_character = '\n';
static char space_character = ' ';

struct conversion
{
  TCHAR *convname;
  int conversion;
};

static struct conversion conversions[] =
{
#ifdef SUPPORT_CONVERSIONS
  {_T("ascii"), C_ASCII | C_TWOBUFS},	/* EBCDIC to ASCII. */
  {_T("ebcdic"), C_EBCDIC | C_TWOBUFS},	/* ASCII to EBCDIC. */
  {_T("ibm"), C_IBM | C_TWOBUFS},	/* Slightly different ASCII to EBCDIC. */
  {_T("block"), C_BLOCK | C_TWOBUFS},	/* Variable to fixed length records. */
  {_T("unblock"), C_UNBLOCK | C_TWOBUFS},	/* Fixed to variable length records. */
  {_T("lcase"), C_LCASE | C_TWOBUFS},	/* Translate upper to lower case. */
  {_T("ucase"), C_UCASE | C_TWOBUFS},	/* Translate lower to upper case. */
  {_T("swab"), C_SWAB | C_TWOBUFS},	/* Swap bytes of input. */
  {_T("notrunc"), C_NOTRUNC},	/* Do not truncate output file. */
  {_T("sync"), C_SYNC},		/* Pad input records to ibs with NULs. */
#endif //SUPPORT_CONVERSIONS
  {_T("noerror"), C_NOERROR},	/* Ignore i/o errors. */
  {_T("comp"), C_COMPRESS},  /*Compress the output*/
  {_T("decomp"), C_DECOMPRESS},  /*Decompress the input*/
  {NULL, 0}
};

/* Translation table formed by applying successive transformations. */
static unsigned char trans_table[256];

static unsigned char const ascii_to_ebcdic[] =
{
  0, 01, 02, 03, 067, 055, 056, 057,
  026, 05, 045, 013, 014, 015, 016, 017,
  020, 021, 022, 023, 074, 075, 062, 046,
  030, 031, 077, 047, 034, 035, 036, 037,
  0100, 0117, 0177, 0173, 0133, 0154, 0120, 0175,
  0115, 0135, 0134, 0116, 0153, 0140, 0113, 0141,
  0360, 0361, 0362, 0363, 0364, 0365, 0366, 0367,
  0370, 0371, 0172, 0136, 0114, 0176, 0156, 0157,
  0174, 0301, 0302, 0303, 0304, 0305, 0306, 0307,
  0310, 0311, 0321, 0322, 0323, 0324, 0325, 0326,
  0327, 0330, 0331, 0342, 0343, 0344, 0345, 0346,
  0347, 0350, 0351, 0112, 0340, 0132, 0137, 0155,
  0171, 0201, 0202, 0203, 0204, 0205, 0206, 0207,
  0210, 0211, 0221, 0222, 0223, 0224, 0225, 0226,
  0227, 0230, 0231, 0242, 0243, 0244, 0245, 0246,
  0247, 0250, 0251, 0300, 0152, 0320, 0241, 07,
  040, 041, 042, 043, 044, 025, 06, 027,
  050, 051, 052, 053, 054, 011, 012, 033,
  060, 061, 032, 063, 064, 065, 066, 010,
  070, 071, 072, 073, 04, 024, 076, 0341,
  0101, 0102, 0103, 0104, 0105, 0106, 0107, 0110,
  0111, 0121, 0122, 0123, 0124, 0125, 0126, 0127,
  0130, 0131, 0142, 0143, 0144, 0145, 0146, 0147,
  0150, 0151, 0160, 0161, 0162, 0163, 0164, 0165,
  0166, 0167, 0170, 0200, 0212, 0213, 0214, 0215,
  0216, 0217, 0220, 0232, 0233, 0234, 0235, 0236,
  0237, 0240, 0252, 0253, 0254, 0255, 0256, 0257,
  0260, 0261, 0262, 0263, 0264, 0265, 0266, 0267,
  0270, 0271, 0272, 0273, 0274, 0275, 0276, 0277,
  0312, 0313, 0314, 0315, 0316, 0317, 0332, 0333,
  0334, 0335, 0336, 0337, 0352, 0353, 0354, 0355,
  0356, 0357, 0372, 0373, 0374, 0375, 0376, 0377
};

static unsigned char const ascii_to_ibm[] =
{
  0, 01, 02, 03, 067, 055, 056, 057,
  026, 05, 045, 013, 014, 015, 016, 017,
  020, 021, 022, 023, 074, 075, 062, 046,
  030, 031, 077, 047, 034, 035, 036, 037,
  0100, 0132, 0177, 0173, 0133, 0154, 0120, 0175,
  0115, 0135, 0134, 0116, 0153, 0140, 0113, 0141,
  0360, 0361, 0362, 0363, 0364, 0365, 0366, 0367,
  0370, 0371, 0172, 0136, 0114, 0176, 0156, 0157,
  0174, 0301, 0302, 0303, 0304, 0305, 0306, 0307,
  0310, 0311, 0321, 0322, 0323, 0324, 0325, 0326,
  0327, 0330, 0331, 0342, 0343, 0344, 0345, 0346,
  0347, 0350, 0351, 0255, 0340, 0275, 0137, 0155,
  0171, 0201, 0202, 0203, 0204, 0205, 0206, 0207,
  0210, 0211, 0221, 0222, 0223, 0224, 0225, 0226,
  0227, 0230, 0231, 0242, 0243, 0244, 0245, 0246,
  0247, 0250, 0251, 0300, 0117, 0320, 0241, 07,
  040, 041, 042, 043, 044, 025, 06, 027,
  050, 051, 052, 053, 054, 011, 012, 033,
  060, 061, 032, 063, 064, 065, 066, 010,
  070, 071, 072, 073, 04, 024, 076, 0341,
  0101, 0102, 0103, 0104, 0105, 0106, 0107, 0110,
  0111, 0121, 0122, 0123, 0124, 0125, 0126, 0127,
  0130, 0131, 0142, 0143, 0144, 0145, 0146, 0147,
  0150, 0151, 0160, 0161, 0162, 0163, 0164, 0165,
  0166, 0167, 0170, 0200, 0212, 0213, 0214, 0215,
  0216, 0217, 0220, 0232, 0233, 0234, 0235, 0236,
  0237, 0240, 0252, 0253, 0254, 0255, 0256, 0257,
  0260, 0261, 0262, 0263, 0264, 0265, 0266, 0267,
  0270, 0271, 0272, 0273, 0274, 0275, 0276, 0277,
  0312, 0313, 0314, 0315, 0316, 0317, 0332, 0333,
  0334, 0335, 0336, 0337, 0352, 0353, 0354, 0355,
  0356, 0357, 0372, 0373, 0374, 0375, 0376, 0377
};

static unsigned char const ebcdic_to_ascii[] =
{
  0, 01, 02, 03, 0234, 011, 0206, 0177,
  0227, 0215, 0216, 013, 014, 015, 016, 017,
  020, 021, 022, 023, 0235, 0205, 010, 0207,
  030, 031, 0222, 0217, 034, 035, 036, 037,
  0200, 0201, 0202, 0203, 0204, 012, 027, 033,
  0210, 0211, 0212, 0213, 0214, 05, 06, 07,
  0220, 0221, 026, 0223, 0224, 0225, 0226, 04,
  0230, 0231, 0232, 0233, 024, 025, 0236, 032,
  040, 0240, 0241, 0242, 0243, 0244, 0245, 0246,
  0247, 0250, 0133, 056, 074, 050, 053, 041,
  046, 0251, 0252, 0253, 0254, 0255, 0256, 0257,
  0260, 0261, 0135, 044, 052, 051, 073, 0136,
  055, 057, 0262, 0263, 0264, 0265, 0266, 0267,
  0270, 0271, 0174, 054, 045, 0137, 076, 077,
  0272, 0273, 0274, 0275, 0276, 0277, 0300, 0301,
  0302, 0140, 072, 043, 0100, 047, 075, 042,
  0303, 0141, 0142, 0143, 0144, 0145, 0146, 0147,
  0150, 0151, 0304, 0305, 0306, 0307, 0310, 0311,
  0312, 0152, 0153, 0154, 0155, 0156, 0157, 0160,
  0161, 0162, 0313, 0314, 0315, 0316, 0317, 0320,
  0321, 0176, 0163, 0164, 0165, 0166, 0167, 0170,
  0171, 0172, 0322, 0323, 0324, 0325, 0326, 0327,
  0330, 0331, 0332, 0333, 0334, 0335, 0336, 0337,
  0340, 0341, 0342, 0343, 0344, 0345, 0346, 0347,
  0173, 0101, 0102, 0103, 0104, 0105, 0106, 0107,
  0110, 0111, 0350, 0351, 0352, 0353, 0354, 0355,
  0175, 0112, 0113, 0114, 0115, 0116, 0117, 0120,
  0121, 0122, 0356, 0357, 0360, 0361, 0362, 0363,
  0134, 0237, 0123, 0124, 0125, 0126, 0127, 0130,
  0131, 0132, 0364, 0365, 0366, 0367, 0370, 0371,
  060, 061, 062, 063, 064, 065, 066, 067,
  070, 071, 0372, 0373, 0374, 0375, 0376, 0377
};

/* If nonzero, display usage information and exit.  */
static int show_help;

/* If nonzero, print the version on standard output and exit.  */
static int show_version;

static void output_char(unsigned char c, unsigned char* buf)
{
	buf[oc++] = (c); 

	if (oc >= output_blocksize) 
		write_output (buf); 
}

TCHAR* computer_name(COMPUTER_NAME_FORMAT NameType)
{
	TCHAR* pszName;
	long lError;
	unsigned long dwSize = 0UL;

	if(GetComputerNameEx(NameType, NULL, &dwSize) ||
		(lError = GetLastError()) != ERROR_MORE_DATA)
		return NULL;

	pszName = (TCHAR*) xmalloc((dwSize + 1) * sizeof(TCHAR));

	if(!GetComputerNameEx(NameType, pszName, &dwSize))
	{
		_RPT1(_CRT_WARN, "Failed to get computer name: Last Error = %ld\n", GetLastError());
		free(pszName);
		pszName = NULL;
	}
	return pszName;
}

TCHAR* full_path(const TCHAR* lpszPath)
{
	size_t count = _MAX_PATH;
	TCHAR* path = (TCHAR*)0;
#ifdef 	_WIN32
	size_t count2;
#endif // _WIN32

	if(lpszPath == NULL ||
		lpszPath[0] == _T('\0'))
		return (TCHAR*)0;

#ifdef 	_WIN32
	count = GetFullPathName(lpszPath, 0UL, 0, 0);
	
	// On Windows 2000 GetFullPathName() returns less than the
	// required buffer size if NULL is specified for the output buffer
	// and lpszPath points to a device or volume (e.g. "\\.\C:").  The 
	// required buffer size will always be at least as big as the length
	// of the lpszPath argument. Windows XP always returns the correct 
	// buffer size and the following line is not required if only Windows
	// XP is targeted.
	count = max(count, _tcslen(lpszPath));

	if(count == 0)
	{
		error(0, 0, _T("GetFullPathName failed for path %s: Error = %ld"), lpszPath, GetLastError());
		return (TCHAR*)0;
	}	
	
	path = (TCHAR*) xmalloc(++count * sizeof(TCHAR));
	
	count2 = GetFullPathName(lpszPath, (unsigned long)count, path, 0);
	_ASSERTE(count2 < count);
	_ASSERTE(_CrtCheckMemory());

	if(count2 == 0UL)
	{
		free(path);
		error(0, 0, _T("GetFullPathName failed for path %s: Error = %ld"), lpszPath, GetLastError());
		return (TCHAR*)0;
	}
#else
	path = xmalloc(count * sizeof(TCHAR));

	if(_tfullpath(path, lpszPath, MAX_PATH) == NULL)
	{
		free(path);
		return (TCHAR*)0;
	}
#endif //_WIN32
	return path;
}

TCHAR* module_path(const TCHAR* lpszPath)
{
#ifdef _WIN32
	unsigned int i = 0;
	unsigned long dwSize;

	TCHAR * lpszFullPath = (TCHAR*) 0;

	// Unfortunately there is no way to size the module file name
	// other than trial and error.  Increase the path buffer in
	// _MAX_PATH increments.

	do
	{
		
		dwSize = (_MAX_PATH * sizeof(TCHAR) * ++i);

		if(lpszFullPath != NULL)
			free(lpszFullPath);

		lpszFullPath = (TCHAR*) xmalloc((dwSize + 2) * sizeof(TCHAR));
		 
	} while(GetModuleFileName(NULL, lpszFullPath, dwSize) == 0UL);

	return lpszFullPath;
#else
	return full_path(lpszPath);
#endif //_WIN32
}

#ifdef _WIN32

#define BIG_BUFFER_SIZE 1024

void display_system_time()
{
	unsigned long dwResult;
	SYSTEMTIME now;
	TIME_ZONE_INFORMATION ti;
	SYSTEMTIME local;

	GetSystemTime(&now);

	_ftprintf(stderr, L"\n%02d/%02d/%d  %02d:%02d:%02d (UTC)\n",
		    now.wDay, now.wMonth, now.wYear,
			now.wHour, now.wMinute, now.wSecond);

	dwResult = GetTimeZoneInformation(&ti);
	
	if(dwResult == TIME_ZONE_ID_INVALID ||
		dwResult == TIME_ZONE_ID_UNKNOWN)
		return;
	
	if(!SystemTimeToTzSpecificLocalTime(&ti, &now, &local))
		return;

	_ftprintf(stderr, L"%02d/%02d/%d  %02d:%02d:%02d (local time)\n\n",
		    local.wDay, local.wMonth, local.wYear,
			local.wHour, local.wMinute, local.wSecond);

}

int display_os_version()
{
	OSVERSIONINFOEX osvi;

	// Try calling GetVersionEx using the OSVERSIONINFOEX structure.
	//
	// If that fails, try using the OSVERSIONINFO structure.

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);

	if(!GetVersionEx ((OSVERSIONINFO *) &osvi))
		return FALSE;

	switch (osvi.dwPlatformId)
	{
	case VER_PLATFORM_WIN32_NT:
		_ftprintf(stderr, _T("Microsoft Windows: Version %ld.%ld (Build %ld."), 
				osvi.dwMajorVersion, osvi.dwMinorVersion, (osvi.dwBuildNumber & 0xFFFF));
		
		if ( osvi.wProductType == VER_NT_WORKSTATION )
		{
			if( osvi.wSuiteMask & VER_SUITE_PERSONAL )
				_ftprintf(stderr, _T("Personal"));
			else
				_ftprintf(stderr, _T("Professional"));
		}

		else if ( osvi.wProductType == VER_NT_SERVER )
		{
		   if( osvi.wSuiteMask & VER_SUITE_DATACENTER )
			  _ftprintf(stderr, _T("DataCenter"));
		   else if( osvi.wSuiteMask & VER_SUITE_ENTERPRISE )
			  _ftprintf(stderr, _T("Advanced Server"));
		   else
			  _ftprintf(stderr, _T("Server"));
		}
		if(osvi.szCSDVersion[0] != L'\0')
			_ftprintf(stderr, _T(" %s"), osvi.szCSDVersion);

		_ftprintf(stderr, _T(")\n"));
        break;
	default:
		;

   }

   return TRUE; 
}

BOOL display_current_user(EXTENDED_NAME_FORMAT NameFormat)
{
	long lError;
	unsigned long dwSize = 0UL;
	TCHAR* pszName;

	if(GetUserNameEx(NameFormat, 
		              NULL,
					  &dwSize) ||
		(lError = GetLastError()) != ERROR_MORE_DATA)
	{
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return FALSE;
	}

	pszName = (TCHAR*)_alloca(dwSize * sizeof(TCHAR));

	if(!GetUserNameEx(NameFormat, 
		              pszName,
					  &dwSize))
	{
		lError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to get current user name! Last Error = %ld\n", lError);
		return FALSE;
	}

	_ftprintf(stderr, _T("Current User: %s\n\n"), pszName);
	return TRUE;
}

void banner()
{
	unsigned long dwHandle;
	unsigned char* pbData;
	unsigned long dwSize = GetFileVersionInfoSize(program_name, &dwHandle);
	wchar_t* lpszFileDescription;
	wchar_t* lpszProductVersion;
	wchar_t* lpszLegalCopyright;
	wchar_t* lpszProductName;
	wchar_t* lpszFileVersion;
	TCHAR* lpszComment;

	unsigned int nSize;

	if(dwSize == 0UL)
		return;

	pbData = (unsigned char*)_alloca(dwSize * sizeof(unsigned char));
	if(!GetFileVersionInfo(program_name, dwHandle, dwSize, pbData))
	{
		_ASSERT(FALSE);
		return;
	}

	if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileDescription", 
					  (void**)&lpszFileDescription, 
					  &nSize))
	{
		_ASSERT(FALSE);
		return;
	}

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductVersion", 
					  (void**)&lpszProductVersion, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }

    if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\ProductName", 
					  (void**)&lpszProductName, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }


     if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\FileVersion", 
					  (void**)&lpszFileVersion, 
					  &nSize))
	 {
		_ASSERT(FALSE);
		 return;
	 }

	 if(!VerQueryValue(pbData, 
		              L"\\StringFileInfo\\040904B0\\LegalCopyright", 
					  (void**)&lpszLegalCopyright, 
					  &nSize))
	  {
		 _ASSERT(FALSE);
		  return;
	  }

	 if(!VerQueryValue(pbData, 
		              _T("\\StringFileInfo\\040904B0\\Comments"), 
					  (void**)&lpszComment, 
					  &nSize))
	  {
		 _ASSERT(FALSE);
		  return;
	  }
	_ftprintf(stderr, _T("%s, %s\n"), lpszProductName, lpszProductVersion);
	_ftprintf(stderr, _T("%s, %s\n"), lpszFileDescription, lpszFileVersion);
	_ftprintf(stderr, _T("%s\n\n"), lpszLegalCopyright);
	_ftprintf(stderr, _T("Command Line: %s\n"), GetCommandLine());
	_ftprintf(stderr, lpszComment);
	_ftprintf(stderr, _T("\n"));

	display_os_version();
	display_system_time();
	if(!display_current_user(NameCanonical))
		display_current_user(NameSamCompatible);

}

#else
void banner()
{
	if (show_version)
	{
	  _tprintf (_T("dd (%s) %s\n"), GNU_PACKAGE, VERSION);
	  exit (0);
	}
}
#endif //_WIN32

#ifdef _POSIX_VERSION
void initialize_signals(struct sigaction* sigact)
{
  sigaction (SIGINT, NULL, sigact);
  if (sigact.sa_handler != SIG_IGN)
    {
      sigact.sa_handler = interrupt_handler;
      sigemptyset (&sigact->sa_mask);
      sigact->sa_flags = 0;
      sigaction (SIGINT, sigact, NULL);
    }
  sigaction (SIGPIPE, NULL, sigact);
  if (sigact.sa_handler != SIG_IGN)
    {
      sigact.sa_handler = interrupt_handler;
      sigemptyset (&sigact->sa_mask);
      sigact->sa_flags = 0;
      sigaction (SIGPIPE, sigact, NULL);
    }
#else				/* !_POSIX_VERSION */
void initialize_signals()
{
  if (signal (SIGINT, SIG_IGN) != SIG_IGN)
    signal (SIGINT, interrupt_handler);
#ifdef HAS_SIGPIPE
  if (signal (SIGPIPE, SIG_IGN) != SIG_IGN)
    signal (SIGPIPE, interrupt_handler);
#endif //HAS_SIGPIPE
#endif				/* !_POSIX_VERSION */

#ifdef _WIN32
  SetConsoleCtrlHandler(control_handler, 1 );
  SetConsoleCtrlHandler(NULL, FALSE );  // added 8/17/2004
#endif //_WIN32
	
}

void write_md5sum_fname(FILE* fd, TCHAR* file)
{
	unsigned int i;

	char cch[2];
	
	for (i = 0; i < _tcslen (file); ++i)
	{
		switch (file[i])
		{
			case _T('\n'):
				fputs ("\\n", fd);
				break;

			case _T('\\'):
				fputs ("\\\\", fd);
			break;

			default:
#ifdef _UNICODE
				wctomb(cch, file[i]);
#else
				cch[0] = file[i];
#endif //_UNICODE
				putc (cch[0], fd);
				break;
		}
	}

}

void write_md5sum(unsigned char* buffer, size_t len, TCHAR* ifile, TCHAR* ofile, TCHAR* md5out)
{
//	  size_t i;
	  int ret;

	  char szSig[MD5_STRING_SIZE + 1];
		
	  if(_tcsncmp(md5out, _T("standard output"), 16) == 0)
		  md5_output_fd = stderr;
	  else if((md5_output_fd = _tfopen (md5out, _T("w"))) == 0)
	  {
		  error(0, errno, _T("Unable to open md5 output file %s"), md5_output_file);
		  md5_output_fd = stderr;
	  }
	  if(md5_output_fd != (FILE*)0 &&
		  md5_output_fd != stderr)
		  _tchmod(md5out, _S_IREAD);
		

	  /* Output a leading backslash if the file name contains
		 a newline or backslash.  */
	  if(_tcsncmp(ofile, _T("standard output"), 16) != 0)
	  {

	      if (_tcschr (ofile, _T('\n')) || _tcschr (ofile, _T('\\')))
				putc('\\', md5_output_fd);
	  }
	  else
	  {
	      if (_tcschr (ifile, _T('\n')) || _tcschr (ifile, _T('\\')))
				putc('\\', md5_output_fd);
	  }

  
	  //len = min(len, MD5_SIGNATURE_SIZE);

	  //for (i = 0; i < len; ++i)
		//fprintf (md5_output_fd, "%02x", buffer[i]);
		// putc (' ', md5_output_fd);	  
	  ret = md5_to_stringA(buffer, len, szSig, MD5_STRING_SIZE + 1);
	  _ASSERTE(ret == MD5_STRING_SIZE);
	  szSig[MD5_STRING_SIZE] = ' ';

	  fwrite(szSig, sizeof(char), MD5_STRING_SIZE + 1, md5_output_fd);

	  /* Translate each NEWLINE byte to the string, "\\n",
	 and each backslash to "\\\\".  */
	  if(_tcsncmp(ofile, _T("standard output"), 16) != 0)
	  {
			putc ('[', md5_output_fd);		  
			write_md5sum_fname(md5_output_fd, ifile);
			putc (']', md5_output_fd);		  
			putc (' ', md5_output_fd);		  
			putc('*', md5_output_fd);
			write_md5sum_fname(md5_output_fd, ofile);
	  }
		else
		{
			putc('*', md5_output_fd);
			write_md5sum_fname(md5_output_fd, ifile);
		}
	putc ('\n', md5_output_fd);

	if(md5_output_fd != (FILE*)0 && md5_output_fd != stderr)
	{
		fclose(md5_output_fd);
		md5_output_fd = (FILE*)0;
	}
	fflush(stderr);
}

int is_physical_memory_device(TCHAR* pinput_file)
{
   TCHAR drive[_MAX_DRIVE];
   TCHAR dir[_MAX_DIR];
   TCHAR fname[_MAX_FNAME];
   TCHAR ext[_MAX_EXT];

   if(pinput_file == 0)
	   return 0;

   _tsplitpath( pinput_file, drive, dir, fname, ext );

   if(drive[0] == _T('\0') &&
	   _tcsnicmp(dir, _T("\\\\.\\"), 4) == 0 &&
	   _tcsnicmp(fname, _T("PhysicalMemory"), 15) == 0 &&
	   ext[0] == _T('\0'))
	   return 1;
	return 0;
}

static unsigned long page_size()
{
#ifdef _WIN32
	SYSTEM_INFO si;
	GetSystemInfo(&si);
	return si.dwPageSize;
#else
	return DEFAULT_BLOCKSIZE;
#endif //_WIN32
}

static unsigned long allocation_granularity()
{
#ifdef _WIN32
	SYSTEM_INFO si;
	GetSystemInfo(&si);
	return si.dwAllocationGranularity;
#else
	return DEFAULT_BLOCKSIZE;
#endif //_WIN32
}

static int check_block_sizes()
{
	unsigned long dwSize = allocation_granularity();

  /*The algorithm assumes that the allocation granularity will be 64K
	for the purposes of generating md5 checksums*/
  _ASSERTE(dwSize == 64 * 1024);
	
	if((input_blocksize < 0) ||
		(input_blocksize <= dwSize &&  dwSize%input_blocksize != 0) ||
		(input_blocksize > dwSize &&  dwSize%input_blocksize != 0))
	{
		error(1, EINVAL, _T("Input block size must be a multiple of allocation granularity.\n \
\tThe input block size is %ld\n\tThe allocation granularity is %ld\n"), input_blocksize, dwSize);

		// not reached
		return 0;
	}

	if(output_blocksize != input_blocksize)
	{
		error(1, EINVAL, _T("Input block size must equal output block size.\n \
\tThe input block size is %ld\n\tThe pagefile size is %ld\n"), input_blocksize, dwSize);
		
		// not reached
		return 0;
	}
	return 1;
}

static int is_windows_xp()
{
	OSVERSIONINFOEX osvi;
    DWORDLONG dwlConditionMask = 0;

	memset(&osvi, 0, sizeof(OSVERSIONINFOEX));
	osvi.dwOSVersionInfoSize = sizeof(OSVERSIONINFOEX);
	osvi.dwMajorVersion = 5;
	osvi.dwMinorVersion = 1;

	// Initialize the condition mask.
	VER_SET_CONDITION(dwlConditionMask, VER_MAJORVERSION, 
	  VER_GREATER_EQUAL);
	VER_SET_CONDITION(dwlConditionMask, VER_MINORVERSION, 
	  VER_GREATER_EQUAL);

	// Perform the test.
	return VerifyVersionInfo(
	  &osvi, 
	  VER_MAJORVERSION | VER_MINORVERSION,
	  dwlConditionMask);
}

// Wrapper for WNetAddConnection2
static unsigned long add_connection(TCHAR* lpszTarget, const TCHAR* lpszUser, const TCHAR* lpszPassword)
{
	// Prompt the user for appropriate network credentials 	
	// Don't redirect a local resource (~CONNECT_REDIRECT)
	// Don't update user profile (~CONNECT_UPDATE_PROFILE)
	unsigned long dwFlags = CONNECT_INTERACTIVE | CONNECT_PROMPT;

	NETRESOURCE nr;
	memset(&nr, 0, sizeof(NETRESOURCE));

	//Presumably we will be connecting to a network drive (RESOURCETYPE_DISK),
	//But there is no reason (yet) why this function needs to be so limited.
	nr.dwType = RESOURCETYPE_ANY;
	nr.lpRemoteName = lpszTarget;

	if(is_windows_xp())
		dwFlags |= CONNECT_COMMANDLINE; // supported only on Windows XP

	//WNetAddConnection will handle this error, but we would like to know
	//about it in debug builds.
	_ASSERTE(lpszTarget != NULL);

	return WNetAddConnection2(&nr, lpszPassword, lpszUser, dwFlags);
}

// Remove the trailing '\' from the target path if it exists.
static TCHAR* terminate_trailing_slash(TCHAR* pszString)
{
	size_t nLen;
	if(pszString != NULL && (nLen = _tcslen(pszString)) > 1 &&
		pszString[--nLen] == _T('\\'))
		pszString[nLen] = _T('\0');
	return pszString;
}

static int cmdline_prompt_yes_or_no(const TCHAR* format, const TCHAR* lpszTarget)
{
	int ch, mode;
	int result = 1;

	_ASSERTE(lpszTarget != NULL);

	// fgets and fgetc do not work right with binary streams
	mode = setmode(fileno(stdin), _O_TEXT);

	__try
	{
		_ftprintf(stdout, format, lpszTarget);

		if(log_fd != -1)
			_ftprintf(stderr, format, lpszTarget);		

		fflush(stdin);
		if((ch = _fgettc(stdin)) == EOF ||
			(ch != _T('Y') && ch != _T('y')))
			result = 0;
		
		if(log_fd != -1)
			_ftprintf(stderr, _T("%c\n"), ch);
	}
	__finally
	{
		setmode(fileno(stdin), mode);
	}

	return result;
}

static int logon_user_with_new_network_credentials(const TCHAR* pszTarget)
{
	unsigned long dwResult;
	TCHAR szDrive[_MAX_DRIVE + 1];
	TCHAR szDIR[_MAX_DIR];

	// Guard against dereferencing null pointer or using empty
	// target string.  Check to see if stdin is a console before 
	// requesting input from the user.
	if(pszTarget == NULL || _tcsnicmp(pszTarget, L"\0", 1) == 0 ||
		GetFileType((HANDLE)_get_osfhandle(fileno(stdin))) != FILE_TYPE_CHAR)
		return 0;

	_tsplitpath(pszTarget, szDrive, szDIR, NULL,NULL);

	// If a local drive letter is specified then either the network 
	// drive already has been mapped to a local resource or we are not 
	// dealing with a remote resource.   
	if(szDrive[0] != _T('\0'))
	{
		_ASSERTE(szDrive[0] != _T('\0'));
		return 0;
	}
	
	// Find out if the user wants to attempt connecting to the remote resource
	if(!cmdline_prompt_yes_or_no(_T("Do you want to login to %s: [Y]es or [N]o?"), terminate_trailing_slash(szDIR)))
		return 0;
	

	if((dwResult=add_connection(szDIR, // target path
		                        NULL, // prompt for user name
								NULL  // prompt for password
								)) == NO_ERROR)
		return 1;
		
	system_error(dwResult);
	
	return 0;
}

static int do_file_open(const TCHAR* file, int mode, int pMode)
{
	int fd = -1;

	do {

		if(pMode != 0)
			fd = _topen(file, mode, pMode);
		else
			fd = _topen (file, mode);

	} while (fd < 0 && GetLastError() == ERROR_LOGON_FAILURE &&
		logon_user_with_new_network_credentials(file));

	return fd;
}

//modified 8/17/2004
// fixed secondary logon but now restricted
// to Windows XP or later (because it uses
// CredUIXXX api's
static void handle_input_fileopen_error(int nArgs)
{
	int err = errno;
#if defined(_UNICODE) && _WIN32_WINNT >= 0x0500 		  
	//if(errno == EACCES)
	//	create_process_as_user(nArgs, program_name);
	if(err == EACCES && nArgs > 0)
	{
		if(is_windows_xp() && 
			create_process_as_user(nArgs, program_name))
		return;
	}

#endif //_UNICODE
	error (1, err, _T("%s"), input_file);
}

static void initialize_input_file(int nArgs)
{
	if (input_file != NULL)
	{
		if(input_physical_memory)
		{
			check_block_sizes();
			if(!open_physical_memory())
				handle_input_fileopen_error(nArgs);

		}
		else
		{
			int oflag = O_BINARY | O_SEQUENTIAL;
			
			if(is_windows_xp() || 
				_tcsnicmp(input_file, _T("\\\\.\\PhysicalDrive"), 17) != 0)
				oflag |= O_RDONLY;
			else
				oflag |= O_RDWR;  //Windows 2000 needs write access to physical drives for IOCTL_SCSI_PASS_THROUGH_DIRECT
			                      //Note that requesting write access does not require that the application send a 
			                      //command that alters the drive.

			input_fd = do_file_open(input_file, oflag, 0);
			if(input_fd < 0)
				handle_input_fileopen_error(nArgs);

			if(is_disk_device(input_fd, input_file, INPUT_FILE))
				display_device_info(input_fd, input_file, INPUT_FILE);
			if(o_lock[INPUT_FILE])
			{
				if(lock_file(input_fd, (__int64) -1, INPUT_FILE))
					_ftprintf(stderr, _T("input file locked\n"));
				else
				{
					if(o_physical_drive[INPUT_FILE])
						error(1, 0, _T("Physical drive %s cannot be locked"), input_file);
					if(o_disk_device[INPUT_FILE] && 
						cmdline_prompt_yes_or_no(_T("The volume or drive %s could not be locked. ")
						                            _T("Do you want to dismount it? [Y]es or [N]o?"), input_file) &&
													cmdline_prompt_yes_or_no(_T("WARNING: ALL OPEN FILE HANDLES WILL BECOME INVALID!\n")
													_T("Are you sure you want to dismount %s? [Y]es or [N]o?"), input_file))
					{
						if(dismount_device(input_fd, INPUT_FILE)/* || 
							lock_file(input_fd, (__int64) -1, INPUT_FILE)*/)
							_ftprintf(stderr, _T("input volume dismounted\n"));
						else
						{
							if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), input_file))
							{
								o_lock[INPUT_FILE] = 0;
							}
							else
							{
								error(1, errno, _T("Unable to copy device"));
							}
						}

						// In theory (and according to MS documetation) 
						// dismounting a volume also locks the volume 
						// because it "disappears" from the system.  On 
						// Windows XP it works this way. But lets test the
						// assumption elsewhere.
						_ASSERTE(!lock_file(input_fd, (__int64) -1, INPUT_FILE));
					}
					else if(!o_disk_device[INPUT_FILE]) 
					{
						if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), input_file))
						{
							o_lock[INPUT_FILE] = 0;
						}
						else						{
							error(1, errno, _T("Unable to copy file"));
						}
					}
					
				}
			}
		}

    }
	else
	{
		size_t len = _tcslen(_T("CONIN$"));
		input_file = (TCHAR*)xmalloc((len + 1) * sizeof(TCHAR));
		_tcsncpy(input_file, _T("CONIN$"), len + 1);
		SET_BINARY_MODE(stdin);
		input_fd = fileno(stdin);
		
	}

	if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS && input_fd != -1)
	{
		if((gzfh = gzdopen(input_fd, _T("rb"))) != (gzFile)0)
		{
			input_fd = -1;
		}
		else
		{
			int err = errno;
			error(1, 0, gzerror(gzfh, &err));
		}
	}
}

static void initialize_output_file()
{
	if (output_file != NULL)
    {
		int omode = O_RDWR | O_BINARY | O_SEQUENTIAL;
		if(_tcsnicmp(output_file, _T("\\\\.\\"), 4) == 0)
			omode |= _O_EXCL;
		else
			omode |= O_CREAT;

#ifdef CONVERSIONS_SUPPORTED
		if (seek_record == 0 
			&& ((conversions_mask & C_NOTRUNC) == 0))
			omode |= O_TRUNC;
#endif //CONVERSIONS_SUPPORTED       
			
		output_fd = do_file_open(output_file, omode, S_IREAD);

		if (output_fd < 0)
		{
			_RPT1(_CRT_WARN, "Unable to open file:  Last Error = %ld\n", GetLastError());
			error (1, errno, _T("%s"), output_file);
		}
		else
		{
			if(is_disk_device(output_fd, output_file, OUTPUT_FILE))
			{
				display_device_info(output_fd, output_file, OUTPUT_FILE);
			
				if(!is_disk_writable(output_fd))
				{
					error(0, 0, _T("The output device is not writeable.\n"));
					return FALSE;
				}
				if(o_lock[OUTPUT_FILE])
				{
					if(lock_file(output_fd, (__int64) -1, OUTPUT_FILE))
						_ftprintf(stderr, _T("output file locked\n"));
					else
					{
						if(o_physical_drive[OUTPUT_FILE])
						{
							if(!cmdline_prompt_yes_or_no(_T("The physical drive %s could not be locked. ")
														_T("Do you want to dismount it? [Y]es or [N]o?"), output_file))
								error(1, 0, _T("Physical drive %s cannot be locked"), output_file);
						}
						if(o_disk_device[OUTPUT_FILE] && 
							cmdline_prompt_yes_or_no(_T("The volume or drive %s could not be locked. ")
														_T("Do you want to dismount it? [Y]es or [N]o?"), output_file) &&
														cmdline_prompt_yes_or_no(_T("WARNING: ALL OPEN FILE HANDLES WILL BECOME INVALID!\n")
														_T("Are you sure you want to dismount %s? [Y]es or [N]o?"), output_file))
						{
							if(dismount_device(output_fd, OUTPUT_FILE) /*|| 
								lock_file(output_fd, (__int64) -1, OUTPUT_FILE)*/)
								_ftprintf(stderr, _T("output file dismounted\n"));
							else
							{
								if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), output_file))
								{
									o_lock[OUTPUT_FILE] = 0;
								}
								else
								{
									error(1, errno, _T("Unable to copy to device"));
								}
							}
							// In theory (and according to MS documetation) 
							// dismounting a volume also locks the volume 
							// because it "disappears" from the system.  On 
							// Windows XP it works this way. But lets test the
							// assumption elsewhere.
							_ASSERTE(!lock_file(input_fd, (__int64) -1, OUTPUT_FILE));

						}
						else if(!o_disk_device[OUTPUT_FILE]) 
						{
							if(cmdline_prompt_yes_or_no(_T("%s could not be locked!\nDo you want to continue anyway? [Y]es or [N]o?"), output_file))
							{
								o_lock[OUTPUT_FILE] = 0;
							}
							else						{
								error(1, errno, _T("Unable to copy output file"));
							}
						}
					}
				}
			}
		}
#ifdef HAVE_FTRUNCATE
		if (seek_record > 0 && ((conversions_mask & C_NOTRUNC) == 0)
		{
			if (ftruncate (output_fd, seek_record * output_blocksize) < 0)
				error (0, errno, _T("%s"), output_file);
		}
#endif //HAVE_FTRUNCATE
#ifdef _WIN32
		if(o_sparse)
			o_sparse = file_system_supports(output_file, FILE_SUPPORTS_SPARSE_FILES | FS_FILE_COMPRESSION);

		o_supports_compression = file_system_supports(output_file, FS_FILE_COMPRESSION);

		if(o_sparse)
			o_sparse = set_sparse(output_fd);
		if(o_sparse)
		{
			_ftprintf(stderr, _T("output file set to sparse\n"));
			_ASSERTE(is_sparse(output_fd));
			_ASSERTE(output_blocksize != -1);
			init_sparse();
		}
#endif //_WIN32
    }
	else
	{
		size_t len = _tcslen(_T("CONOUT$"));
		output_file = (TCHAR*)xmalloc((len + 1) * sizeof(TCHAR));
		_tcsncpy(output_file, _T("CONOUT$"), len + 1);
		SET_BINARY_MODE(stdout);
		output_fd = fileno(stdout);
	}

	if((conversions_mask & C_COMPRESS) == C_COMPRESS && 
		output_fd != -1)
	{
		if((gzfh = gzdopen(output_fd, _T("wb"))) == (gzFile)0)
		{
			int err = errno;
			error(1, 0, gzerror(gzfh, &err));
		}
		else
			output_fd = -1;
	}
}

static void initialize_log_file()
{
	if (log_file != NULL)
    {
		int omode = O_RDWR | O_CREAT | O_SEQUENTIAL;
		log_fd = do_file_open(log_file, omode, S_IREAD);

		if (log_fd < 0)
		{
			_RPT1(_CRT_WARN, "Unable to open log file:  Last Error = %ld\n", GetLastError());
			error (1, errno, _T("%s"), log_file);
		}

		old_stderr = dup(fileno(stderr));
		if(dup2(log_fd, fileno(stderr)) < 0)
			error(1, errno, _T("Unable to dup2 stderr"));
	}
}

static void initialize_files(int nArgs)
{
	initialize_input_file(nArgs);
	initialize_output_file();
}

static void initialize_translation_table()
{
	int i;
	/* Initialize translation table to identity translation. */
	for (i = 0; i < 256; i++)
		trans_table[i] = i;
}

#ifdef _WIN32
int try_vanilla_copy()
{
	// If we are just doing a vanilla copy, the CopyFileEx
	// function is preferrable because it will always do the 
	// right thing re alternate streams encrypted files, and 
	// other NTFS specific stuff.  CopyFileEx does not support any
	// options and fails if the input file is something other than a
	// standard disk file.  
	if(input_file != (TCHAR*)0 &&
		!input_physical_memory &&
		output_file != (TCHAR*) 0 &&
		conversions_mask == 0 && 
		skip_records == 0 && seek_record == 0 &&
		generate_md5sum == 0 && verify_md5 == 0 &&
		max_records == -1 && 
		input_blocksize == output_blocksize &&
		input_blocksize == 4096 &&
		_tcsncmp(output_file, __T("\\\\.\\"), 4) != 0)
	{
		unsigned long dwFlags = 0UL;

		_ftprintf(stderr, _T("CopyFileEx %s to %s..."), input_file, output_file);
		
		if(is_windows_xp())
			dwFlags |= COPY_FILE_FAIL_IF_EXISTS;

		if(CopyFileEx(input_file,  // source
		           output_file, // destination
				   0,           // callback function
				   0,			// callback parameter
				   0,           // cancel status
				   dwFlags)) // Flags
		{
			_ftprintf(stderr, _T("Succeeded!\n"));
			_tchmod(output_file, S_IREAD);
			return 1;
		}
		else
		{
			_ftprintf(stderr, _T("Failed!\n"));
			system_error(GetLastError());
		}
	}
	return 0;
}

#endif //_WIN32

int _tmain (int argc, TCHAR **argv)
{
#ifdef _POSIX_VERSION
	struct sigaction sigact;
#endif /* _POSIX_VERSION */

#ifdef HAVE_NEW_HANDLER
	xmalloc_initalize_memory_allocation();
#endif //HAVE_NEW_HANDLER

#ifdef _WIN32
	__try
	{

	_CrtSetDbgFlag(_CRTDBG_LEAK_CHECK_DF | _CRTDBG_ALLOC_MEM_DF);
#endif //_WIN32	

	atexit(cleanup);
	program_name = module_path(argv[0]);
	if(program_name == (TCHAR*)0)
	{
		size_t len = _tcslen(argv[0]);
		program_name = (TCHAR*)xmalloc((len + 1) * sizeof(TCHAR));
		_tcsncpy(program_name, argv[0], len + 1);
	}

	_tsetlocale (LC_ALL, _T(""));
	bindtextdomain (PACKAGE, LOCALEDIR);
	textdomain (PACKAGE);
	initialize_translation_table();	

	/* Decode arguments. */
	scanargs (argc, argv);

	initialize_log_file();

	banner();

	if (show_help)
		usage (0);

	validate_input();  

#ifdef _WIN32
	// Try the vanilla copy (CopyFileEx).  If the vanilla copy fails, 
	// try to do it the old fashioned way.
	if(try_vanilla_copy())
		exit(0);
#endif //_WIN32

	apply_translations ();
	
	initialize_files(argc);
	
	_ASSERTE(input_file != 0);
	_ASSERTE(output_file != 0);
	_ASSERTE(md5_output_file != 0);

	//if (input_fd == output_fd)
	//	error (1, 0, _T("%s is closed"), (input_fd == 0
	//					 ? _T("standard input")
	//					 : _T("standard output")));

#ifdef _POSIX_VERSION
	initialize_signals(&sigact);
#else
	initialize_signals();
#endif //_POSIX_VERSION
	
#ifdef _WIN32
	if(input_physical_memory)
		copy_memory();
	else
#endif //_WIN32	
		copy_file ();

#ifdef _WIN32
	}
	__except(1) {	}
#endif //_WIN32
}

/* Throw away RECORDS blocks of BLOCKSIZE bytes on file descriptor FDESC,
   which is open with read permission for FILE.  Store up to BLOCKSIZE
   bytes of the data at a time in BUF, if necessary. */

static __int64 skip_read(int fdesc, TCHAR *file, _off_t records, size_t blocksize, unsigned char *buf)
{
	__int64 total_read = (__int64)0;

	while (records-- > 0)
	{
	  int nread;

	  nread = safe_read (fdesc, buf, blocksize);
	  if (nread < 0)
	    {
	      error (0, errno, _T("%s"), file);
	      exit (1);
	    }
	  /* POSIX doesn't say what to do when dd detects it has been
	     asked to skip past EOF, so I assume it's non-fatal.
	     FIXME: maybe give a warning.  */
	  if (nread == 0)
	    break;
	  total_read += nread;
	}
	return total_read;
}

void skip (int fdesc, TCHAR *file, _off_t records, size_t blocksize, unsigned char *buf)
{
	if (lseek (fdesc, records * blocksize, SEEK_SET) < 0 &&
		skip_read(fdesc, file, records, blocksize, buf) < 0)
	{
		error (0, errno, _T("%s"), file);
		exit (1);
	}
}

static __int64 skip_gzread(gzFile fdesc, TCHAR *file, _off_t records, size_t blocksize, unsigned char *buf)
{
	__int64 total_read = 0;

	while (records-- > 0)
	{
	  int nread;

	  nread = gzread (fdesc, buf, (unsigned int)blocksize);
	  if (nread < 0)
	    {
			int err;
			error (0, 0, gzerror(fdesc, &err));
		    exit (1);
	    }
	  /* POSIX doesn't say what to do when dd detects it has been
	     asked to skip past EOF, so I assume it's non-fatal.
	     FIXME: maybe give a warning.  */
	  if (nread == 0)
	    break;
	  total_read += nread;
	}
	return total_read;
}

static void gzskip (gzFile fdesc, TCHAR *file, _off_t records, size_t blocksize, unsigned char *buf)
{
  
   if (gzseek(fdesc, records * blocksize, SEEK_CUR) < 0 &&
	  skip_gzread(fdesc, file, records, blocksize, buf) < 0)
  {
	  int err;
	  error (0, 0, gzerror(fdesc, &err));
	  exit (1);
  }
}

/* Apply the character-set translations specified by the user
   to the NREAD bytes in BUF.  */

static void
translate_buffer (unsigned char *buf, int nread)
{
  register unsigned char *cp;
  register int i;

  for (i = nread, cp = buf; i; i--, cp++)
    *cp = trans_table[*cp];
}

/* If nonnzero, the last char from the previous call to `swab_buffer'
   is saved in `saved_char'.  */
static int char_is_saved = 0;

/* Odd char from previous call.  */
static char saved_char;

/* Swap NREAD bytes in BUF, plus possibly an initial char from the
   previous call.  If NREAD is odd, save the last char for the
   next call.   Return the new start of the BUF buffer.  */

static unsigned char *
swab_buffer (unsigned char *buf, int *nread)
{
  unsigned char *bufstart = buf;
  register unsigned char *cp;
  register int i;

  /* Is a char left from last time?  */
  if (char_is_saved)
    {
      *--bufstart = saved_char;
      (*nread)++;
      char_is_saved = 0;
    }

  if (*nread & 1)
    {
      /* An odd number of chars are in the buffer.  */
      saved_char = bufstart[--*nread];
      char_is_saved = 1;
    }

  /* Do the byte-swapping by moving every second character two
     positions toward the end, working from the end of the buffer
     toward the beginning.  This way we only move half of the data.  */

  cp = bufstart + *nread;	/* Start one char past the last.  */
  for (i = *nread / 2; i; i--, cp -= 2)
    *cp = *(cp - 2);

  return ++bufstart;
}

/* Index into current line, for `conv=block' and `conv=unblock'.  */
static size_t col = 0;

static void handle_bad_region(__int64 Start, __int64 End, size_t blocksize)
{
	_ftprintf(stderr, _T("File data in the range 0x%08I64x-0x%08I64x could not be read.\n"), Start, End + blocksize);
}

/* The main loop.  */

static void copy_file (void)
{
	__int64 BadStart = 0;
	__int64 BadLast = 0;
	int bInBadRegion = 0;
	unsigned char *bufstart = (unsigned char*)0; /* Input buffer. */
	unsigned int count = 0;
	_off_t nread;			/* Bytes read in the current block. */
	int exit_status = 0;
	unsigned char md5buffer[MD5_SIGNATURE_SIZE];
	unsigned char *ibuf = (unsigned char*) 0;
	unsigned char *obuf = (unsigned char*)0;
	PMD5CTX md5_ctx = (PMD5CTX)0;

	if (max_records == 0)
		exit (exit_status);

#ifdef _WIN32
  __try
  {
#endif //_WIN32

	  /* Leave at least one extra byte at the beginning and end of `ibuf'
	 for conv=swab, but keep the buffer address even.  But some peculiar
	 device drivers work only with word-aligned buffers, so leave an
	 extra two bytes.  */

	ibuf = (unsigned char *) xmalloc (input_blocksize + (2 * SWAB_ALIGN_OFFSET) + 72);
  
	memset ((char *) ibuf, 0, input_blocksize + (2 * SWAB_ALIGN_OFFSET) + 72);

	ibuf += SWAB_ALIGN_OFFSET;

	if ((conversions_mask & C_TWOBUFS) == C_TWOBUFS)
	{
		obuf = (unsigned char *) xmalloc (output_blocksize);
	}
	else
	{
		obuf = ibuf;
	}

  if(generate_md5sum)
  {
	  md5_ctx = md5_alloc_ctx();
	  md5_init_ctx(md5_ctx);
  }
  
	if (skip_records > 0)
	{
		if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
			gzskip(gzfh, input_file, skip_records, input_blocksize, ibuf);
		else
			skip(input_fd, input_file, skip_records, input_blocksize, ibuf);
	}


	// Delete Me:
	// For testing purposes only
	//	BadStart = lseek(input_fd, _DriveSize * 1024I64, SEEK_SET);
	//	BadStart = lseek(input_fd, 4096, SEEK_SET);

	if (seek_record > 0)
	{
		if((conversions_mask & C_COMPRESS) == C_COMPRESS)	
			gzskip(gzfh, output_file, skip_records, output_blocksize, obuf);
		else
			skip (output_fd, output_file, seek_record, output_blocksize, obuf);
	}

  _ftprintf(stderr, _T("Copying %s to %s...\n"), input_file, output_file);
  fflush(stderr);

  while (1)
	{
		// Control handler may not get scheduled without this.
		Sleep(0L); //added 8/17/2004

		if(bCancelled)
			break;

		if (max_records >= 0 && r_partial + r_full >= max_records)
			break;

	  /* Zero the buffer before reading, so that if we get a read error,
	 whatever data we are able to read is followed by zeros.
	 This minimizes data loss. */
	  if (/*(conversions_mask & C_SYNC) == C_SYNC && */
		  (conversions_mask & C_NOERROR) == C_NOERROR)
		memset ((char *) ibuf, 0, input_blocksize);

	errno=0;

	if(bInBadRegion)
	{
		__int64 pos = -1I64;

		if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
			pos = gzseek(gzfh, input_blocksize, SEEK_CUR);
		else
			pos = lseek(input_fd, input_blocksize, SEEK_CUR);
		
		if(pos < 0I64)
		{
			// Might mean that we are at the end of the file.
			// Handle the bad region and break.
			if(bInBadRegion)
			{
				handle_bad_region(BadStart, BadLast, input_blocksize);
				bInBadRegion = FALSE;
			}
			error(0, errno, _T("Failed to seek beyond bad file region at 0x%I64x\n"), BadLast);								
			break;
		}
	}

	if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
		nread = gzread(gzfh, ibuf, (unsigned int)input_blocksize);
	else
		nread = safe_read (input_fd, ibuf, input_blocksize);

	if (nread == 0)
	{
		if(bInBadRegion)
		{
			handle_bad_region(BadStart, BadLast, input_blocksize);
			bInBadRegion = FALSE;
		}
		break;			/* EOF.  */
	}
	else if (nread < 0)
	{
		int err = errno;

		if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
			BadLast = gztell(gzfh);
		else
			BadLast = tell(input_fd);

		if(BadLast == -1I64)
		{
			//Either this is a non-seeking device or some serious error has 
			//occurred.
			error(1, errno, _T("Failed to get offset of bad file region\n"));				
			break;
		}
		
		if(o_physical_drive[INPUT_FILE] &&	BadLast >= (_DriveSize * 1024I64))
		{
			/* EOF.*/
			/* The original POSIX version of 'dd' on which this code is based
			assumes that read() always will return 0 on an end-of-file condition, 
			even if the file is for a physical device.  This assumption is not POSIX-ly
			correct:  http://www.opengroup.org/onlinepubs/007904975/functions/read.html#tag_03_594_03 ("No data
			transfer shall occur past the current end-of-file. If the starting position is at or after			the end-of-file, 0 shall be returned. If the file refers to a device special file, the 			result of subsequent read() requests is implementation-defined.")  As a result, the POSIX version
			of 'dd' may fail on some versions of Windows.*/

			error(0, err, _T("read operation returning error for EOF condition at offset 0x%I64x.\n"), BadLast);

			if(bInBadRegion)
			{
				handle_bad_region(BadStart, BadLast, input_blocksize);
				bInBadRegion = FALSE;
			}

			nread = 0;

			break;			/* EOF.  */
		}

		if(!bInBadRegion)
		{
			if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
			{
				error(0, 0, gzerror(gzfh, &err));
			}
			else
			{
				error (0, err, _T("%s (offset 0x%I64x)"), input_file, BadLast);
			}
		}

		if ((conversions_mask & C_NOERROR) == C_NOERROR)
		{
			if(!bInBadRegion)
			{
				BadStart = BadLast;
				bInBadRegion = TRUE;
			}
			
			nread = (off_t) input_blocksize;
			memset (ibuf, 0, input_blocksize);
#ifdef CONVERSIONS_SUPPORTED
			if ((conversions_mask & C_SYNC) == C_SYNC)
			/* Replace the missing input with null bytes and
			proceed normally.  */
				nread = 0;
			else
#endif //CONVERSIONS_SUPPORTED
//				continue;
		}
	  else
		{
		  /* Write any partial block. */
		  exit_status = 2;
		  break;
		}
	}
	else if (((size_t)nread) < input_blocksize)
	{
		__int64 pos;

		if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
			pos = gztell(gzfh);
		else
			pos = tell(input_fd);

		error (0, errno, _T("%s (offset 0x%I64x)"), input_file, pos);

		r_partial++;

		if(bInBadRegion)
		{
			handle_bad_region(BadStart, BadLast, input_blocksize);
			bInBadRegion = FALSE;
		}

#if CONVERSIONS_SUPPORTED
		if ((conversions_mask & C_SYNC) == C_SYNC)
		{
		  if ((conversions_mask & C_NOERROR) == 0)
			/* If C_NOERROR, we zeroed the block before reading. */
			memset ((char *) (ibuf + nread), 0, input_blocksize - nread);
			nread = (_off_t)input_blocksize;
		}
#endif //CONVERSIONS_SUPPORTED
	}
	else //if(nread == input_blocksize)
	{
		r_full++;

		if(bInBadRegion)
		{
			handle_bad_region(BadStart, BadLast, input_blocksize);
			bInBadRegion = FALSE;
		}
	}

	if(bCancelled)
		break;
	
	 if (ibuf == obuf)		/* If not C_TWOBUFS. */
	{
	  
		 int nwritten = 0;

		 /*nread must be a multiple of 64*/
	 
		 if(generate_md5sum)
		{
			count++;
			if(nread == input_blocksize)
			{
				_RPT2(_CRT_WARN, "\n%ld. Calling md5_process_block for %ld bytes\n", count, nread);
				md5_process_block(ibuf, nread, md5_ctx);
			}
			else
			{
				_RPT2(_CRT_WARN, "\n%ld. Calling md5_process_bytes for %ld bytes\n", count, nread);
				md5_process_bytes (ibuf, nread, md5_ctx);
			}

		}

		if((conversions_mask & C_COMPRESS) == C_COMPRESS)
			nwritten = gzwrite(gzfh, obuf, nread);
		else
			nwritten = full_write (output_fd, obuf, nread);

	  if (nwritten < 0)
		{
		  error (0, errno, _T("%s"), output_file);
		  exit (1);
		}
	  else if (nread == input_blocksize)
		w_full++;
	  else
		w_partial++;
	  continue;
	}

	if(bCancelled)
		break;

	/* Do any translations on the whole buffer at once.  */

	if (translation_needed)
		translate_buffer (ibuf, nread);

	if(bCancelled)
		break;

#ifdef CONVERSIONS_SUPPORTED
	if ((conversions_mask & C_SWAB) == C_SWAB)
		bufstart = swab_buffer (ibuf, &nread);
	else
#endif //CONVERSIONS_SUPPORTED

		bufstart = ibuf;

	if(bCancelled)
		break;

#ifdef CONVERSIONS_SUPPORTED	 
		if ((conversions_mask & C_BLOCK) == C_BLOCK)
		copy_with_block (bufstart, nread, obuf);
	  else if ((conversions_mask & C_UNBLOCK) == C_UNBLOCK)
		copy_with_unblock (bufstart, nread, obuf);
	  else
#endif //CONVERSIONS_SUPPORTED
		copy_simple (bufstart, nread, obuf);
	}

  /* If we have a char left as a result of conv=swab, output it.  */
  if (char_is_saved)
	{
#ifdef CONVERSIONS_SUPPORTED
	  if (conversions_mask & C_BLOCK)
		copy_with_block (&saved_char, 1);
	  else if ((conversions_mask & C_UNBLOCK) == C_UNBLOCK)
	copy_with_unblock (&saved_char, 1);
	  else
#endif //CONVERSIONS_SUPPORTED

	output_char (saved_char, obuf);
	}

	if(bCancelled)
		__leave;

#ifdef CONVERSIONS_SUPPORTED	
	if ((conversions_mask & C_BLOCK) && col > 0)
	{
		  /* If the final input line didn't end with a '\n', pad
		 the output block to `conversion_blocksize' chars.  */
		  size_t pending_spaces = max (0, conversion_blocksize - col);
		  while (pending_spaces)
			{
			  output_char (space_character, obuf);
			  --pending_spaces;
			}
	}

  if ((conversions_mask & C_UNBLOCK) && col == conversion_blocksize)
	/* Add a final '\n' if there are exactly `conversion_blocksize'
	   characters in the final record. */
		output_char (newline_character, obuf);
#endif // CONVERSIONS_SUPPORTED
	if(bCancelled)
		__leave;
  
  /* Write out the last block. */
	if (oc > 0)
	{
		int nwritten;

		if((conversions_mask & C_COMPRESS) == C_COMPRESS)
			nwritten = gzwrite(gzfh, obuf, nread);
		else
			nwritten = full_write (output_fd, obuf, oc);
	  if (nwritten > 0)
		w_partial++;
		if (nwritten < 0)
		{
			if((conversions_mask & C_COMPRESS) == C_COMPRESS)
			{
				int err;
				error(0, 0, gzerror(gzfh, &err));
			}
			else
			{
				error (0, errno, _T("%s"), output_file);
			}
			exit (1);
		}
	}
	
	if(generate_md5sum)
	{
		unsigned char md5buffer2[MD5_SIGNATURE_SIZE + 1];

		if(bCancelled)
			__leave;

		if(md5_finish_ctx (md5_ctx, md5buffer, MD5_SIGNATURE_SIZE) != NULL)
		{
			write_md5sum(md5buffer, MD5_SIGNATURE_SIZE, input_file, output_file, md5_output_file);
			write_md5sum(md5buffer, MD5_SIGNATURE_SIZE, input_file, output_file, _T("standard output"));
		}

		if(verify_md5)
		{
			if(bCancelled)
				__leave;

			if(in_sparse)
				complete_sparse(output_fd, 0);

			_ftprintf(stderr, _T("\nVerifying output file...\n"));

			if((conversions_mask & C_COMPRESS) == C_COMPRESS)
			{
				_ASSERTE(output_fd == -1);
				gzclose(gzfh);
				gzfh = (gzFile)0;
			}
			else
			{
				_commit(output_fd);
			}

			if(output_fd != -1 && 
				lseek(output_fd, 0, SEEK_SET) < 0)
			{
				//non-seeking device
				_ftprintf(stderr, _T("Verification not supported on non-seeking device.\n"));
			}
			else
			{
				if((conversions_mask & C_COMPRESS) == C_COMPRESS)
				{
					if(md5_gzfile(output_file, TRUE, md5buffer2, MD5_SIGNATURE_SIZE, 0) != 0)
					{
						error(1, 0, _T("verification of compressed output file failed"));
					}
				}
				else
				{
					_md5_stream(output_fd, md5buffer2, MD5_SIGNATURE_SIZE);
				}
				write_md5sum(md5buffer2, MD5_SIGNATURE_SIZE, input_file, output_file, _T("standard output"));
			}

			_ftprintf(stderr, _T("The checksums %s match.\n"), 
				is_equal_md5(md5buffer, MD5_SIGNATURE_SIZE, md5buffer2, MD5_SIGNATURE_SIZE)? _T("do") : _T("do NOT"));
			
		}
	}

	if(in_sparse)
		complete_sparse(output_fd, 0);
#ifdef _WIN32
	}
	__finally
#endif //_WIN32
	{
		if(obuf != ibuf)
			free(obuf);

		free (ibuf - SWAB_ALIGN_OFFSET);

		if(md5_ctx != (PMD5CTX)0)
			md5_free_ctx(md5_ctx);
	}
}

#ifdef _WIN32
void system_error(long lerror)
{
	LPVOID lpMsgBuf = (LPVOID)0;

	__try
	{
		if((FormatMessage( 
			FORMAT_MESSAGE_ALLOCATE_BUFFER | 
			FORMAT_MESSAGE_FROM_SYSTEM | 
			FORMAT_MESSAGE_IGNORE_INSERTS,
			NULL,
			lerror,
			MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), // Default language
			(LPTSTR) &lpMsgBuf,
			0,
			NULL 
		)) == 0UL)
		__leave;
	
		_ftprintf(stderr, lpMsgBuf);
	}
	__finally
	{
		if(lpMsgBuf)
			LocalFree( lpMsgBuf );
	}
}
#endif // _WIN32

/* Copy NREAD bytes of BUF, with no conversions.  */

static void copy_simple (unsigned char *buf, size_t nread, unsigned char* _obuf)
{
  size_t nfree;			/* Number of unused bytes in `obuf'.  */
  unsigned char *start = buf; /* First uncopied char in BUF.  */

  do
    {
      nfree = output_blocksize - oc;
      if (nfree > (size_t)nread)
		nfree = nread;

      memcpy ((char *) (_obuf + oc), (char *) start, nfree);

      nread -= nfree;		/* Update the number of bytes left to copy. */
      start += nfree;
      oc += (_off_t)nfree;
      if (oc >= output_blocksize)
		write_output (_obuf);
    }
  while (nread > 0);
}

/* Copy NREAD bytes of BUF, doing conv=block
   (pad newline-terminated records to `conversion_blocksize',
   replacing the newline with trailing spaces).  */

static void
copy_with_block (unsigned char *buf, size_t nread, unsigned char* obuf)
{
  register size_t i;

  for (i = nread; i; i--, buf++)
    {
      if (*buf == newline_character)
	{
	  size_t pending_spaces = max (0, conversion_blocksize - col);
	  while (pending_spaces)
	    {
	      output_char (space_character, obuf);
	      --pending_spaces;
	    }
	  col = 0;
	}
      else
	{
	  if (col == conversion_blocksize)
	    r_truncate++;
	  else if (col < conversion_blocksize)
	    output_char (*buf, obuf);
	  col++;
	}
    }
}

/* Copy NREAD bytes of BUF, doing conv=unblock
   (replace trailing spaces in `conversion_blocksize'-sized records
   with a newline).  */

static void copy_with_unblock (unsigned char *buf, size_t nread, unsigned char* obuf)
{
  register size_t i;
  register unsigned char c;
  static int pending_spaces = 0;

  for (i = 0; i < nread; i++)
    {
      c = buf[i];

      if (col++ >= conversion_blocksize)
	{
	  col = pending_spaces = 0; /* Wipe out any pending spaces.  */
	  i--;			/* Push the char back; get it later. */
	  output_char (newline_character, obuf);
	}
      else if (c == space_character)
	pending_spaces++;
      else
	{
	  /* `c' is the character after a run of spaces that were not
	     at the end of the conversion buffer.  Output them.  */
	  while (pending_spaces)
	    {
	      output_char (space_character, obuf);
	      --pending_spaces;
	    }
	  output_char (c, obuf);
	}
    }
}

/* Write, then empty, the output buffer `obuf'. */

static void write_output (unsigned char* obuf)
{
	int nwritten = full_write (output_fd, obuf, output_blocksize);
  if (nwritten != output_blocksize)
    {
		error (0, errno, _T("%s"), output_file);
		if (nwritten > 0)
			w_partial++;
		exit (1);
    }
  else
    w_full++;
  oc = 0;
}

static void adjust_block_sizes()
{
  unsigned long dwSize = page_size();

  /*C_TWOBUFS is not supported with -md5sum*/
//  if(!generate_md5sum)
//	conversions_mask |= C_TWOBUFS;
  if (input_blocksize == -1)
    input_blocksize = dwSize;
  if (output_blocksize == -1)
    output_blocksize = dwSize;
#ifdef CONVERSIONS_SUPPORTED
  if (conversion_blocksize == 0)
    conversions_mask &= ~(C_BLOCK | C_UNBLOCK);
#endif //CONVERSIONS_SUPPORTED

}
static void validate_input()
{
	/* If bs= was given, both `input_blocksize' and `output_blocksize' will
		have been set to non-negative values.  If either has not been set,
		bs= was not given, so make sure two buffers are used. */
	if (input_blocksize == -1 || output_blocksize == -1)
		adjust_block_sizes();
	if(generate_md5sum)
	{
		struct stat _St;

		if(input_blocksize != output_blocksize)
			error(1, 0, _T("Input blocksize and output blocksize must be the same with -md5sum.\n"));
		else if ((conversions_mask & C_TWOBUFS) == C_TWOBUFS)
			error(1, 0, _T("Two buffers is not supported with -md5sum.\n"));
		else if((conversions_mask & ~(C_COMPRESS | C_DECOMPRESS | C_NOERROR)) != 0)
			error(1, 0, _T("Only comp, decomp and noerror conversions supported with -md5sum.\n"));
		else if (md5_output_file == NULL ||
			(lstat(md5_output_file, &_St) == 0 && (_St.st_mode & S_IFREG) == S_IFREG))
			error(1, 0, _T("MD5 output file is not a regular file.\n"));
		check_block_sizes();
	}
	
	if(input_physical_memory)
	{
		if((conversions_mask & C_DECOMPRESS) == C_DECOMPRESS)
			error(1, 0, _T("Physical memory cannot be decompressed on input.\n"));
		if(o_lock[INPUT_FILE])
			error(1, 0, _T("Physical memory cannot be locked on input.\n"));
	}
	
	if(verify_md5)
	{
		struct stat _St;
		
		if(!generate_md5sum)
			error(1, 0, _T("Verification requires that the --md5sum option also be specified\n"));
		else if(output_file == NULL ||
			(lstat(output_file, &_St) == 0 &&
			(_St.st_mode & S_IFREG) != S_IFREG))
			error(1, 0, _T("Verification is supported only for disk files and the output file is not a disk file."));
	}
}

static void scanargs (int argc, TCHAR **argv)
{
  int i, n;
  int c;

static struct option const long_options[] =
	{
	{_T("help"), no_argument, &show_help, 1},
	{_T("version"), no_argument, &show_version, 1},
	{_T("md5sum"), no_argument, &generate_md5sum, 1},
	{_T("verifymd5"), no_argument, &verify_md5, 1},
	{_T("md5out"), required_argument, 0, _T('o')},
	{_T("sparse"), no_argument, &o_sparse, 1},
	{_T("lockin"), no_argument, &o_lock[INPUT_FILE], 1},
	{_T("lockout"), no_argument, &o_lock[OUTPUT_FILE], 1},
	{_T("log"), required_argument, 0, _T('l')},
	{0, 0, 0, 0}
	};

  while ((c = getopt_long (argc, argv, _T(""), long_options, (int *) 0)) != EOF)
    {
		switch (c)
		{
		case 0:
		  break;

		case _T('l'):
		  if(optarg[0] != _T('\0'))
			  log_file = full_path(optarg);
			  break;
		case _T('o'):
		  if(optarg[0] != _T('\0'))
			  md5_output_file = full_path(optarg);
			  break;
		case _T('h'):
		default:
		  usage (1);
		}
    }

	if(md5_output_file == (TCHAR*)0)
	{
		size_t len = _tcslen(_T("standard output"));
		md5_output_file = malloc((len + 1) * sizeof(TCHAR));
		_tcsncpy(md5_output_file, _T("standard output"), len + 1);
	}

  for (i = optind; i < argc; i++)
  {
		  TCHAR *name, *val;

		  name = argv[i];
		  val = _tcschr (name, _T('='));
		  if (val == NULL)
		{
		  error (0, 0, _T("unrecognized option `%s'"), name);
		  usage (1);
		}
		  *val++ = _T('\0');

		  if (equal (name, _T("if"), 3))
		{
			if((input_file = full_path(val)) == NULL)
			{
				size_t len = _tcslen(val);
				input_file = malloc((len + 1) * sizeof(TCHAR));
				_tcsncpy(input_file, val, len + 1);
			}
		}
		else if (equal (name, _T("of"), 3))
		{
			if((output_file = full_path(val)) == NULL)
			{
				size_t len = _tcslen(val);
				output_file = malloc((len + 1) * sizeof(TCHAR));
				_tcsncpy(output_file, val, len + 1);
			}

		}
		else if (equal (name, _T("conv"), 5))
		{
			parse_conversion (val);
		}
		else
		{
		  n = parse_integer (val);
		  if (n < 0)
			error (1, 0, _T("invalid number `%s'"), val);

		  if (equal (name, _T("ibs"), 4))
			{
			  input_blocksize = n;
			  conversions_mask |= C_TWOBUFS;
			}
		  else if (equal (name, _T("obs"), 4))
			{
			  output_blocksize = n;
			  conversions_mask |= C_TWOBUFS;
			}
		  else if (equal (name, _T("bs"), 3))
			output_blocksize = input_blocksize = n;
		  else if (equal (name, _T("cbs"), 4))
			conversion_blocksize = n;
		  else if (equal (name, _T("skip"), 5))
			skip_records = n;
		  else if (equal (name, _T("seek"), 5))
			seek_record = n;
		  else if (equal (name, _T("count"), 6))
			max_records = n;
		  else if (equal(name, _T("md5sum"), 7))
			  generate_md5sum = 1;
		  else if (equal(name, _T("verifymd5"), 7))
			  verify_md5 = 1;
		  else
			{
			  error (0, 0, _T("unrecognized option `%s=%s'"), name, val);
			  usage (1);
			}
		}
    }
	input_physical_memory = is_physical_memory_device(input_file);
}

/* Return the value of STR, interpreted as a non-negative decimal integer,
   optionally multiplied by various values.
   Return -1 if STR does not represent a number in this format. */

/* FIXME: use xstrtou?l */

static int
parse_integer (TCHAR *str)
{
  register int n = 0;
  register int temp;
  register TCHAR *p = str;

  while (ISDIGIT (*p))
    {
      n = n * 10 + *p - '0';
      p++;
    }
loop:
  switch (*p++)
    {
    case _T('\0'):
      return n;
    case _T('b'):
      n *= 512;
      goto loop;
    case _T('c'):
      goto loop;
    case _T('k'):
      n *= 1024;
      goto loop;
    case _T('w'):
      n *= 2;
      goto loop;
    case _T('x'):
      temp = parse_integer (p);
      if (temp == -1)
	return -1;
      n *= temp;
      break;
    default:
      return -1;
    }
  return n;
}

/* Interpret one "conv=..." option. */

static void
parse_conversion (TCHAR *str)
{
  TCHAR *new;
  int i;

  do
    {
      new = _tcschr (str, _T(','));
      if (new != NULL)
	*new++ = _T('\0');
      for (i = 0; conversions[i].convname != NULL; i++)
		if (equal(conversions[i].convname, str,_tcslen(conversions[i].convname)+1))
		  {
			conversions_mask |= conversions[i].conversion;
			break;
		  }
        if (conversions[i].convname == NULL)
		{
		  error (0, 0, _T("%s: invalid conversion"), str);
		  usage (1);
		}
      str = new;
  } while (new != NULL);
}

/* Fix up translation table. */

static void
apply_translations (void)
{
#ifdef CONVERSIONS_SUPPORTED
	int i;


#define MX(a) (bit_count (conversions_mask & (a)))
  if ((MX (C_ASCII | C_EBCDIC | C_IBM) > 1)
      || (MX (C_BLOCK | C_UNBLOCK) > 1)
      || (MX (C_LCASE | C_UCASE) > 1)
      || (MX (C_UNBLOCK | C_SYNC) > 1))
    {
      error (1, 0, _T("\
only one conv in {ascii,ebcdic,ibm}, {lcase,ucase}, {block,unblock}, {unblock,sync}"));
    }
#undef MX

  if ((conversions_mask & C_ASCII) == C_ASCII)
    translate_charset (ebcdic_to_ascii);

  if ((conversions_mask & C_UCASE) == C_UCASE)
    {
      for (i = 0; i < 256; i++)
	if (ISLOWER (trans_table[i]))
	  trans_table[i] = toupper (trans_table[i]);
      translation_needed = 1;
    }
  else if ((conversions_mask & C_LCASE) == C_LCASE)
    {
      for (i = 0; i < 256; i++)
	if (ISUPPER (trans_table[i]))
	  trans_table[i] = tolower (trans_table[i]);
      translation_needed = 1;
    }

  if ((conversions_mask & C_EBCDIC) == C_EBCDIC)
    {
      translate_charset (ascii_to_ebcdic);
      newline_character = ascii_to_ebcdic['\n'];
      space_character = ascii_to_ebcdic[' '];
    }
  else if ((conversions_mask & C_IBM) == C_IBM)
    {
      translate_charset (ascii_to_ibm);
      newline_character = ascii_to_ibm['\n'];
      space_character = ascii_to_ibm[' '];
    }
#endif //CONVERSIONS_SUPPORTED
}

static void
translate_charset (const unsigned char *new_trans)
{
  int i;

  for (i = 0; i < 256; i++)
    trans_table[i] = new_trans[trans_table[i]];
  translation_needed = 1;
}

/* Return the number of 1 bits in `i'. */

static int
bit_count (register unsigned int i)
{
  register int set_bits;

  for (set_bits = 0; i != 0; set_bits++)
    i &= i - 1;
  return set_bits;
}

static void print_stats (void)
{
	_ftprintf(stderr, _T("\n"));

	if(output_file != (TCHAR*) 0)
	{
		struct stat _St;
#ifdef _WIN32
		LARGE_INTEGER _S;
#endif // _WIN32

		_ASSERTE(output_file != (TCHAR*)0);

		if(lstat(output_file, &_St) == 0 &&
			(_St.st_mode & S_IFREG) == S_IFREG)
		{
#ifdef _WIN32

			_S.LowPart = GetCompressedFileSize(output_file, &_S.HighPart);
			if(o_supports_compression && 
				_S.LowPart != INVALID_FILE_SIZE && 
				_St.st_size != 0I64)
				_ftprintf(stderr, _T("Output %s %I64d/%I64d bytes (compressed/uncompressed)\n"), output_file, _S.QuadPart, _St.st_size);
			else
#endif //_WIN32
				_ftprintf(stderr, _T("Output %s (%I64d bytes)\n"), output_file, _St.st_size);
		}
	}
  _ftprintf (stderr, _T("%u+%u records in\n"), r_full, r_partial);
  _ftprintf (stderr, _T("%u+%u records out\n"), w_full, w_partial);
  if (r_truncate > 0)
    _ftprintf (stderr, _T("%u %s\n"), r_truncate,
	     (r_truncate == 1
	      ? _T("truncated record")
	      : _T("truncated records")));
}

// added 8/17/2004
static BOOL close_log_file(void)
{
	int to_close = (int) interlocked_exchange(&log_fd, -1);
	if(to_close != -1)
	{
		fflush(stderr);
		_ASSERTE(old_stderr != -1);
		dup2(old_stderr, 1);

		close(to_close);
		return TRUE;
	}

	return FALSE;
}

static void cleanup (void)
{
	int to_close;
	void* to_free;

	to_close = (int) interlocked_exchange(&input_fd, -1);
	
	if (to_close != -1)
	{
		if(o_lock[INPUT_FILE])
			unlock_file(to_close, -1, INPUT_FILE);
		close (to_close);
	}

	to_close = (int) interlocked_exchange(&output_fd, -1);
	if (to_close != -1)
	{
		if(o_disk_device[OUTPUT_FILE] && 
			o_lock[OUTPUT_FILE])
			dismount_device(fileno(to_close), OUTPUT_FILE);

		if(o_lock[OUTPUT_FILE])
			unlock_file(to_close, -1, OUTPUT_FILE);
		
		close(to_close);
	}

	print_stats ();

	if(to_free = interlocked_exchange_ptr(&input_file, 0))
	{
		if(to_free != (void*)0)
			free(to_free);
	}

	if(to_free = interlocked_exchange_ptr(&output_file, 0))
	{
		if(to_free != (void*)0)
			free(to_free);
	}

	to_close = (int) interlocked_exchange(&log_fd, -1);
	if(to_close != -1)
	{
		fflush(stderr);
		close(to_close);
		_ASSERTE(old_stderr != -1);
		dup2(old_stderr, 1);
	}

	/*if(to_free = interlocked_exchange_ptr(&log_file, 0))
	{
		if(to_free != (void*)0)
			free(to_free);
	}*/
	close_log_file();

	if(to_free = interlocked_exchange_ptr(&md5_output_fd, 0))
	{
		if(to_free != (void*)0)
			fclose(to_free);
	}

	if(to_free = interlocked_exchange_ptr(&md5_output_file, 0))
	{
		if(to_free != (void*)0)
			free(to_free);
	}

	if(to_free = interlocked_exchange_ptr((void**)&gzfh, 0))
	{
		if(to_free != (void*)0)
			gzclose((gzFile)to_free);
	}
	
	if(to_free = interlocked_exchange_ptr(&program_name, 0))
	{
		if(to_free != (void*)0)
			free(to_free);
	}

#ifdef _WIN32
	close_physical_memory();
#endif // _WIN32
}

static RETSIGTYPE
interrupt_handler (int sig)
{
#ifdef SA_INTERRUPT
  struct sigaction sigact;

  sigact.sa_handler = SIG_DFL;
  sigemptyset (&sigact.sa_mask);
  sigact.sa_flags = 0;
  sigaction (sig, &sigact, NULL);
#else				/* !SA_INTERRUPT */
  signal (sig, SIG_DFL);
#endif				/* SA_INTERRUPT */
//  cleanup (); 

#ifdef _WIN32
  exit(sig);
#else
  kill (getpid (), sig);
#endif 
}

static void usage (int status)
{
  if (status != 0)
    _ftprintf (stderr, _T("Try `%s --help' for more information.\n"),
	     program_name);
  else
    {
      _tprintf (_T("Usage: %s [OPTION]...[-md5out=FILE]\n"), program_name);
      printf (_("\
Copy a file, converting and formatting according to the options.\n\
\n\
  bs=BYTES         force ibs=BYTES and obs=BYTES\n\
  cbs=BYTES        convert BYTES bytes at a time\n\
  conv=KEYWORDS    convert the file as per the comma separated keyword list\n\
  count=BLOCKS     copy only BLOCKS input blocks\n\
  ibs=BYTES        read BYTES bytes at a time\n\
  if=FILE          read from FILE instead of stdin\n\
  obs=BYTES        write BYTES bytes at a time\n\
  of=FILE          write to FILE instead of stdout, don't truncate file\n\
  seek=BLOCKS      skip BLOCKS obs-sized blocks at start of output\n\
  skip=BLOCKS      skip BLOCKS ibs-sized blocks at start of input\n\
     --help        display this help and exit\n\
     --version     output version information and exit\n\
     --md5sum      generate md5 checksum for copied data\n \
     --verifymd5   computes the md5 checksum of the output file\n \
	 --sparse      enables support for sparse output files\n \
	 --lockin      lock input file during dd\n \
	 --lockout     lock output file during dd\n \
	 --md5out=FILE writes the md5 checksum to FILE\n \
	 --log=FILE    writes status information to the specified log file\n \
\n\
BYTES may be suffixed: by xM for multiplication by M, by c for x1,\n\
by w for x2, by b for x512, by k for x1024.  Each KEYWORD may be:\n\
\n\
  noerror   continue after read errors\n\
  comp             Compress output\n\
  decomp           Decompress input\n"));

#ifdef SUPPORT_CONVERSIONS
printf (_("\
  ascii     from EBCDIC to ASCII\n\
  ebcdic    from ASCII to EBCDIC\n\
  ibm       from ASCII to alternated EBCDIC\n\
  block     pad newline-terminated records with spaces to cbs-size\n\
  unblock   replace trailing spaces in cbs-size records with newline\n\
  lcase     change upper case to lower case\n\
  ucase     change lower case to upper case\n\
  swab      swap every pair of input bytes\n\
  sync      pad every input block with NULs to ibs-size\n"));
#endif //SUPPORT_CONVERSIONS

      _putts (_T("\nReport bugs to gmgarner@erols.com"));
    }
  exit (status);
}

#ifdef _WIN32
//
//  FUNCTION: control_handler ( unsigned long sig )
//
//  PURPOSE: Handled console control events
//
//  PARAMETERS:
//    dwCtrlType - type of control event
//
//  RETURN VALUE:
//    True - handled
//    False - unhandled
//
//  COMMENTS:
//
int __stdcall control_handler ( unsigned long sig )
{

	switch( sig)
    {
        case CTRL_BREAK_EVENT:  // use Ctrl+C or Ctrl+Break to simulate
        case CTRL_C_EVENT:      // SERVICE_CONTROL_STOP in debug mode
			/*Unfortunately, the original gnu code is hopelessly single-threaded.
			  This is the best that we can do here.*/
			_ftprintf(stderr, _T("Stopping dd.exe..."));
			__try
			{
				InterlockedExchange(&bCancelled, 1L);
			}
			__except(1) {	}

            return 1;
            break;
		default:
			;
    }
    return 0;
}

char* root_path(const char* _Path)
{
	size_t len;
	char* root;
	char* dir;
	char drive[_MAX_DRIVE];
	
	_ASSERTE(_Path != NULL);
	if(_Path == NULL || _Path[0] == '\0')
		return (char*)0;

	// The directory length will be less than or equal to the size
	// of the full path plus one for the trailing null character.
	// Also add one for a trailing backslash which may be added 
	// by splitpath.  Add _MAX_DRIVE so that we can do makepath in place.
	len = strlen(_Path) + 2 + _MAX_DRIVE;
	
	root = malloc(len * sizeof(char));
	dir = root + _MAX_DRIVE;
	
	// Separate the drive letter (if any) and directory
	_splitpath(_Path, drive, dir, NULL, NULL);
	_makepath(root, drive, dir, NULL, NULL);
	
	return root;
}

int volume_sector_size(const TCHAR* root)
{
	__int32 dwSectorSize;
	unsigned long dwSectorsPerCluster;
	unsigned long dwNumberOfFreeClusters;
	unsigned long dwTotalNumberOfClusters;

	if(!GetDiskFreeSpace(root,
				            &dwSectorsPerCluster,
							(unsigned long*)&dwSectorSize,
							&dwNumberOfFreeClusters,
							&dwTotalNumberOfClusters))				
	{
		return INVALID_SECTOR_SIZE;	
	}
	
	
	_RPT3(_CRT_WARN, "%s: BytesPerSector = %ld, SectorsPerCluster = %ld\n", root, dwSectorSize, dwSectorsPerCluster);		

	return dwSectorSize;
}

// Requires Windows 2000 or later
#if defined(_UNICODE) && _WIN32_WINNT >= 0x0501

/*LPWSTR first_argument(LPWSTR command_line, LPCWSTR lpszApplication)
{
	_ASSERTE(command_line != NULL);
	_ASSERTE(lpszApplication != NULL);

	if(command_line[0] == _T('\"'))
		command_line = wcschr(++command_line, L'\"');
	else
		command_line += (wcslen(lpszApplication));

	_ASSERTE(command_line == NULL || iswspace(command_line[0]) || iswspace(command_line[1]));

	return ++command_line;
}

typedef int (__stdcall *SHCREATEPROCESSASUSERW) (PSHCREATEPROCESSINFOW);
 
int shell_create_process_as_user(PSHCREATEPROCESSINFOW psei)
{
	SHCREATEPROCESSASUSERW pfnSHCreateProcessAsUserW;
	HMODULE hMod;
	int result = 0;
	
	if( psei == NULL || 
		(hMod = LoadLibraryW(L"Shell32.dll")) == (HMODULE) 0)
		return result;
 
	__try
	{
		if((pfnSHCreateProcessAsUserW = (SHCREATEPROCESSASUSERW)GetProcAddress(hMod, "SHCreateProcessAsUserW")) == NULL)
			__leave;

		result = (*pfnSHCreateProcessAsUserW)(psei);
	}
	__finally
	{
		if(hMod != (HMODULE)0)
			FreeLibrary(hMod);
	}
	return result;
}

LPCWSTR module_filename(HMODULE hMod, LPWSTR lpszPath, unsigned long size)
{
	size_t count;

	_ASSERTE(lpszPath != (LPTSTR)0);

	// The documentation for CreateProcessAsUser() explains the security
	// considerations behind enclosing the application name in double
	// quotes on Win32 platforms

	lpszPath[0] = L'\"';

	if(!GetModuleFileNameW(hMod,
		                  lpszPath + 1,
						  size - 3))
		return (LPCWSTR) 0;

	
	count = wcslen(lpszPath);

	lpszPath[count] = L'\"';
	lpszPath[count + 1] = L'\0';

	if(lpszPath[1] == L'\"')
		return (lpszPath + 1);
	else
		return lpszPath;
}

int create_process_as_user(int nArgs, wchar_t* thisApp)
{
	SHCREATEPROCESSINFOW sei;
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
	wchar_t myname[_MAX_PATH + 3];
	wchar_t mycurrentdirectory[_MAX_PATH + 3];

	memset(&sei, 0, sizeof(sei));
	GetStartupInfoW(&si);

	sei.cbSize = sizeof(sei);
	sei.fMask = SEE_MASK_UNICODE;
	
	sei.pszFile = module_filename(0, myname, _MAX_PATH + 3)? myname : thisApp;
	sei.pszCurrentDirectory = 	module_filename(GetModuleHandleW(L"md5lib"), mycurrentdirectory, _MAX_PATH + 3);
	if(nArgs > 1)
		sei.pszParameters = first_argument(GetCommandLineW(), thisApp);

	
	sei.lpStartupInfo = &si;
	sei.lpProcessInformation = &pi;

	return shell_create_process_as_user(&sei);
	
}*/
//8/17/2004 Taken from developmental release
long prompt_for_user_name_and_password(const __wchar_t* pszTarget, __wchar_t* pszUserName, size_t user_name_size, __wchar_t* pszPassword, size_t password_size)
{
	BOOL bSaved = FALSE;

	_ASSERTE(pszUserName != NULL && pszPassword != NULL);
	_ASSERTE(user_name_size == CREDUI_MAX_USERNAME_LENGTH
		&& password_size == CREDUI_MAX_PASSWORD_LENGTH);
	
	return CredUICmdLinePromptForCredentialsW(pszTarget,
											NULL,
											0UL,
											pszUserName,
											(unsigned long)user_name_size,
											pszPassword,
											(unsigned long)password_size,
											&bSaved,
											CREDUI_FLAGS_DO_NOT_PERSIST | CREDUI_FLAGS_VALIDATE_USERNAME | CREDUI_FLAGS_EXCLUDE_CERTIFICATES
											);
}

int create_process_as_user(int nArgs, __wchar_t* thisApp)
{
	long lError;
	
	STARTUPINFO si;
	PROCESS_INFORMATION pi;

	__wchar_t szUserName[CREDUI_MAX_USERNAME_LENGTH + 1];
	__wchar_t szPassword[CREDUI_MAX_PASSWORD_LENGTH + 1];
	__wchar_t szDomain[CREDUI_MAX_DOMAIN_TARGET_LENGTH + 1];
	__wchar_t szUser[CREDUI_MAX_USERNAME_LENGTH + 1];

	__wchar_t* pszTarget = NULL;

	if(!is_windows_xp())
		return FALSE;

	szUserName[0] = L'\0';
	szPassword[0] = L'\0';
	szDomain[0] = L'\0';

	memset(&si, 0, sizeof(STARTUPINFO));
	memset(&pi, 0, sizeof(PROCESS_INFORMATION));

	__try
	{
		pszTarget = computer_name(ComputerNamePhysicalNetBIOS);

		_RPT0(_CRT_WARN, "The computer name is ");
		OutputDebugStringW(pszTarget != NULL ? pszTarget : L"");
		_RPT0(_CRT_WARN, "\n");

		lError = prompt_for_user_name_and_password(pszTarget, szUserName, CREDUI_MAX_USERNAME_LENGTH, szPassword, CREDUI_MAX_PASSWORD_LENGTH);
		if(lError != NO_ERROR)
			RaiseException(lError, 0, 0, 0);

		if((lError = CredUIParseUserNameW(szUserName,
							szUser,
							CREDUI_MAX_USERNAME_LENGTH + 1,
							szDomain,
							CREDUI_MAX_DOMAIN_TARGET_LENGTH + 1
							)) != NO_ERROR)
		{
			_RPT1(_CRT_WARN, "CredUIParseUserName failed: Last Error = %ld\n", lError);
			RaiseException(lError, 0, 0, 0);
		}

		GetStartupInfoW(&si);

		si.lpDesktop = NULL;

		_RPT0(_CRT_WARN, "Calling CreateProcessWithLogonW for application: ");
		OutputDebugStringW(thisApp);
		_RPT1(_CRT_WARN, "\nCommand Line: %s\nUser Name: ", GetCommandLineA());
		OutputDebugStringW(szUser);
		_RPT0(_CRT_WARN, "\nDomain: ");
		OutputDebugStringW(szDomain);
		_RPT0(_CRT_WARN, "\n");

		if(!CreateProcessWithLogonW(szUser,
										szDomain,
										szPassword,
										0UL,
										thisApp,
										GetCommandLineW(),
										CREATE_UNICODE_ENVIRONMENT | CREATE_SUSPENDED,
										NULL,
										NULL,
										&si,
										&pi
										))
			RaiseException(GetLastError(), 0, 0, 0);

		close_log_file();		
		
		if(log_file != NULL &&
			_tcsnicmp(log_file, _T("CONOUT$"), 8) != 0)
			_tchmod(log_file, S_IWRITE | S_IREAD);
		ResumeThread(pi.hThread);
	}
	__finally
	{
		memset(&szUserName, 0, (CREDUI_MAX_USERNAME_LENGTH + 1) * sizeof(__wchar_t));
		memset(&szPassword, 0, (CREDUI_MAX_PASSWORD_LENGTH + 1) * sizeof(__wchar_t));

		if(pszTarget != NULL)
			free(pszTarget);

		if(pi.hProcess != (HANDLE)0)
			CloseHandle(pi.hProcess);
		if(pi.hThread != (HANDLE)0)
			CloseHandle(pi.hThread);
	}

	return TRUE;
}

#endif // defined(_UNICODE) && _WIN32_WINNT >= 0x0500

#endif //_WIN32

void* interlocked_exchange_ptr(void* volatile* target, void* value)
{
#ifdef _WIN32

#if defined(_X86_)
#pragma warning(disable : 4311)
#pragma warning(disable : 4312)
#endif //_X86

	return InterlockedExchangePointer(target, value);

#if defined(_X86_)
#pragma warning(default : 4311)
#pragma warning(default : 4312)
#endif //_X86
#else
	// TODO
	#pragma message("interlocked_exchange_ptr() not implemented")
#endif //_WIN32
}


SOCKET interlocked_exchange_socket(SOCKET volatile* target, SOCKET value)
{
#ifdef _WIN32
	return (SOCKET) interlocked_exchange_ptr((void* volatile *) target, (void*)value); 
#else
	// TODO
	#pragma message("interlocked_exchange_socket() not implemented")
#endif //_WIN32
}

int interlocked_exchange(int volatile* target, int value)
{
#ifdef _WIN32
	return InterlockedExchange(target, value);
#else
	// TODO
#pragma message("interlocked_exchange() not implemented")
#endif //_WIN32
}