/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002, 2003 George M. Garner Jr.

#if HAVE_CONFIG_H
# include <config.h>
#endif

#include <sys/types.h>
#include <stdio.h>
#include <io.h>
#include <wtypes.h>

extern unsigned __int64 wrote_out;
extern TCHAR *output_file;
size_t output_blocksize;
#define FILESYSNAMEBUFSIZE 1024

char *xmalloc (size_t n);
void* interlocked_exchange_ptr(void* volatile* target, void* value);

void init_sparse();
void free_sparse();
BOOL is_sparse(int fd);
BOOL set_sparse(int fd);
BOOL file_system_supports(const TCHAR* _Path, unsigned long dwMask);
int begin_sparse(size_t len);
int complete_sparse(int fd, size_t len);
static int set_zero_data(int fd, PFILE_ZERO_DATA_INFORMATION pzd);
static TCHAR* volume_path_name(const TCHAR* _Path);

int in_sparse = FALSE;
static FILE_ZERO_DATA_INFORMATION zd;
unsigned char* zbuf = (unsigned char*)0;


static TCHAR* volume_path_name(const TCHAR* _Path)
{
	size_t Len;
	TCHAR* vp = NULL;
	_ASSERTE(_Path != NULL);

	if(_Path == NULL || _Path[0] == _T('\0'))
		return (TCHAR*)0;

	Len = _tcslen(_Path) + 1;

	vp = (TCHAR*)xmalloc(Len * sizeof(TCHAR));

	if(!GetVolumePathName(_Path,
			                vp,
							(unsigned long) Len))
	{
		free(vp);
		return (TCHAR*)0;
	}
	return vp;
}

static int set_zero_data(int fd, PFILE_ZERO_DATA_INFORMATION pzd)
{
	unsigned long dwBytesReturned;

	if(fd < 0)
		return FALSE;

	return DeviceIoControl((HANDLE)_get_osfhandle(fd),
		                   FSCTL_SET_ZERO_DATA,
						   pzd,
						   sizeof(FILE_ZERO_DATA_INFORMATION),
						   NULL,
						   0UL,
						   &dwBytesReturned,
						   NULL);
}

int begin_sparse(size_t len)
{
	if(!in_sparse)
	{
		zd.FileOffset.QuadPart = wrote_out;
		zd.BeyondFinalZero.QuadPart = (__int64) wrote_out;
		in_sparse = TRUE;
		//fprintf(stderr, "Beginning sparse region at 0x%I64x\n", wrote_out);
	}
	return (int)len;
}

int complete_sparse(int fd, size_t len)
{
	int res = -1;
#ifdef _DEBUG
	unsigned long sh;
#endif // _DEBUG

	if(!in_sparse)
		return 0;
	else 
	{
		zd.BeyondFinalZero.QuadPart = wrote_out;
		if(set_zero_data(fd, &zd))
		{
			LARGE_INTEGER cur_pos;
			BOOL bResult;

			res =  (int)len;

			bResult = SetFilePointerEx((HANDLE)_get_osfhandle(fd),
											zd.BeyondFinalZero,
											&cur_pos,
											FILE_BEGIN);
			_ASSERT(bResult);

			bResult = SetEndOfFile((HANDLE) _get_osfhandle(fd));
			_ASSERT(bResult);

			//fprintf(stderr, "Completing sparse region at 0x%I64x\n", wrote_out);
		}
	}
	_ASSERTE(output_file != NULL);
	_RPT3(_CRT_WARN, "%s is %ld bytes compressed and %ld bytes uncompressed.\n", 
			output_file, GetCompressedFileSize(output_file, &sh), 
			GetFileSize((HANDLE) _get_osfhandle(fd), &sh));
	
	in_sparse = FALSE;
	return (int)len;
}

void init_sparse()
{
	zbuf = xmalloc(output_blocksize * sizeof(char));
	memset(zbuf, 0, output_blocksize * sizeof(char));
}

void free_sparse()
{
	void * p = interlocked_exchange_ptr(&zbuf, 0);
	if(p != 0)
		free(p);
}

BOOL set_sparse(int fd)
{
	unsigned long dwBytesReturned;

	if(fd < 0)
		return FALSE;

	return DeviceIoControl((HANDLE)_get_osfhandle(fd),
		                   FSCTL_SET_SPARSE,
						   NULL,
						   0UL,
						   NULL,
						   0UL,
						   &dwBytesReturned,
						   NULL);
}

BOOL is_sparse(int fd)
{
	BY_HANDLE_FILE_INFORMATION	fi;

	// Retrieve the file information using the open file handle
	// and check for the sparse attribute.
	if(fd < 0 || 
		!GetFileInformationByHandle((HANDLE)_get_osfhandle(fd), &fi) || 
		!(fi.dwFileAttributes & FILE_ATTRIBUTE_SPARSE_FILE))
		return FALSE;
	return TRUE;
}

BOOL file_system_supports(const TCHAR* _Path, unsigned long dwMask)
{
	TCHAR szFileSystem[FILESYSNAMEBUFSIZE];
	BOOL bResult = FALSE;
	unsigned long dwFlags;

	TCHAR* vp = volume_path_name(_Path);
	if(vp == NULL)
		return FALSE;

	
	__try
	{
		// If the volume is not NTFS? 
		if(!GetVolumeInformation(vp, // Root path name 
									NULL,             // volume name buffer
									0,                // length of volume name buffer
									NULL,             // volume serial number (unsigned long)
									NULL,             // maximum file name length 
									&dwFlags,      // flags
									szFileSystem,   //
									FILESYSNAMEBUFSIZE))
		{
			_RPT2(_CRT_WARN, "Failed to get volume information for %s: Last Error = %ld\n", vp, GetLastError());
			__leave;
		}

		//_ftprintf(stderr, _T("The file system is %s\n"), szFileSystem);

		if((dwFlags & dwMask) == dwMask)
			bResult = TRUE;
//		else
//			_ftprintf(stderr, _T("The file system does not support compression and sparse files\n"));
	}
	__finally
	{
		if(vp != NULL)
			free(vp);
	}
	return bResult;
}
