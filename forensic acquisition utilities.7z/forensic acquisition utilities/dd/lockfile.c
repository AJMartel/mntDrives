/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#include <config.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>

#ifdef _WIN32
#include <windows.h>
#endif //_WIN32

#include "error.h"

#define NUM_FILES 2
extern int o_disk_device[];
extern int o_disk_file[];
extern int o_physical_drive[];

int lock_file(int fd, __int64 size, unsigned int which);
int unlock_file(int fd, __int64 size, unsigned int which);
int dismount_device(int fd, unsigned int which);

static int lock_disk_device(int fd)
{
#ifdef _WIN32
	unsigned long dwBytesReturned;
	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),            // handle to a volume
						FSCTL_LOCK_VOLUME,  // dwIoControlCode
						NULL,               // lpInBuffer
						0,                  // nInBufferSize
						NULL,               // lpOutBuffer
						0,                  // nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						0))                // OVERLAPPED structure
	{
		_RPT1(_CRT_WARN, "Failed to lock volume: Last Error = %ld\n", GetLastError());
		return 0;
	}
	return 1;
#else
	return 0;
#endif //_WIN32
}

static unlock_disk_device(int fd)
{
#ifdef _WIN32
	unsigned long dwBytesReturned;
	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),            // handle to a volume
						FSCTL_UNLOCK_VOLUME,  // dwIoControlCode
						NULL,               // lpInBuffer
						0,                  // nInBufferSize
						NULL,               // lpOutBuffer
						0,                  // nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						0))                // OVERLAPPED structure
	{
		_RPT1(_CRT_WARN, "Failed to unlock volume: Last Error = %ld\n", GetLastError());
		return 0;

	}
	return 1;
#else
	return 0;
#endif //_WIN32
}

static int lock_disk_file(int fd, __int64 _S)
{
#ifdef _WIN32
	ULARGE_INTEGER _R;
	OVERLAPPED ov;
	
	memset(&ov, 0, sizeof(OVERLAPPED));

	_R.QuadPart = _S;

	if(!LockFileEx((HANDLE)_get_osfhandle(fd),
		           LOCKFILE_EXCLUSIVE_LOCK,
				   0UL,
				   _R.LowPart,
				   _R.HighPart,
				   &ov))
	{
		_RPT1(_CRT_WARN, "Unable to lock file, Last Error = %ld\n", GetLastError());
		return 0;
	}

	return 1;
#else

	// The ANSI locking function does not support
	// large files.  You will get a compiler warning
	// to indicate this.  If your platform has large file
	// support, redefine _locking in generic.h
	if(locking(fd, _LK_LOCK, _S))
		return 1;
	return 0;
#endif //
}

int unlock_disk_file(int fd, unsigned __int64 _S)
{
#ifdef _WIN32
	LARGE_INTEGER _R;
	OVERLAPPED ov;
	
	memset(&ov, 0, sizeof(OVERLAPPED));
	_R.QuadPart = _S;
	
	if(!UnlockFileEx((HANDLE)_get_osfhandle(fd),
				   0UL,
				   _R.LowPart,
				   _R.HighPart,
				   &ov))
	{
		_RPT1(_CRT_WARN, "Unable to unlock file, Last Error = %ld\n", GetLastError());
		return 0;
	}

	return 1;
#else
	// The ANSI _locking function does not support
	// large files.  You will get a compiler warning
	// to indicate this.  If your platform has large file
	// support, redefine _locking in generic.h
	if(locking(fd, _LK_UNLCK, _S))
		return 1;
	return 0;
#endif //
}

int lock_file(int fd, __int64 _S, unsigned int which)
{
	if(!o_disk_file[which])
		return 1;
	//else if(o_physical_drive[which]) 8/17/2004
	//	return 0;
	else if(o_disk_device[which])
		return lock_disk_device(fd);

	return lock_disk_file(fd, _S);
}

int unlock_file(int fd, __int64 _S, unsigned int which)
{
	if(fd < 0)
		return 0;

	if(!o_disk_file[which])
		return 1;
	else if(o_disk_device[which])
		return unlock_disk_device(fd);

	return unlock_disk_file(fd, _S);
}

int dismount_device(int fd, unsigned int which)
{
#ifdef _WIN32
	unsigned long dwBytesReturned;

	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),            // handle to a volume
						FSCTL_DISMOUNT_VOLUME,  // dwIoControlCode
						NULL,               // lpInBuffer
						0,                  // nInBufferSize
						NULL,               // lpOutBuffer
						0,                  // nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						0))                // OVERLAPPED structure
	{
		_RPT1(_CRT_WARN, "Failed to dismount volume: Last Error = %ld\n", GetLastError());
		return 0;
	}

	return 1;
#else
	//TODO
	return 0;
#endif // _WIN32
}

