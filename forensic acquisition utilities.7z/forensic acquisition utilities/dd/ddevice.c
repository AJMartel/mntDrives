/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.  */

// Copyright 2002 George M. Garner Jr.

#if HAVE_CONFIG_H
# include <config.h>
#endif

#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <io.h>

#ifdef _WIN32
#include <windows.h>
#include <ntddscsi.h>
#endif //_WIN32

#include "error.h"

extern const TCHAR* input_file;
void* xmalloc(size_t);

#define INPUT_FILE 0;
#define OUTPUT_FILE 1;
#define NUM_FILES 2

int o_disk_device[NUM_FILES] = {0,0};
int o_disk_file[NUM_FILES] = {0,0};
 int o_physical_drive[NUM_FILES] = {0,0};
int is_disk_device(int fd, const TCHAR* path, unsigned int which); //8/17/04 added path
int display_device_info(int fd, const TCHAR* file, unsigned int which);
int is_disk_writable(int fd);

#ifdef _WIN32

__int64 _DriveSize;

#define FILESYSNAMEBUFSIZE 1024
// From ntddstor.h
typedef enum _STORAGE_PROPERTY_ID {
    StorageDeviceProperty = 0,
    StorageAdapterProperty,
    StorageDeviceIdProperty
} STORAGE_PROPERTY_ID, *PSTORAGE_PROPERTY_ID;

typedef enum _STORAGE_QUERY_TYPE {
    PropertyStandardQuery = 0,          // Retrieves the descriptor
    PropertyExistsQuery,                // Used to test whether the descriptor is supported
    PropertyMaskQuery,                  // Used to retrieve a mask of writeable fields in the descriptor
    PropertyQueryMaxDefined     // use to validate the value
} STORAGE_QUERY_TYPE, *PSTORAGE_QUERY_TYPE;

typedef struct _STORAGE_PROPERTY_QUERY {

    STORAGE_PROPERTY_ID PropertyId;
    STORAGE_QUERY_TYPE QueryType;
    UCHAR AdditionalParameters[1];

} STORAGE_PROPERTY_QUERY, *PSTORAGE_PROPERTY_QUERY;

typedef struct _STORAGE_DESCRIPTOR_HEADER {
    ULONG Version;
    ULONG Size;
} STORAGE_DESCRIPTOR_HEADER, *PSTORAGE_DESCRIPTOR_HEADER;

typedef struct _STORAGE_DEVICE_DESCRIPTOR {
    ULONG Version;
    ULONG Size;
    UCHAR DeviceType;
    UCHAR DeviceTypeModifier;
    BOOLEAN RemovableMedia;
    BOOLEAN CommandQueueing;
    ULONG VendorIdOffset;
    ULONG ProductIdOffset;
    ULONG ProductRevisionOffset;
    ULONG SerialNumberOffset;
    STORAGE_BUS_TYPE BusType;
    ULONG RawPropertiesLength;
    UCHAR RawDeviceProperties[1];
} STORAGE_DEVICE_DESCRIPTOR, *PSTORAGE_DEVICE_DESCRIPTOR;

#define IOCTL_STORAGE_QUERY_PROPERTY   CTL_CODE(IOCTL_STORAGE_BASE, 0x0500, METHOD_BUFFERED, FILE_ANY_ACCESS)


static PVOLUME_DISK_EXTENTS volume_disk_extents(int fd, int* bClustered)
{
	long lError;
	unsigned char* pbData = (unsigned char*)0;
	unsigned long dwReturned;
	unsigned long dwSize;
	VOLUME_DISK_EXTENTS de;

	_ASSERTE(bClustered != NULL);
	*bClustered = FALSE;

	if(DeviceIoControl((HANDLE)_get_osfhandle(fd),                              
						IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,
						NULL,
						0UL,
						&de,
						sizeof(VOLUME_DISK_EXTENTS),
						&dwSize,
						NULL))
	{
		pbData = xmalloc(dwSize * sizeof(unsigned char));
		memcpy(pbData, (unsigned char*)&de, dwSize);
		return (PVOLUME_DISK_EXTENTS)pbData;
	}

	if((lError = GetLastError()) != ERROR_SUCCESS && 
		lError != ERROR_MORE_DATA)
	{
		_RPT1(_CRT_WARN, "IOCTL_GET_VOLUME_DISK_EXTENTS failed!  Last Error = %ld\n", GetLastError());
		return NULL;
	}

	pbData = xmalloc(dwSize * sizeof(unsigned char));

	if(!DeviceIoControl((HANDLE)_get_osfhandle(fd),
					   IOCTL_VOLUME_GET_VOLUME_DISK_EXTENTS,
					   NULL,
					   0UL,
					   pbData,
					   dwSize,
					   &dwReturned,
					   NULL) || dwReturned != dwSize)
	{
		_RPT1(_CRT_WARN, "IOCTL_GET_VOLUME_DISK_EXTENTS failed!  Last Error = %ld\n", GetLastError());
		free(pbData);
		return NULL;
	}
	
	*bClustered = (DeviceIoControl((HANDLE)_get_osfhandle(fd),
					   IOCTL_VOLUME_IS_CLUSTERED,
					   NULL,
					   0UL,
					   NULL,
					   0UL,
					   &dwSize,
					   NULL) == NO_ERROR);

	return (PVOLUME_DISK_EXTENTS)pbData;
}

static const TCHAR* drive_type(const TCHAR* lpszRoot)
{
	switch(GetDriveType(lpszRoot))
	{
	case DRIVE_NO_ROOT_DIR:
		return _T("no root directory");
		break;
	case DRIVE_REMOVABLE:
		return _T("removable");
		break;
	case DRIVE_FIXED:
		return _T("fixed");
		break;
	case DRIVE_REMOTE:
		return _T("remote");
		break;
	case DRIVE_CDROM:
		return _T("cdrom/dvd-rom");
		break;
	case DRIVE_RAMDISK:
		return _T("ram disk");
		break;
	default:
		;
	}
	return _T("unknown");
}
static void display_disk_extent(PDISK_EXTENT pExtent)
{
	_ftprintf(stderr, _T("\tDisk Number:\t\t%ld\n"), pExtent->DiskNumber);
	_ftprintf(stderr, _T("\tStarting Offset:\t0x%016I64x\n"), pExtent->StartingOffset.QuadPart);
	_ftprintf(stderr, _T("\tExtent Length:\t\t%016I64d\n"), pExtent->ExtentLength.QuadPart);
}

static void display_volume_disk_extents(PVOLUME_DISK_EXTENTS lpVolumeExtents)
{
	unsigned long i;

	if(lpVolumeExtents == (PVOLUME_DISK_EXTENTS)0)
		return;
		
	_ftprintf(stderr, _T("Volume Extents:\n\n"));

	for(i = 0UL; i < lpVolumeExtents->NumberOfDiskExtents; ++i)
		display_disk_extent(lpVolumeExtents->Extents + i);
}

static void display_volume_flags(unsigned long dwFlags)
{
	_ftprintf(stderr, _T("Volume Characteristics:\n\n"));

	if(dwFlags & FS_CASE_IS_PRESERVED)
		_ftprintf(stderr, _T("\t\t\tFile system preserves case\n"));
	if(dwFlags & FS_CASE_SENSITIVE)
		_ftprintf(stderr, _T("\t\t\tFile system supports case sensitive file names\n"));
	if(dwFlags & FS_UNICODE_STORED_ON_DISK)
		_ftprintf(stderr, _T("\t\t\tFile system supports Unicode file names\n"));
	if(dwFlags & FS_PERSISTENT_ACLS)
		_ftprintf(stderr, _T("\t\t\tFile system preserves and supports persistent ACL's\n"));
	if(dwFlags & FS_FILE_COMPRESSION)
		_ftprintf(stderr, _T("\t\t\tFile system supports file level compression\n"));
	if(dwFlags & FS_VOL_IS_COMPRESSED)
		_ftprintf(stderr, _T("\t\t\tVolume is compressed\n"));
	if(dwFlags & FILE_NAMED_STREAMS)
		_ftprintf(stderr, _T("\t\t\tFile system supports named streams\n"));
	if(dwFlags & FS_VOL_IS_COMPRESSED)
		_ftprintf(stderr, _T("\t\t\tVolume is compressed\n"));
	if(dwFlags & FILE_READ_ONLY_VOLUME)
		_ftprintf(stderr, _T("\t\t\tVolume is read only\n"));
	if(dwFlags & FILE_SUPPORTS_ENCRYPTION)
		_ftprintf(stderr, _T("\t\t\tFile system supports encryption\n"));
	if(dwFlags & FILE_SUPPORTS_OBJECT_IDS)
		_ftprintf(stderr, _T("\t\t\tFile system supports object identifiers\n"));
	if(dwFlags & FILE_SUPPORTS_REPARSE_POINTS)
		_ftprintf(stderr, _T("\t\t\tFile system supports reparse points\n"));
	if(dwFlags & FILE_SUPPORTS_SPARSE_FILES)
		_ftprintf(stderr, _T("\t\t\tFile system supports sparse files\n"));
	if(dwFlags & FILE_VOLUME_QUOTAS)
		_ftprintf(stderr, _T("\t\t\tFile system supports quotas\n"));
}

static void _display_volume_information(const TCHAR* lpszRoot, const TCHAR* lpszVolume, const TCHAR* lpszDriveType, unsigned long dwSerialNumber, unsigned long dwMaxComponentLength, unsigned long dwFlags, const TCHAR* lpszFileSystem, PVOLUME_DISK_EXTENTS lpVolumeExtents, const int bClustered)
{
	_ftprintf(stderr, _T("Volume Name:\t\t%s\n"), lpszRoot);
	_ftprintf(stderr, _T("Volume Label:\t\t%s\n"), lpszVolume);
	_ftprintf(stderr, _T("Drive Type:\t\t%s\n"), lpszDriveType);

	_ftprintf(stderr, _T("Volume Serial Number:\t\t%hX-%hX\n"), (short)(dwSerialNumber >> 8), (short) dwSerialNumber);
	_ftprintf(stderr, _T("Maximum Component Length:\t%ld\n"), dwMaxComponentLength);
	display_volume_flags(dwFlags);
	_ftprintf(stderr, _T("File System:\t\t%s\n"), lpszFileSystem);
	_ftprintf(stderr, _T("Clustered:\t\t%s\n"), bClustered ? _T("Yes") : _T("No\n"));

	display_volume_disk_extents(lpVolumeExtents);	
}

static int display_volume_size(const TCHAR* directory)
{
	ULARGE_INTEGER ulFreeAvailable;
	ULARGE_INTEGER ulTotal;
	ULARGE_INTEGER ulTotalFree;

	if(!GetDiskFreeSpaceEx(directory,  // directory name
							&ulFreeAvailable,    // bytes available to caller
							&ulTotal        ,    // bytes on disk
							&ulTotalFree))         // free bytes on disk
	{
		// This function fails with ERROR_ACCESS_DENIED if  the file is
		// a physical disk.
		long lError = GetLastError();
			
		_RPT1(_CRT_WARN, "GetDiskFreeSpaceEx failed: Last Error = %ld\n", GetLastError());
		return FALSE;
	}

	_DriveSize = ulTotal.QuadPart/(__int64)1024;;

	_ftprintf(stderr, _T("Statistics for logical volume %s\n"), input_file);
	_ftprintf(stderr, _T("\t\t%I64d bytes available\n"), ulFreeAvailable.QuadPart);
	_ftprintf(stderr, _T("\t\t%I64d bytes free\n"), ulTotalFree.QuadPart);
	_ftprintf(stderr, _T("\t\t%I64d bytes total\n\n"), ulTotal.QuadPart);

	return TRUE;
}

static int display_volume_info(const TCHAR* directory, int fd)
{
	int bResult = FALSE;
	int bClustered = FALSE;
	unsigned long dwSerialNumber;
	unsigned long dwMaxComponentLength;
	unsigned long dwFlags;
	PVOLUME_DISK_EXTENTS lpVolumeExtents = NULL;
	TCHAR szFileSystem[FILESYSNAMEBUFSIZE];
	TCHAR szVolume[_MAX_PATH];

	// If the volume is not NTFS? 
	if(!GetVolumeInformation(directory, // Root path name 
								szVolume,             // volume name buffer
								_MAX_PATH,             // length of volume name buffer
								&dwSerialNumber,         // volume serial number (unsigned long)
								&dwMaxComponentLength,   // maximum file name length 
								&dwFlags,      // flags
								szFileSystem,   //
								FILESYSNAMEBUFSIZE))
	{
		_RPT1(_CRT_WARN, "Failed to get volume information: Last Error = %ld\n", GetLastError());
		return FALSE;
	}

	lpVolumeExtents = volume_disk_extents(fd, &bClustered);

	__try
	{
		_display_volume_information(input_file, 
									szVolume, 
									drive_type(directory),
									dwSerialNumber, 
									dwMaxComponentLength, 
									dwFlags, 
									szFileSystem,
									lpVolumeExtents,
									bClustered);
		bResult = TRUE;
		
	}
	__finally
	{
		if(lpVolumeExtents != NULL)
			free(lpVolumeExtents);
	}
	return bResult;
}

static void display_physical_media_type(MEDIA_TYPE mt)
{
	_ftprintf(stderr, _T("\tMedia Type:\t\t"));

	switch(mt)
	{
	case F5_1Pt2_512: 
		_ftprintf(stderr, _T("A 5.25\" floppy, with 1.2MB and 512 bytes/sector\n"));
		break;
	case F3_1Pt44_512: 
		_ftprintf(stderr, _T("A 3.5\" floppy, with 1.44MB and 512 bytes/sector\n"));
		break;
	case F3_2Pt88_512: 
		_ftprintf(stderr, _T("A 3.5\" floppy, with 2.88MB and 512 bytes/sector\n"));
		break;
	case F3_20Pt8_512: 
		_ftprintf(stderr, _T("A 3.5\" floppy, with 20.8MB and 512 bytes/sector\n"));
		break;
	case F3_720_512: 
		_ftprintf(stderr, _T("A 3.5\" floppy, with 720KB and 512 bytes/sector\n"));
		break;
	case F5_360_512:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 360KB and 512 bytes/sector\n"));
		break;
	case F5_320_512:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 320KB and 512 bytes/sector\n"));
		break;
	case F5_320_1024:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 320KB and 1024 bytes/sector\n"));
		break;
	case F5_180_512:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 180KB and 512 bytes/sector\n"));
		break;
	case F5_160_512:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 160KB and 512 bytes/sector\n"));
		break;
	case RemovableMedia:
		_ftprintf(stderr, _T("Removable media other than floppy\n"));
		break;
	case FixedMedia:
		_ftprintf(stderr, _T("Fixed hard disk media\n"));
		break;
	case F3_120M_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 120MB and 512 bytes/sector\n"));
		break;
	case F3_640_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 640MB and 512 bytes/sector\n"));
		break;
	case F5_640_512:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 640KB and 512 bytes/sector\n"));
		break;
	case F5_720_512:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 720KB and 512 bytes/sector\n"));
		break;
	case F3_1Pt2_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 1.2MB and 512 bytes/sector\n"));
		break;
	case F3_1Pt23_1024:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 1.23MB and 1024 bytes/sector\n"));
		break;
	case F5_1Pt23_1024:
		_ftprintf(stderr, _T("A 5.25\" floppy, with 1.23KB and 1024 bytes/sector\n"));
		break;
	case F3_128Mb_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 128MB and 512 bytes/sector\n"));
		break;
	case F3_230Mb_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 230MB and 512 bytes/sector\n"));
		break;
	case F8_256_128:
		_ftprintf(stderr, _T("An 8\" floppy, with 256KB and 128 bytes/sector\n"));
		break;
	case F3_200Mb_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 200MB and 512 bytes/sector. (HiFD)\n"));
		break;
	case F3_240M_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 240MB and 512 bytes/sector. (HiFD)\n"));
		break;
	case F3_32M_512:
		_ftprintf(stderr, _T("A 3.5\" floppy, with 32MB and 512 bytes/sector\n"));
		break;
	case Unknown: 
	default:
		_ftprintf(stderr, _T("Unknown media type\n"));
	}
	_ftprintf(stderr, _T("\n"));
}
static int display_physical_disk_geometry_ex(int fd)
{
	unsigned long dwBytesReturned;
	unsigned char buf[1024];
	PDISK_GEOMETRY_EX pdg =(PDISK_GEOMETRY_EX)buf;
	
	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),              // handle to a volume
						IOCTL_DISK_GET_DRIVE_GEOMETRY_EX, // dwIoControlCode
						NULL,                 // lpInBuffer
						0,                    // nInBufferSize
						pdg,                  // lpOutBuffer
						1024,// nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						NULL))                // OVERLAPPED structure
	{
		unsigned long dwError = GetLastError();
		//_RPT1(_CRT_ASSERT, "Failed to get extended disk geometry: Last Error = %ld\n", dwError);
		return FALSE;
	}

	_DriveSize = pdg->DiskSize.QuadPart/(__int64)1024;
	_RPT2(_CRT_WARN, "Reported drive size = 0x%I64x\nEstimated drive size = 0x%I64x\n", pdg->DiskSize.QuadPart, pdg->Geometry.BytesPerSector * pdg->Geometry.SectorsPerTrack * pdg->Geometry.TracksPerCylinder * pdg->Geometry.Cylinders.QuadPart);
	_ftprintf(stderr, _T("Geometry:\n"));
	_ftprintf(stderr, _T("\tCylinders:\t\t%I64d\n"), pdg->Geometry.Cylinders.QuadPart);
	_ftprintf(stderr, _T("\tTracks per Cylinder:\t%ld\n"), pdg->Geometry.TracksPerCylinder);
	_ftprintf(stderr, _T("\tSectors per Track:\t%ld\n"), pdg->Geometry.SectorsPerTrack);
	_ftprintf(stderr, _T("\tBytes per Sector:\t%ld\n"), pdg->Geometry.BytesPerSector);
	_ftprintf(stderr, _T("\tTotal Size:\t\t%I64d KB\n"), _DriveSize);
	display_physical_media_type(pdg->Geometry.MediaType);
	
	return TRUE;
}	

#define SPT_SENSE_LENGTH 32
#define CDB10GENERIC_LENGTH 10
#define SCSIOP_READ_CAPACITY  0x25  //scsi.h

#pragma pack(push, read_capacity, 1)
typedef struct _READ_CAPACITY_DATA {
    ULONG LogicalBlockAddress;
    ULONG BytesPerBlock;
} READ_CAPACITY_DATA, *PREAD_CAPACITY_DATA; //scsi.h
#pragma pack(pop, read_capacity) 

typedef struct _SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER {
    SCSI_PASS_THROUGH_DIRECT spt;
    ULONG             Filler;      // realign buffer to double word boundary
    UCHAR             ucSenseBuf[SPT_SENSE_LENGTH];
	READ_CAPACITY_DATA rcd;
    } SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER, *PSCSI_PASS_THROUGH_DIRECT_WITH_BUFFER;

static unsigned long convert_to_host_byte_order(unsigned long network)
{
	unsigned long host;
	unsigned char* little = (unsigned char*) &host;
	unsigned char* big = (unsigned char*) &network;
	little[0] = big[3];
	little[1] = big[2];
	little[2] = big[1];
	little[3] = big[0];
	return host;
}

static __int64 query_disk_capacity(int fd)
{
	unsigned long dwBytesReturned;
	unsigned long dwLength;
	__int64 _S;
	SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER sptwb;

	memset(&sptwb, 0, sizeof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER));

    sptwb.spt.Length = sizeof(SCSI_PASS_THROUGH_DIRECT);
	sptwb.spt.CdbLength = CDB10GENERIC_LENGTH;
	sptwb.spt.SenseInfoLength = SPT_SENSE_LENGTH;
	sptwb.spt.DataIn = SCSI_IOCTL_DATA_IN;
	sptwb.spt.TimeOutValue = 2;
    
    sptwb.spt.SenseInfoOffset = 
       offsetof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER,ucSenseBuf);

    sptwb.spt.DataBuffer = &sptwb.rcd;
    sptwb.spt.DataTransferLength = sizeof(READ_CAPACITY_DATA);

    sptwb.spt.Cdb[0] = SCSIOP_READ_CAPACITY;

    dwLength = offsetof(SCSI_PASS_THROUGH_DIRECT_WITH_BUFFER,rcd) +
       sptwb.spt.DataTransferLength;

	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),              // handle to a volume
						IOCTL_SCSI_PASS_THROUGH_DIRECT, // dwIoControlCode
						&sptwb,                 // lpInBuffer
						sizeof(SCSI_PASS_THROUGH_DIRECT),  // nInBufferSize
						&sptwb,                  // lpOutBuffer
						dwLength,// nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						NULL))                // OVERLAPPED structure
	{
		unsigned long dwError = GetLastError();
		_RPT1(_CRT_WARN, "Failed to read SCSI capacity: Last Error = %ld\n", dwError);
		return -1I64;
	}
	
	// SCSI CAPACITY DATA is returned in network byte order.
	sptwb.rcd.LogicalBlockAddress = convert_to_host_byte_order(sptwb.rcd.LogicalBlockAddress);
	sptwb.rcd.BytesPerBlock = (sptwb.rcd.BytesPerBlock == 0UL)? 512 : convert_to_host_byte_order(sptwb.rcd.BytesPerBlock);

	_S = sptwb.rcd.LogicalBlockAddress;
	_S++;
	_S *= sptwb.rcd.BytesPerBlock;
	_S /= 1024I64;
	return _S;
}

static int display_physical_disk_geometry(int fd)
{
	unsigned long dwBytesReturned;
	DISK_GEOMETRY dg;

	if(display_physical_disk_geometry_ex(fd))
		return TRUE;

	if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),              // handle to a volume
						IOCTL_DISK_GET_DRIVE_GEOMETRY, // dwIoControlCode
						NULL,                 // lpInBuffer
						0,                    // nInBufferSize
						&dg,                  // lpOutBuffer
						sizeof(DISK_GEOMETRY),// nOutBufferSize
						&dwBytesReturned,   // number of bytes returned
						NULL))                // OVERLAPPED structure
	{
		unsigned long dwError = GetLastError();
		//_RPT1(_CRT_ASSERT, "Failed to get extended disk geometry: Last Error = %ld\n", dwError);
		return FALSE;
	}

	_ASSERTE(dwBytesReturned == sizeof(DISK_GEOMETRY));

	_ftprintf(stderr, _T("Geometry:\n"));
	_ftprintf(stderr, _T("\tCylinders:\t\t%I64d\n"), dg.Cylinders.QuadPart);
	_ftprintf(stderr, _T("\tTracks per Cylinder:\t%ld\n"), dg.TracksPerCylinder);
	_ftprintf(stderr, _T("\tSectors per Track:\t%ld\n"), dg.SectorsPerTrack);
	_ftprintf(stderr, _T("\tBytes per Sector:\t%ld\n"), dg.BytesPerSector);

	_DriveSize = query_disk_capacity(fd);

	if(_DriveSize != -1I64)
	{
		_ftprintf(stderr, _T("\tTotal Size:\t\t%I64d KB\n"), _DriveSize);
	}
	else
	{
		_DriveSize = ((__int64) dg.BytesPerSector * (__int64) dg.SectorsPerTrack * (__int64) dg.TracksPerCylinder* dg.Cylinders.QuadPart)/(__int64)1024;
		_ftprintf(stderr, _T("\tEstimated Total Size:\t\t%I64d KB\n"), _DriveSize);
	}
		

	display_physical_media_type(dg.MediaType);
	
	return TRUE;
}	

static int display_disk_device_properties(int fd)
{
	long lError;
	unsigned long dwLength;
	PSTORAGE_DEVICE_DESCRIPTOR pSdd;
	STORAGE_PROPERTY_QUERY query;
	unsigned char data[512];
	query.PropertyId = StorageDeviceProperty;
    query.QueryType = PropertyStandardQuery;
	
	


    if(!DeviceIoControl((HANDLE) _get_osfhandle(fd),                
                        IOCTL_STORAGE_QUERY_PROPERTY,
                        &query,
                        sizeof( STORAGE_PROPERTY_QUERY ),
                        data,                   
                        512,                      
                        &dwLength,
                        NULL                    
                        ))
	{
		lError = GetLastError();
		//_RPT1(_CRT_ASSERT, "Attempt to query storage device property failed: Last Error = %ld\n", lError);
		return FALSE;
	}
	
	pSdd = (PSTORAGE_DEVICE_DESCRIPTOR)data;
	
	fprintf(stderr, "Disk: %s %s (", (pSdd -> VendorIdOffset != 0UL)? (char*)(data + pSdd -> VendorIdOffset) : "",
										(pSdd -> ProductIdOffset != 0UL)? (char*)(data + pSdd -> ProductIdOffset) : "");
	fprintf(stderr, "S/N %s)\n", (pSdd->SerialNumberOffset != 0UL)? (char*)(data + pSdd->SerialNumberOffset) : "");
	return TRUE;
}
static const TCHAR* partition_style(unsigned long style)
{
	switch(style)
	{
	case PARTITION_STYLE_MBR:
		return _T("MBR");
	case PARTITION_STYLE_GPT:
		return _T("GPT");
			default:
		;
	}

	return _T("Raw");
}

static const TCHAR* partiton_type(unsigned char ch)
{
	switch(ch)
	{
	case PARTITION_EXTENDED:
		return _T("Extended");
	case PARTITION_FAT_12:
		return _T("FAT12");
	case PARTITION_FAT_16:
		return _T("FAT16");
	case PARTITION_FAT32:
		return _T("FAT32");
	case PARTITION_FAT32_XINT13:
		return _T("FAT32_XINT13");
	case PARTITION_HUGE:
		return _T("HUGE");
	case PARTITION_IFS:
		return _T("IFS");
	case PARTITION_LDM:
		return _T("LDM");
	case PARTITION_NTFT:
		return _T("NTFT");
	case PARTITION_OS2BOOTMGR:
		return _T("OS2BootMgr");
	case PARTITION_PREP:
		return _T("PReP");
	case PARTITION_UNIX:
		return _T("Unix");
	case PARTITION_XENIX_1:
		return _T("Xenix_1");
	case PARTITION_XENIX_2:
		return _T("Xenix_2");
	case PARTITION_XINT13:
		return _T("Extended INT13");
	case PARTITION_XINT13_EXTENDED:
		return _T("Extended (uses INT13)");
	case VALID_NTFT:
		_T("NTFT");
	default:
		;
	}
	return _T("Unknown");
}

static void display_Gpt_Partition_Attributes(unsigned __int64 attributes)
{
	_ftprintf(stderr, _T("\tAttributes:\n"));

	if((attributes & GPT_ATTRIBUTE_PLATFORM_REQUIRED) == GPT_ATTRIBUTE_PLATFORM_REQUIRED)
		_ftprintf(stderr, _T("\t\t\tPlatform Required\n"));
	if((attributes & GPT_BASIC_DATA_ATTRIBUTE_NO_DRIVE_LETTER ) == GPT_BASIC_DATA_ATTRIBUTE_NO_DRIVE_LETTER )
		_ftprintf(stderr, _T("\t\t\tNo drive letter\n"));
	if((attributes & GPT_BASIC_DATA_ATTRIBUTE_HIDDEN) == GPT_BASIC_DATA_ATTRIBUTE_HIDDEN)
		_ftprintf(stderr, _T("\t\t\tBasic data hidden\n"));
	if((attributes & GPT_BASIC_DATA_ATTRIBUTE_READ_ONLY ) == GPT_BASIC_DATA_ATTRIBUTE_READ_ONLY )
		_ftprintf(stderr, _T("\t\t\tBasic data read only\n\n"));
}

static int display_extended_partition_info(int fd)
{
	int bResult = FALSE;
	long lError;
	unsigned int i = 0;
	PDRIVE_LAYOUT_INFORMATION_EX pDli;
	unsigned char* pbData = NULL;
	unsigned long dwSize;

	__try
	{
		do
		{
			dwSize = 1024 + sizeof(PARTITION_INFORMATION_EX) * i++;
			pbData = realloc(pbData, dwSize);

			if(pbData == NULL)
				__leave;

			if(DeviceIoControl((HANDLE) _get_osfhandle(fd),   // handle to device
							   IOCTL_DISK_GET_DRIVE_LAYOUT_EX,   // dwIoControlCode
                               NULL,                          // lpInBuffer
                               0UL,                           // nInBufferSize
                               pbData,                        // output buffer
                               dwSize,                        // size of output buffer
                               &dwSize,                       // number of bytes returned
                               NULL))                         // OVERLAPPED structure
			{
				lError = ERROR_SUCCESS;
				break;
			}

			lError = GetLastError();

		} while(lError == ERROR_INSUFFICIENT_BUFFER ||
			    lError == ERROR_MORE_DATA);
		if(lError != ERROR_SUCCESS)
		{
			_RPT1(_CRT_ASSERT, "IOCTL_DISK_GET_DRIVE_LAYOUT_EX failed! Last Error = %ld\n", lError); 
			__leave;
		}
		
		pDli = (PDRIVE_LAYOUT_INFORMATION_EX) pbData;

		_ftprintf(stderr, _T("\tPartition Count:\t%ld\n"), pDli->PartitionCount);
		_ftprintf(stderr, _T("\tStyle:\t\t\t%s\n"), partition_style(pDli->PartitionStyle));
		
		if(pDli->PartitionStyle == PARTITION_STYLE_MBR)
		{
			_ftprintf(stderr, _T("\tSignature:\t\t%lX\n\n"), pDli->Mbr.Signature);
		}
		else
		{
			TCHAR szGuid[64];
			if(StringFromGUID2(&pDli->Gpt.DiskId, szGuid, 64) > 0)
				_ftprintf(stderr, _T("DiskId:\t\t\t%s\n"), szGuid);
			_ftprintf(stderr, _T("\tStartingUsableOffset:\t%016I64x\n"), pDli->Gpt.StartingUsableOffset.QuadPart);
			_ftprintf(stderr, _T("\tUsableLength:\t% 16I64d\n"), pDli->Gpt.UsableLength.QuadPart);
			_ftprintf(stderr, _T("\tMaxPartitionCount:\t%ld\n\n"), pDli->Gpt.MaxPartitionCount);
		}

		for(i = 0; i < pDli->PartitionCount; ++i)
		{
			if(pDli->PartitionEntry[i].PartitionStyle == PARTITION_STYLE_MBR &&
				_tcsnicmp(partiton_type(pDli->PartitionEntry[i].Mbr.PartitionType), _T("Unknown"), 8) == 0)
				continue;

			_ftprintf(stderr, _T("\tPartition:\t\t%ld\n"),pDli->PartitionEntry[i].PartitionNumber);
			_ftprintf(stderr, _T("\tStarting Offset:\t%016I64x\n"), pDli->PartitionEntry[i].StartingOffset.QuadPart);
			_ftprintf(stderr, _T("\tLength:\t\t\t%016I64d\n"), pDli->PartitionEntry[i].PartitionLength.QuadPart);
			
			if(pDli->PartitionEntry[i].PartitionStyle == PARTITION_STYLE_MBR)
			{
				_ftprintf(stderr, _T("\tType:\t\t\t%s\n"), partiton_type(pDli->PartitionEntry[i].Mbr.PartitionType));
				_ftprintf(stderr, _T("\tBootable?\t\t%s\n\n"), (pDli->PartitionEntry[i].Mbr.BootIndicator)? _T("Yes") : _T("No"));
			}
			else if(pDli->PartitionEntry[i].PartitionStyle == PARTITION_STYLE_GPT)
			{
				TCHAR szGuid[64];
				if(StringFromGUID2(&pDli->PartitionEntry[i].Gpt.PartitionType, szGuid, 64) > 0)
					_ftprintf(stderr, _T("\tPartition Type:\t%s\n"), szGuid);
				if(StringFromGUID2(&pDli->PartitionEntry[i].Gpt.PartitionId, szGuid, 64) > 0)
					_ftprintf(stderr, _T("\tPartition Id:\t%s\n"), szGuid);
				fwprintf(stderr, L"\tName:\t%s\n", pDli->PartitionEntry[i].Gpt.Name);
				display_Gpt_Partition_Attributes(pDli->PartitionEntry[i].Gpt.Attributes);
			}
		}
		bResult = TRUE;
	}
	__finally
	{
		if(pbData != NULL)
			free(pbData);
	}
	return bResult;
}

static int _display_partition_info(int fd)
{
	int bResult = FALSE;
	long lError;
	unsigned int i = 0;
	PDRIVE_LAYOUT_INFORMATION pDli;
	unsigned char* pbData = NULL;
	unsigned long dwSize;

	__try
	{
		do
		{
			dwSize = 1024UL + sizeof(PARTITION_INFORMATION) * i++;
			pbData = realloc(pbData, dwSize);

			if(pbData == NULL)
				__leave;

			if(DeviceIoControl((HANDLE) _get_osfhandle(fd),   // handle to device
							   IOCTL_DISK_GET_DRIVE_LAYOUT,   // dwIoControlCode
                               NULL,                          // lpInBuffer
                               0UL,                           // nInBufferSize
                               pbData,                        // output buffer
                               dwSize,                        // size of output buffer
                               &dwSize,                       // number of bytes returned
                               NULL))                         // OVERLAPPED structure
			{
				lError = ERROR_SUCCESS;
				break;
			}

			lError = GetLastError();

		} while(lError == ERROR_INSUFFICIENT_BUFFER ||
			    lError == ERROR_MORE_DATA);
		if(lError != ERROR_SUCCESS)
			__leave;
		
		pDli = (PDRIVE_LAYOUT_INFORMATION) pbData;

		_ftprintf(stderr, _T("\tPartition Count:\t%ld\n"), pDli->PartitionCount);
		_ftprintf(stderr, _T("\tSignature:\t\t%lX\n\n"), pDli->Signature);

		for(i = 0; i < pDli->PartitionCount; ++i)
		{
			if(_tcsnicmp(partiton_type(pDli->PartitionEntry[i].PartitionType), _T("Unknown"), 8) == 0)
				continue;

			_ftprintf(stderr, _T("\tPartition:\t\t%ld\n"),pDli->PartitionEntry[i].PartitionNumber);
			_ftprintf(stderr, _T("\tStarting Offset:\t%016I64x\n"), pDli->PartitionEntry[i].StartingOffset.QuadPart);
			_ftprintf(stderr, _T("\tLength:\t\t\t%016I64d\n"), pDli->PartitionEntry[i].PartitionLength.QuadPart);
			_ftprintf(stderr, _T("\tType:\t\t\t%s\n"), partiton_type(pDli->PartitionEntry[i].PartitionType));
			_ftprintf(stderr, _T("\tBootable?\t\t%s\n\n"), (pDli->PartitionEntry[i].BootIndicator)? _T("Yes") : _T("No"));
		}
		bResult = TRUE;
	}
	__finally
	{
		if(pbData != NULL)
			free(pbData);
	}
	return bResult;
}

static int display_partition_info(int fd)
{
	_ftprintf(stderr, _T("Partition Information:\n"));

	// IOCTL_DISK_GET_DRIVE_LAYOUT is obsolete but needed for
	// backwards compatibility with Windows 2000.
	// IOCTL_DISK_GET_DRIVE_LAYOUT_EX adds support for Gpt
	// partitions in addition Mbr support.
	if(!display_extended_partition_info(fd))
		return _display_partition_info(fd);
	return TRUE;
}

#endif //_WIN32

int display_device_info(int fd, const TCHAR* file, unsigned int which)
{
#ifdef _WIN32
	int bResult = FALSE;
	_ASSERTE(which < NUM_FILES);		
	if(o_physical_drive[which])
	{
		if(display_disk_device_properties(fd) &&
			display_physical_disk_geometry(fd))
			bResult = display_partition_info(fd);
	}
	else
	{
		size_t len = _tcslen(input_file);
		TCHAR* directory = (TCHAR*)xmalloc((len + 2) * sizeof(TCHAR));

		__try
		{

			_tcsncpy(directory, file, len + 1);
			if(directory[--len] != _T('\\') &&
				directory[len] != _T('/'))
				_tcscat(directory, _T("\\"));
	
			if(display_volume_size(directory))
				bResult = display_volume_info(directory, fd);

		}
		__finally
		{
			if(directory != NULL)
				free(directory);
		}
	}
	
	if(!bResult)
		_ftprintf(stderr, _T("unable to display device info"));
	return bResult;
#else
	//TODO
	return FALSE;
#endif //_WIN32
}

/*int is_disk_device(int fd, unsigned int which)
{
#ifdef _WIN32
	BY_HANDLE_FILE_INFORMATION fi;

	_ASSERTE(which < NUM_FILES);

	if(GetFileType((HANDLE) _get_osfhandle(fd)) != FILE_TYPE_DISK)
		return FALSE;
	
	o_disk_file[which] = 1;

	if(GetFileInformationByHandle((HANDLE) _get_osfhandle(fd), &fi) &&
		GetLastError() != ERROR_INVALID_FUNCTION)
	{
		_RPT1(_CRT_WARN, "Failed to GetFileInformationByHandle: Last Error = %ld\n", GetLastError());
		return FALSE;
	}
	_ASSERTE(_tcsnicmp(input_file, _T("\\\\.\\"), 4) == 0);
	o_disk_device[which] = 1;
	
	if(_tcsnicmp(input_file, _T("\\\\.\\PhysicalDrive"), 17) == 0)
		o_physical_drive[which] = 1;
	return TRUE;
#else
	// TO DO
	return FALSE;
#endif //
}*/

// 8/17/2004 
// Changes needed to support image restoration
// Taken from developmental build
int is_disk_device(int fd, const TCHAR* path, unsigned int which) 
{
#ifdef _WIN32
	BY_HANDLE_FILE_INFORMATION fi;

	_ASSERTE(which < NUM_FILES);

	if(GetFileType((HANDLE) _get_osfhandle(fd)) != FILE_TYPE_DISK)
		return FALSE;
	
	o_disk_file[which] = 1;

	if(	GetFileInformationByHandle((HANDLE) _get_osfhandle(fd), &fi))
	{
		if(which == 0/*INPUT_FILE*/)
		{
			ULARGE_INTEGER uli;
			uli.LowPart = fi.nFileSizeLow;
			uli.HighPart = fi.nFileSizeHigh;
			//_DriveSize = uli.QuadPart/1024ui64;
			_DriveSize = uli.QuadPart;
		}
		return FALSE;
	}

	_ASSERTE(_tcsnicmp(path, _T("\\\\.\\"), 4) == 0);
	o_disk_device[which] = 1;
	
	if(_tcsnicmp(path, _T("\\\\.\\"), 4) != 0)
		return FALSE;
	
	o_physical_drive[which] = 1;

	return TRUE;
#else
	// TO DO
	return FALSE;
#endif //
}

// added 8/17/2004
// from developmental release
int is_disk_writable(int fd)
{
	unsigned long dwBytesReturned;

	_ASSERTE(fd != -1);

	return DeviceIoControl((HANDLE) _get_osfhandle(fd),
		                   IOCTL_DISK_IS_WRITABLE,
						   NULL,
						   0UL,
						   NULL,
						   0UL,
						   &dwBytesReturned,
						   NULL);
}
