/* full-write.c -- an interface to write that retries after interrupts
   Copyright (C) 1993, 1994 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software Foundation,
   Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.

   Copied largely from GNU C's cccp.c.
   */

/* Modified from the original by George M. Garner Jr. 01/07/02*/

#if HAVE_CONFIG_H
# include <config.h>
#endif

#include <sys/types.h>

#if HAVE_UNISTD_H
# include <unistd.h>
#else
#include <stdio.h>
#endif

#include <errno.h>
#ifndef errno
extern int errno;
#endif

#include <stddef.h>
#include <io.h>

#ifdef _WIN32
#include <memory.h>

extern unsigned char* zbuf;
extern int o_sparse;
extern TCHAR *output_file;

int begin_sparse(size_t len);
int complete_sparse(int fd, size_t len);

unsigned __int64 wrote_out = (unsigned __int64) 0;
#endif //_WIN32

/* Write LEN bytes at PTR to descriptor DESC, retrying if interrupted.
   Return LEN upon success, write's (negative) error code otherwise.  */

//N.B. The algorithm requires that full_write be a
// signed type!!!  See "len > 0" below.
int full_write (int desc, char *ptr, size_t len)
{
	int total_written;

#ifdef _WIN32
	_ASSERTE(ptr != (char*)0);
	_ASSERTE(!o_sparse || zbuf != (unsigned char*)0);

	if(o_sparse && 
		memcmp(ptr, zbuf, len) == 0)
	{
		total_written = begin_sparse(len);
	}
	else if(complete_sparse(desc, len) < 0)
	{
		return -1;
	}
	else
#endif //_WIN32
	{
		total_written = 0;

		while (len > 0)
		{
			int written = write (desc, ptr, (unsigned int)len);
			if (written < 0)
			{
#ifdef EINTR
				if (errno == EINTR)
					continue;
#endif
				return written;
			}
		total_written += written;
		ptr += written;
		len -= written;
		}
	}
	wrote_out += (unsigned __int64) total_written;
	return total_written;
}

