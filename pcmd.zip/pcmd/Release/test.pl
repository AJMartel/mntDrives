#!/usr/bin/perl
#		
########################################
#
#  Sample Perl Program
#
printf "Checking args:\n";
foreach $argnum (0 .. $#ARGV) {
   print "argv[".$argnum."]=".$ARGV[$argnum]."\n";
}
print "\n";

print "Counting to five:\n";
for($i = 1; $i <=5; $i++) {    print "$i\n"; }

print "\nEnvironment: P*\n";
foreach $key ( keys %ENV )
{
  printf $key."=".$ENV{$key}."\n"  if ($key =~ /^P/);
}
print "\n";

print "program  = ".$0."\n";
print "OSname   = ".$^O."\n";
print "username = ".$<."\n";
print "groupid  = ".$(."\n";
print "processid= ".$$."\n";
print "perlvers = ".$]."\n";
print "exename  = ".$^X."\n";
print "include  = ".$INC[0]."\n";

print "\nexecuting : dir p*.* \n";
@outp=qx(dir /B p*.*);
foreach $line (@outp) { print $line; }

print "\nThe End..\n";
return 0;
