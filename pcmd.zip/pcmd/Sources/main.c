#include <precomp.h>

int _tmain (int argc, const TCHAR *argv[])
{
    return cmd_main(argc, argv);
}
