#define CMD_VER      "0.1.2"
#define CMD_VER_RC   CMD_VER"\0"
