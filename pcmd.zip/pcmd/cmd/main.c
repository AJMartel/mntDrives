/* ============================================================= *
 * Basic cmd interpreter with prepared hooks
 * as examples it checks for custom commands
 */
#include <precomp.h>
#pragma warning(disable: 4996)

#ifdef __cplusplus
extern "C" {  // only need to export C interface if
              // used by C++ source code
#endif
	
int cmd_sethook(int id, void *pFunc);
int cmd_main (int argc, const TCHAR *argv[]);

#ifdef __cplusplus
}
#endif

int cmd_sethook(int id, void *pFunc)
{
	switch (id) {
	   case CMDHOOK_LOADFILE : pCustomLoadFile=(tCMDHOOK_LoadFile)pFunc;  break;
	   case CMDHOOK_COMMAND  : pCustomCommand =(tCMDHOOK_Command )pFunc;  break;
	   case CMDHOOK_EXECUTE  : pCustomExecute =(tCMDHOOK_Execute )pFunc;  break;
	   default               : return 0;
	}
    return 1;
}

// custom command hook,   c=command   p=parameter string
int	cmd_custom(char *c, char *p)
{
	if (stricmp(c,"sayhello")==0) {
		while (*p==' ') p++;
        ConOutPuts("hello !");
		return 0;
	}
    return -1;		/* return cmd not found */
}

int _tmain (int argc, const TCHAR *argv[])
{
	/* use custom loadfile function in cmd.dll */
	cmd_sethook(CMDHOOK_COMMAND, (void *)cmd_custom);

    return cmd_main(argc,argv);
}

