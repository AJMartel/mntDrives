#ifdef WIN32
#pragma warning(disable: 4996)
#endif
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>

char	plcID[81]="/usr/bin/plc";

// dummy function
void	plc_init(char *typ, int sw)
{
	strcpy(plcID,typ);
}

// dummy function
int	plc_GetHostid(char *hnm, char *fhnm)
{
	strcpy(hnm,"host");
	strcpy(fhnm,"fullid");
	return 0;
}

// dummy function
int plc_keyread(char *packnm, char *tmp, char *hnm, char *days)
{
	packnm[0]=tmp[0]=hnm[0]=days[0]='\0';
	return 0;
}

/* --- read unencrypted file into memory */
char *plc_fn(char *fn, DWORD *siz)
{
  FILE  *fp;
  char  *ptr=0;
  DWORD size=0;

  fp=fopen(fn,"rb");
  if (fp) {
	    fseek(fp,0,SEEK_END);
		size=ftell(fp);
		fseek(fp,0,SEEK_SET);
		ptr=(char *)malloc(size+1);
	    fread(ptr,1,size,fp);
		ptr[size]='\0';
		fclose(fp);
  }
  if (siz) *siz=size;
  return ptr;
}

