/* THIS FILE WILL BE OVERWRITTEN BY DEV-C++ */
/* DO NOT EDIT ! */

#ifndef NETCAT_PRIVATE_H
#define NETCAT_PRIVATE_H

/* VERSION DEFINITIONS */
#define VER_STRING	"1.11.6.4"
#define VER_MAJOR	1
#define VER_MINOR	11
#define VER_RELEASE	0
#define VER_BUILD	5
#define COMPANY_NAME	"hobbit"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"NetCat64"
#define INTERNAL_NAME	"nc64"
#define LEGAL_COPYRIGHT	"Copyright (C) hobbit. All Rights Reserved."
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	""
#define PRODUCT_NAME	"NC64"
#define PRODUCT_VERSION	""

#endif /*NETCAT_PRIVATE_H*/
