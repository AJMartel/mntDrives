farm9 README.txt for cryptcat
09-22-2000

Thanks for downloading cryptcat

This is a simple modification to netcat to add twofish encryption.
netcat was origianally written by the l0pht (hobbit and weld pond).

The portion of the code written by farm9 is being released as Open Source.

See the file 'farm9 Public License Agreement.txt' for info on Open Source licensing.

Note that the L0pht has information on their copyrights covering netcat.  See the 
'readme.txt' file for that information.


jojo@farm9.com